# Third-party notices

Suite with Poccham AI is built on open-source software. The full texts of the
licences below are available from the respective projects.

## Runtime and UI

| Component | Licence | Use |
| --- | --- | --- |
| [Svelte](https://svelte.dev) | MIT | UI framework (compiled at build time) |
| [Vite](https://vite.dev) | MIT | Build tooling |
| [Tauri](https://tauri.app) | Apache-2.0 / MIT | Desktop shell, file system and dialogs |
| [llama.cpp](https://github.com/ggml-org/llama.cpp) | MIT | Local LLM inference |
| Rust crates (serde, rusqlite, tokio, …) | MIT / Apache-2.0 | Backend |

## Format compatibility

The Office Open XML (`.docx`, `.xlsx`, `.pptx`) readers and writers in this
product are an independent implementation written for this application. They
are informed by the public ECMA-376 / ISO-29500 specifications and by the
observable behaviour of LibreOffice and ONLYOFFICE, both of which are
distributed under their own licences:

* LibreOffice — Mozilla Public Licence 2.0
* ONLYOFFICE DocumentServer — AGPL-3.0

No source code from those projects is included in this product. Only the
public file-format specifications and general interoperability knowledge were
used, which is what allows this application to keep its own document format
while remaining compatible with Microsoft Office files.

## Fonts

The product ships no font files. It uses the fonts installed on your system so
that it never requires a network connection to render documents.
