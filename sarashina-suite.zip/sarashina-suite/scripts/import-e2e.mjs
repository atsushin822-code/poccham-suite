// 取り込み（.docx / .xlsx / .csv / .pptx）と挿入（画像 / 動画 / リンク）の実ブラウザ検証。
//
//   node scripts/import-e2e.mjs <baseUrl> <fixtureDir>
//
// fixtureDir には python-docx / openpyxl / python-pptx で生成した「外部製」ファイルを置く
// （アプリ自身が作ったファイルではない = 圧縮方式・名前空間・共有文字列の違いを踏むため）。
import { copyFileSync, existsSync } from "node:fs";
const { chromium } = await import(process.env.PLAYWRIGHT_MODULE || "playwright");

const base = process.argv[2] || "http://127.0.0.1:4173/";
const fixtures = process.argv[3] || "/home/user/.cache/oox/ext";

const results = [];
const check = (name, ok, extra = "") => {
  results.push({ name, ok });
  console.log(`${ok ? "PASS" : "FAIL"}  ${name}${extra ? ` — ${extra}` : ""}`);
};

for (const file of ["ext.docx", "ext.xlsx", "ext.csv", "ext.pptx", "pic.png"]) {
  if (!existsSync(`${fixtures}/${file}`)) {
    console.error(`fixture が見つかりません: ${fixtures}/${file}`);
    process.exit(2);
  }
}

const browser = await chromium.launch();
const ctx = await browser.newContext({ locale: "ja-JP", acceptDownloads: true });
const page = await ctx.newPage();
const errors = [];
page.on("pageerror", (e) => errors.push(String(e)));
page.on("console", (m) => {
  if (m.type() === "error") errors.push(m.text());
});

// 初回セットアップ（名前入力）を通す
await page.goto(base, { waitUntil: "networkidle" });
await page.waitForSelector(".setup input", { timeout: 15000 });
await page.fill(".setup input", "ぽっちゃん");
await page.click(".setup button.primary");
await page.waitForSelector('.create[data-kind="doc"]', { timeout: 15000 });

// 同じファイル名だと文書名が衝突するので、拡張子だけ変えたコピーも使う
copyFileSync(`${fixtures}/ext.csv`, `${fixtures}/sales.csv`);
copyFileSync(`${fixtures}/ext.pptx`, `${fixtures}/deck.pptx`);

const importFiles = async (files) => {
  await page.setInputFiles(".importrow input[type=file]", files);
  await page.waitForTimeout(900);
};

/** タイトルが完全一致する項目だけを開く（:has-text は本文の部分一致も拾ってしまうため） */
const openDoc = async (title) => {
  const ok = await page.evaluate((wanted) => {
    const items = Array.from(document.querySelectorAll(".item"));
    const hit = items.find((el) => (el.querySelector(".item-title")?.textContent ?? "").trim().endsWith(wanted));
    if (!hit) return false;
    hit.click();
    return true;
  }, title);
  await page.waitForTimeout(700);
  if (!ok) throw new Error(`項目が見つかりません: ${title}`);
};
const itemCount = () => page.locator(".item").count();

// ===========================================================================
// ① .docx（見出し / 太字 / 箇条書き / 表 / 画像）
// ===========================================================================
await importFiles(`${fixtures}/ext.docx`);
const docTitles = await page.$$eval(".item .item-title", (els) => els.map((e) => e.textContent.trim()));
check("docx を取り込むと文書が増える", docTitles.some((t) => t.includes("外部文書の見出し")), docTitles.join(" / "));

await openDoc("外部文書の見出し");
const docHtml = await page.$eval(".content", (el) => el.innerHTML);
check("docx: 見出しが h1 になる", docHtml.includes("<h1>") && docHtml.includes("外部文書の見出し"));
check("docx: 太字が strong になる", /<strong>太字の強調<\/strong>/.test(docHtml));
check("docx: 箇条書きが li になる", (docHtml.match(/<li>/g) ?? []).length >= 2);
check("docx: 表がテキストとして入る", docHtml.includes("りんご") && docHtml.includes("120"));
const docImg = await page.$eval(".content img", (el) => el.getAttribute("src") ?? "").catch(() => "");
check("docx: 埋め込み画像を data URI で取り込む", docImg.startsWith("data:image/png;base64,"), `${docImg.slice(0, 24)}…`);

// ===========================================================================
// ② .xlsx（複数シート / 数式 / 共有文字列）
// ===========================================================================
await importFiles(`${fixtures}/ext.xlsx`);
const sheetTitles = await page.$$eval(".item .item-title", (els) => els.map((e) => e.textContent.trim()));
check(
  "xlsx: シートごとに文書ができる",
  sheetTitles.some((t) => t.includes("売上")) && sheetTitles.some((t) => t.includes("メモ")),
  sheetTitles.filter((t) => t.includes("ext")).join(" / "),
);

await openDoc("売上");
const cell = async (ref) => (await page.textContent(`[data-cell="${ref}"]`))?.trim() ?? "";
check("xlsx: 数値が入る", (await cell("A1")) === "10", await cell("A1"));
check("xlsx: 共有文字列が入る", (await cell("B2")) === "りんご", await cell("B2"));
check("xlsx: 数式が評価される（SUM）", (await cell("A3")) === "30", await cell("A3"));
check("xlsx: 数式が評価される（乗算）", (await cell("C2")) === "20", await cell("C2"));

await openDoc("メモ");
check("xlsx: 2 枚目のシートも取り込む", (await cell("A1")).includes("2 枚目のシート"), await cell("A1"));

// ===========================================================================
// ③ .csv（引用符・カンマ・改行入りセル）
// ===========================================================================
await importFiles(`${fixtures}/sales.csv`);
await openDoc("sales");
check("csv: 見出し行が入る", (await cell("A1")) === "名前", await cell("A1"));
check("csv: 引用符内のカンマを保持", (await cell("A2")) === "山田, 太郎", await cell("A2"));
check("csv: 行が続く", (await cell("B3")) === "3400", await cell("B3"));

// ===========================================================================
// ④ .pptx（2 枚 / 画像つきスライド）
// ===========================================================================
await importFiles(`${fixtures}/deck.pptx`);
await openDoc("deck");
const thumbs = await page.locator(".thumb").count();
check("pptx: スライド枚数が一致", thumbs === 2, `${thumbs} 枚`);
const firstTitle = await page.inputValue(".s-title");
check("pptx: タイトルと本文を取り込む", firstTitle.includes("外部スライド 1"), firstTitle);
const body = await page.inputValue(".s-body");
check("pptx: 本文の行を保持", body.includes("1 行目の本文") && body.includes("2 行目の本文"));

await page.click(".thumb >> nth=1");
await page.waitForTimeout(300);
const slideImg = await page.$eval(".preview-img", (el) => el.getAttribute("src") ?? "").catch(() => "");
check("pptx: スライド画像を data URI で取り込む", slideImg.startsWith("data:image/png"), `${slideImg.slice(0, 24)}…`);

// ===========================================================================
// ⑤ 画像 / 動画 / リンクの挿入（文書エディタ）
// ===========================================================================
await page.click('.create[data-kind="doc"]');
await page.waitForSelector(".content");
await page.fill("input.title", "挿入テスト");
await page.click(".content");
await page.keyboard.type("前置きのテキスト。");
await page.waitForTimeout(900);

// 画像
await page.setInputFiles('.toolbar input[accept*="image/"]', `${fixtures}/pic.png`);
await page.waitForTimeout(700);
const inserted = await page.$eval(".content img", (el) => el.getAttribute("src") ?? "").catch(() => "");
check("画像を挿入できる", inserted.startsWith("data:image/png;base64,"), `${inserted.slice(0, 24)}…`);

// 動画（WebM の最小ヘッダで OK。表示要素が入ることが確認できれば十分）
const videoBytes = Buffer.concat([
  Buffer.from([0x1a, 0x45, 0xdf, 0xa3]), // EBML ヘッダ
  Buffer.alloc(256, 0),
]);
await page.setInputFiles(
  '.toolbar input[accept*="video/"]',
  { name: "clip.webm", mimeType: "video/webm", buffer: videoBytes },
);
await page.waitForTimeout(700);
const videoSrc = await page.$eval(".content video", (el) => el.getAttribute("src") ?? "").catch(() => "");
check("動画を挿入できる", videoSrc.startsWith("data:video/webm;base64,"), `${videoSrc.slice(0, 26)}…`);

// リンク
await page.click('.toolbar button[title="リンク"]');
await page.waitForSelector(".linkpanel");
await page.fill('.linkpanel input[aria-label="表示テキスト"]', "Poccham のサイト");
await page.fill('.linkpanel input[aria-label="リンク先 URL"]', "example.com/docs");
await page.click(".linkpanel button.primary");
await page.waitForTimeout(600);
const anchor = await page.$eval(".content a", (el) => ({ href: el.getAttribute("href"), text: el.textContent })).catch(() => null);
check(
  "リンクを挿入できる（スキーム補完つき）",
  anchor?.href === "https://example.com/docs" && anchor?.text === "Poccham のサイト",
  JSON.stringify(anchor),
);

// 保存されているか（自動保存 → 再読込）
await page.waitForTimeout(1200);
const savedHtml = await page.evaluate(async () => {
  const db = await new Promise((resolve, reject) => {
    const req = indexedDB.open("sarashina-suite");
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
  const store = db.transaction("documents", "readonly").objectStore("documents");
  const all = await new Promise((resolve, reject) => {
    const req = store.getAll();
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
  db.close();
  return all.map((d) => d.content ?? "").join("\n");
});
check("挿入内容が保存される", savedHtml.includes("<video") && savedHtml.includes("example.com/docs"));

// ===========================================================================
// ⑥ 書き出した .docx を再取り込み（往復）
// ===========================================================================
await page.selectOption('select[aria-label="ファイル形式"]', "docx");
const [download] = await Promise.all([
  page.waitForEvent("download", { timeout: 15000 }),
  page.click("text=ダウンロード"),
]);
const dlPath = `${fixtures}/roundtrip.docx`;
const fs = await import("node:fs");
fs.copyFileSync(await download.path(), dlPath);
const before = await itemCount();
await importFiles(dlPath);
const after = await itemCount();
const roundTitle = await page.inputValue("input.title");
check(
  "書き出した .docx を再取り込みできる",
  after === before + 1 && roundTitle === "挿入テスト",
  `${before} → ${after} 件 / ${roundTitle}`,
);
const roundText = await page.innerText(".content");
check("往復しても本文が残る", roundText.includes("前置きのテキスト"), JSON.stringify(roundText.slice(0, 30)));
const roundImg = await page.$eval(".content img", (el) => el.getAttribute("src") ?? "").catch(() => "");
check("往復しても画像が残る", roundImg.startsWith("data:image/png"), `${roundImg.slice(0, 24)}…`);

// ===========================================================================
// ⑦ スライド画像 → .pptx 書き出し（OOXML に ppt/media が入るか）
// ===========================================================================
await page.click('.create[data-kind="slide"]');
await page.waitForSelector(".s-title");
await page.fill(".s-title", "画像つきスライド");
await page.fill(".s-body", "本文つき");
await page.setInputFiles(".imgrow input[type=file]", `${fixtures}/pic.png`);
await page.waitForTimeout(900);
const previewImgs = await page.locator(".preview-img").count();
check("スライドに画像を貼れる", previewImgs === 1, `${previewImgs} 枚`);

await page.selectOption('select[aria-label="ファイル形式"]', "pptx");
const [slideDl] = await Promise.all([
  page.waitForEvent("download", { timeout: 15000 }),
  page.click("text=ダウンロード"),
]);
copyFileSync(await slideDl.path(), `${fixtures}/slide-image.pptx`);
check("画像つきスライドを .pptx で書き出せる", existsSync(`${fixtures}/slide-image.pptx`));

// ===========================================================================
check("コンソールエラーが無い", errors.length === 0, errors.slice(0, 2).join(" | "));

await browser.close();

const passed = results.filter((r) => r.ok).length;
console.log(`\n${passed}/${results.length} checks passed`);
if (passed !== results.length) process.exit(1);
