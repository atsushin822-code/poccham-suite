// プロ向け機能の実ブラウザ検証（文書の書式・表・検索置換 / 表計算の関数と書式 / スライドのメモ）。
//
//   node scripts/pro-e2e.mjs <baseUrl> <outDir>
//
// 生成した .docx / .xlsx / .pptx は outDir に置かれ、OOXML の中身は別途 python で検証できる。
import { readFileSync, mkdirSync } from "node:fs";
const { chromium } = await import(process.env.PLAYWRIGHT_MODULE || "playwright");

const base = process.argv[2] || "http://127.0.0.1:4173/";
const outDir = process.argv[3] || "/home/user/.cache/oox";
mkdirSync(outDir, { recursive: true });

const results = [];
const check = (name, ok, extra = "") => {
  results.push({ name, ok });
  console.log(`${ok ? "PASS" : "FAIL"}  ${name}${extra ? ` — ${extra}` : ""}`);
};

const browser = await chromium.launch();
const ctx = await browser.newContext({ locale: "ja-JP", acceptDownloads: true, viewport: { width: 1600, height: 1000 } });
const page = await ctx.newPage();
const errors = [];
page.on("pageerror", (e) => errors.push(String(e)));
page.on("console", (m) => {
  if (m.type() === "error") errors.push(m.text());
});

async function exportAs(format, fileName) {
  await page.selectOption('select[aria-label="ファイル形式"]', format);
  const [download] = await Promise.all([
    page.waitForEvent("download", { timeout: 15000 }),
    page.click("[data-action=export]"),
  ]);
  const src = await download.path();
  const dest = `${outDir}/${fileName}`;
  (await import("node:fs")).copyFileSync(src, dest);
  return dest;
}

// ── 起動 ────────────────────────────────────────────────────────────────────
await page.goto(base, { waitUntil: "networkidle" });
await page.waitForSelector(".setup input", { timeout: 15000 });
await page.fill(".setup input", "ぽっちゃん");
await page.click(".setup button.primary");
await page.waitForSelector('.create[data-kind="doc"]', { timeout: 15000 });

// ── ① テンプレート ─────────────────────────────────────────────────────────
await page.click("[data-action=templates]");
await page.waitForSelector(".tpl", { timeout: 10000 });
const tplCount = await page.locator(".tpl").count();
check("テンプレートが 5 種類ある", tplCount === 5, `${tplCount} 件`);
await page.click('[data-template="report"]');
await page.waitForTimeout(600);
const reportTitle = await page.locator(".doc-page input.title").inputValue();
check("テンプレートから文書を作れる", reportTitle.includes("週次報告書"), reportTitle);

const hasTable = await page.locator('.content table.tbl').count();
check("テンプレートの表が表として入る", hasTable >= 1, `${hasTable} 個`);

// ── ② 文書: 段落スタイル / 検索置換 / 表 / 印刷設定 ─────────────────────────
await page.click('.content h2 >> nth=0');
await page.selectOption('select[aria-label="段落スタイル"]', "h3");
const h3Count = await page.locator(".content h3").count();
check("段落スタイルを変更できる（見出し 2 → 見出し 3）", h3Count >= 1, `h3=${h3Count}`);

// 検索と置換
await page.click('.toolbar button[title="検索"]');
await page.waitForSelector(".findpanel", { timeout: 10000 });
await page.fill('.findpanel input[aria-label="検索"]', "タスク");
await page.waitForTimeout(250);
const foundText = (await page.locator(".findpanel .found").innerText()).trim();
check("検索で一致件数が出る", /\d+\/\d+/.test(foundText), foundText);

await page.fill('.findpanel input[aria-label="置換後の文字列"]', "作業項目");
await page.click(".findpanel button.primary"); // 置換
await page.waitForTimeout(300);
const bodyText = await page.locator(".content").innerText();
check("置換が本文に反映される", bodyText.includes("作業項目"), bodyText.slice(0, 40).replace(/\n/g, " "));

// アウトライン
await page.click('.toolbar button[title="アウトライン"]');
await page.waitForTimeout(200);
const outlineItems = await page.locator(".outline-item").count();
check("アウトラインに見出しが並ぶ", outlineItems >= 3, `${outlineItems} 件`);

// ページ設定（A4 / 余白）
const pageWidth = await page.locator(".doc-page").evaluate((el) => el.getBoundingClientRect().width);
check("A4 の紙面幅で表示される（約 794px）", pageWidth > 700 && pageWidth < 900, `${Math.round(pageWidth)}px`);

await page.waitForTimeout(1200);
const docxPath = await exportAs("docx", "pro-report.docx");
const docxZip = readFileSync(docxPath);
check(".docx を書き出せる", docxZip.length > 3000, `${docxZip.length} bytes`);

// ── ③ 表計算: 関数・表示形式・並べ替え・行固定 ──────────────────────────────
await page.click("[data-action=templates]");
await page.waitForSelector(".tpl");
await page.click('[data-template="budget"]');
await page.waitForSelector('[data-cell="A1"]', { timeout: 15000 });

const cellText = async (ref) => (await page.locator(`[data-cell="${ref}"]`).innerText()).trim();
const b6 = await cellText("B6");
const d3 = await cellText("D3");
check("SUM が効く（予算合計）", b6 === "1930000", `B6=${b6}`);
check("差異の数式が効く（予算 − 実績）", d3 === "-60000", `D3=${d3}`);
const e6 = await cellText("E6");
check("達成率の数式が効く", Math.abs(Number(e6.replace(/,/g, "")) - 0.9772) < 0.01, `E6=${e6}`);

// 表示形式（パーセント）を適用
await page.click('[data-cell="E6"]');
await page.selectOption('select[aria-label="表示形式"]', "0%");
await page.waitForTimeout(300);
const e6pct = await cellText("E6");
check("表示形式（パーセント）が反映される", e6pct.includes("%"), e6pct);

// 範囲選択で合計などの集計が出る
await page.click('[data-cell="B2"]');
await page.locator('[data-cell="C5"]').click({ modifiers: ["Shift"] });
await page.waitForTimeout(200);
const foot = await page.locator(".foot").innerText();
check("範囲選択で合計・平均が出る", foot.includes("合計") && foot.includes("平均"), foot.replace(/\n/g, " / ").slice(0, 60));

// 並べ替え（費目列を昇順）
await page.click('[data-cell="A1"]');
await page.locator('[data-cell="A5"]').click({ modifiers: ["Shift"] });
await page.click('.sheet-shell button[title="昇順に並べ替え"]');
await page.waitForTimeout(300);
const firstSorted = await cellText("A2");
check("並べ替えができる", ["交通費", "人件費", "外注費", "広告費"].includes(firstSorted) && firstSorted !== "人件費", `A2=${firstSorted}`);

// 行の固定
const freezeOn = await page.locator('.sheet-shell button[title="見出し行を固定"]').getAttribute("class");
check("行の固定を切り替えられる", freezeOn !== null, freezeOn ?? "");

await page.waitForTimeout(1200);
const xlsxPath = await exportAs("xlsx", "pro-budget.xlsx");
check(".xlsx を書き出せる", readFileSync(xlsxPath).length > 2000, `${readFileSync(xlsxPath).length} bytes`);

// ── ④ スライド: レイアウト・メモ・複製 ──────────────────────────────────────
await page.click("[data-action=templates]");
await page.waitForSelector(".tpl");
await page.click('[data-template="proposal"]');
await page.waitForSelector(".s-title", { timeout: 15000 });

const thumbs = await page.locator(".thumb").count();
check("提案資料テンプレートが 5 枚で入る", thumbs === 5, `${thumbs} 枚`);

// 2 枚目（課題）を開いてメモとレイアウトを設定
await page.click('.thumb >> nth=1');
await page.waitForTimeout(200);
await page.selectOption('select[aria-label="レイアウト"]', "twoCol");
await page.fill(".s-notes", "最初の 3 分で課題の数字を説明する。");
await page.selectOption('select[aria-label="画面切り替え効果"]', "fade");
await page.waitForTimeout(400);

const layoutValue = await page.locator('select[aria-label="レイアウト"]').inputValue();
check("レイアウトを変更できる（2 列）", layoutValue === "twoCol", layoutValue);

await page.click("[data-action=add-slide]");
await page.waitForTimeout(200);
await page.click('.thumb >> nth=2');
await page.click('button[title="複製"]');
await page.waitForTimeout(300);
const thumbsAfter = await page.locator(".thumb").count();
check("スライドを複製できる", thumbsAfter === 7, `${thumbsAfter} 枚`);

// 再読み込みしてもメモ・レイアウトが残る
await page.waitForTimeout(1400);
await page.reload({ waitUntil: "networkidle" });
await page.waitForSelector(".item", { timeout: 15000 });
await page.click("text=提案資料");
await page.waitForSelector(".s-title", { timeout: 15000 });
await page.click('.thumb >> nth=1');
await page.waitForTimeout(300);
const notesAfter = await page.locator(".s-notes").inputValue();
const layoutAfter = await page.locator('select[aria-label="レイアウト"]').inputValue();
check("発表者メモが保存される", notesAfter.includes("最初の 3 分"), notesAfter.slice(0, 30));
check("レイアウトが保存される", layoutAfter === "twoCol", layoutAfter);

await page.waitForTimeout(1200);
const pptxPath = await exportAs("pptx", "pro-proposal.pptx");
check(".pptx を書き出せる", readFileSync(pptxPath).length > 8000, `${readFileSync(pptxPath).length} bytes`);

// ── ⑤ 製品情報ダイアログ ────────────────────────────────────────────────────
await page.click("[data-action=about]");
await page.waitForSelector(".about", { timeout: 10000 });
const aboutText = await page.locator(".about").innerText();
check("製品情報にバージョンとライセンスが出る", aboutText.includes("Personal Edition") && aboutText.includes("Proprietary"));
check("キーボードショートカットが載っている", aboutText.includes("Ctrl") && aboutText.includes("保存"));
await page.keyboard.press("Escape");
await page.waitForTimeout(200);
check("Esc でダイアログを閉じられる", (await page.locator(".about").count()) === 0);

check("コンソール/ページエラーなし（プロ機能）", errors.length === 0, errors.slice(0, 3).join(" | "));

await browser.close();
const failed = results.filter((r) => !r.ok);
console.log(`\n${results.length - failed.length}/${results.length} checks passed`);
process.exit(failed.length ? 1 : 0);
