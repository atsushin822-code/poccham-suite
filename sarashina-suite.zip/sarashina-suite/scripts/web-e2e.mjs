// Web 版（静的ビルド）の実ブラウザ検証。
//   node web-e2e.mjs <baseUrl>
// 検証項目:
//   1) 起動してワークスペースが出る（Web 版はオンボーディングを飛ばす）
//   2) 文書を作成 → 本文入力 → 自動保存 → リロード後も残る（IndexedDB）
//   3) AI パネルが「Web 版では使えない」案内になる
//   4) 検索が動く
// playwright は devDependency に含めていない（任意）。未インストールなら:
//   npm i -D playwright && npx playwright install chromium
import { readFileSync } from "node:fs";
const { chromium } = await import(process.env.PLAYWRIGHT_MODULE || "playwright");

const base = process.argv[2] || "http://127.0.0.1:4173/";
const results = [];
const check = (name, ok, extra = "") => {
  results.push({ name, ok, extra });
  console.log(`${ok ? "PASS" : "FAIL"}  ${name}${extra ? ` — ${extra}` : ""}`);
};

const browser = await chromium.launch();
const ctx = await browser.newContext({ locale: "ja-JP" });
const page = await ctx.newPage();
const errors = [];
page.on("pageerror", (e) => errors.push(String(e)));
page.on("console", (m) => { if (m.type() === "error") errors.push(m.text()); });

await page.goto(base, { waitUntil: "networkidle" });

// 0) 初回起動: 名前を入れるセットアップ画面（透かし文字は出さない）
await page.waitForSelector(".setup input", { timeout: 15000 });
const placeholderCount = await page.locator("[placeholder]").count();
check("入力欄に透かし文字（placeholder）が無い", placeholderCount === 0, `${placeholderCount} 個`);
await page.fill(".setup input", "ぽっちゃん");
await page.click(".setup button.primary");
await page.waitForSelector('.create[data-kind="doc"]', { timeout: 15000 });
const greet = await page.locator("aside").innerText();
check("名前を入れると挨拶に出る", greet.includes("ぽっちゃん"), greet.split("\n").slice(0, 3).join(" / "));

// 1) ワークスペース表示（サイドバーの「＋ 文書」が出る）
check("起動してワークスペースが表示される", true);

// 初期シード文書が 2 件ある
const seeded = await page.locator(".item").count();
check("初回起動でサンプル文書が入っている", seeded >= 2, `${seeded} 件`);

// 2) 文書作成 → 入力 → 自動保存
await page.click('.create[data-kind="doc"]');
await page.waitForTimeout(300);
await page.fill('input.title', "Web版テスト文書");
await page.click('[contenteditable="true"]');
await page.keyboard.type("これはブラウザで入力した本文です。");
await page.waitForTimeout(1600); // AUTOSAVE_MS 待ち
await page.reload({ waitUntil: "networkidle" });
await page.waitForSelector('.create[data-kind="doc"]');
const titles = await page.locator(".item .title, .item").allInnerTexts();
const found = titles.some((t) => t.includes("Web版テスト文書"));
check("作成した文書がリロード後も残る（IndexedDB 永続化）", found, found ? "" : `見出し一覧: ${JSON.stringify(titles.slice(0, 6))}`);

// 本文も残っているか
await page.click("text=Web版テスト文書");
await page.waitForTimeout(400);
const body = await page.locator('[contenteditable="true"]').innerText();
check("本文が保存されている", body.includes("ブラウザで入力した本文"), body.slice(0, 40));

// 3) AI パネル（既定で開いている）
if (await page.locator("text=AI を表示").count()) {
  await page.click("text=AI を表示");
}
await page.waitForSelector("text=Poccham AI");
const panel = await page.locator("section").last().innerText();
check("AI パネルが Web 版向けの案内になる", panel.includes("Web 版ではローカル AI 推論を実行できません"));
check("「モデルをセットアップ」ボタンは出ない", !panel.includes("モデルをセットアップ"));

// 4) 検索
await page.fill('input[aria-label="全文検索"]', "ブラウザ");
await page.waitForTimeout(600);
const hits = await page.locator("text=検索結果").count();
const searchText = await page.locator("aside").innerText();
check("検索が動作する", hits > 0 && searchText.includes("Web版テスト文書"), hits ? "" : "検索結果が出ない");

// 5) 書き出し（Markdown ダウンロード）
await page.click("text=Web版テスト文書");
await page.waitForTimeout(300);
await page.selectOption('select[aria-label="ファイル形式"]', "md");
const [download] = await Promise.all([
  page.waitForEvent("download", { timeout: 10000 }),
  page.click("[data-action=export]"),
]);
const fname = download.suggestedFilename();
const saved = await download.path();
const content = saved ? (await import("node:fs")).readFileSync(saved, "utf8") : "";
// NOTE: headless Chromium は日本語ファイル名を "download" に落とすことがあるため、
// 名前ではなく「Markdown として中身が正しいか」で検証する
check(
  "書き出し（Markdown）がダウンロードされる",
  content.includes("ブラウザで入力した本文"),
  `name=${fname} bytes=${content.length}`,
);

// 6) 統合①: スプレッドシート（種別を選んで新規作成 → 数式 → 永続化）
const createButtons = await page.locator(".create[data-kind]").count();
check("サイドバーに 3 種の新規作成ボタンがある（文書/表計算/スライド）", createButtons === 3, `${createButtons} 個`);
const importButton = await page.locator(".importrow input[type=file]").count();
check("サイドバーに取り込みボタンがある", importButton === 1, `${importButton} 個`);

await page.click('.create[data-kind="sheet"]');
await page.waitForSelector('[data-cell="A1"]', { timeout: 10000 });
check("表計算エディタが開く（グリッド表示）", true);
await page.fill('.sheet-shell input.title', "E2E表計算");

async function typeCell(ref, text) {
  await page.dblclick(`[data-cell="${ref}"]`);
  await page.keyboard.type(text);
  await page.keyboard.press("Enter");
  await page.waitForTimeout(80);
}
await typeCell("A1", "10");
await typeCell("A2", "20");
await typeCell("A3", "=A1+A2");
const a3 = (await page.locator('[data-cell="A3"]').innerText()).trim();
check("数式 =A1+A2 が 30 と計算される", a3 === "30", `A3="${a3}"`);

// 数式バーから SUM を入力（B1）
await page.click('[data-cell="B1"]');
await page.fill('input[aria-label="値または数式"]', "=SUM(A1:A3)");
await page.waitForTimeout(200);
const b1 = (await page.locator('[data-cell="B1"]').innerText()).trim();
check("数式バーからの =SUM(A1:A3) が 60 と計算される", b1 === "60", `B1="${b1}"`);

await page.waitForTimeout(1400); // AUTOSAVE_MS 待ち
await page.reload({ waitUntil: "networkidle" });
// ピン留めされたシード文書が開くので、作成した表計算を選び直す
await page.click("text=E2E表計算");
await page.waitForSelector('[data-cell="A1"]', { timeout: 15000 });
const a3after = (await page.locator('[data-cell="A3"]').innerText()).trim();
const b1after = (await page.locator('[data-cell="B1"]').innerText()).trim();
check(
  "表計算がリロード後も残る（数式・計算結果とも）",
  a3after === "30" && b1after === "60",
  `A3="${a3after}" B1="${b1after}"`,
);

await page.screenshot({ path: "docs/web-preview-sheet.png" });

// 表計算も書き出せる（値はタブ / | 区切りで読める形になる）
await page.selectOption('select[aria-label="ファイル形式"]', "md");
const [sheetDl] = await Promise.all([
  page.waitForEvent("download", { timeout: 10000 }),
  page.click("[data-action=export]"),
]);
const sheetMd = readFileSync(await sheetDl.path(), "utf8");
check(
  "表計算を Markdown で書き出せる（値が並ぶ）",
  sheetMd.includes("10") && sheetMd.includes("60"),
  JSON.stringify(sheetMd.slice(0, 60)),
);

// 7) 統合②: スライド（追加・見出し・本文・枚数）
await page.click('.create[data-kind="slide"]');
await page.waitForSelector('input[aria-label="見出し"]', { timeout: 10000 });
check("スライドエディタが開く（サムネイル + プレビュー）", true);
await page.fill('.slide-shell input.title', "E2Eスライド");
await page.fill('input[aria-label="見出し"]', "統合テストのスライド");
await page.fill('textarea[aria-label="本文"]', "1 つ目の項目\n2 つ目の項目");
await page.waitForTimeout(200);
const previewText = await page.locator(".preview").innerText();
check("プレビューが見出しと本文を反映する", previewText.includes("統合テストのスライド") && previewText.includes("2 つ目の項目"));
await page.click("[data-action=add-slide]");
await page.waitForTimeout(200);
const thumbs = await page.locator(".thumb").count();
check("スライドを追加すると 2 枚になる", thumbs === 2, `${thumbs} 枚`);
await page.waitForTimeout(1400);
await page.reload({ waitUntil: "networkidle" });
await page.click("text=E2Eスライド");
await page.waitForSelector(".thumb", { timeout: 15000 });
const thumbsAfter = await page.locator(".thumb").count();
const slideItem = await page.locator("aside .item").allInnerTexts();
check(
  "スライドがリロード後も残る（2 枚）",
  thumbsAfter === 2 && slideItem.some((t) => t.includes("E2Eスライド")),
  `${thumbsAfter} 枚`,
);

await page.screenshot({ path: "docs/web-preview-slide.png" });

// 8) 種別バッジ: 一覧に 3 種が並ぶ
const kindBadges = await page.locator(".kind").count();
check("一覧に種別アイコンが出る", kindBadges >= 3, `${kindBadges} 個`);

// コンソールエラーなし
check("コンソール/ページエラーなし", errors.length === 0, errors.slice(0, 3).join(" | "));

await page.screenshot({ path: "docs/web-preview.png", fullPage: false });

// 6) ?demo=1（インメモリのモック）も動く
const demoPage = await ctx.newPage();
await demoPage.goto(`${base}?demo=1`, { waitUntil: "networkidle" });
// デモ（インメモリ）は設定が空なので、名前セットアップから始まる
await demoPage.waitForSelector(".setup input", { timeout: 15000 });
await demoPage.fill(".setup input", "デモ");
await demoPage.click(".setup button.primary");
await demoPage.waitForSelector('.create[data-kind="doc"]', { timeout: 15000 });
const demoText = await demoPage.locator("body").innerText();
check("?demo=1 のモックモードも起動する", demoText.includes("デモ"), demoText.slice(0, 60).replace(/\n/g, " / "));
await demoPage.close();

await browser.close();

const failed = results.filter((r) => !r.ok);
console.log(`\n${results.length - failed.length}/${results.length} PASS`);
process.exit(failed.length === 0 ? 0 : 1);
