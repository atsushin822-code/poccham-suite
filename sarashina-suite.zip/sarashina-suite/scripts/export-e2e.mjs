// ネイティブ形式の書き出し（.docx / .xlsx / .pptx / .poccham）、プレゼン、多言語の実ブラウザ検証。
//
//   node scripts/export-e2e.mjs <baseUrl> <outDir>
//
// 生成したファイルは outDir に保存される（OOXML の中身は python 側で検証できる）。
import { readFileSync, mkdirSync } from "node:fs";
const { chromium } = await import(process.env.PLAYWRIGHT_MODULE || "playwright");

const base = process.argv[2] || "http://127.0.0.1:4173/";
const outDir = process.argv[3] || "/home/user/.cache/oox";
mkdirSync(outDir, { recursive: true });

const results = [];
const check = (name, ok, extra = "") => {
  results.push({ name, ok });
  console.log(`${ok ? "PASS" : "FAIL"}  ${name}${extra ? ` — ${extra}` : ""}`);
};

const browser = await chromium.launch();

/** 初回セットアップ（名前入力）を通してワークスペースまで進む */
async function boot(page) {
  await page.goto(base, { waitUntil: "networkidle" });
  await page.waitForSelector(".setup input", { timeout: 15000 });
  await page.fill(".setup input", "ぽっちゃん");
  await page.click(".setup button.primary");
  await page.waitForSelector('.create[data-kind="doc"]', { timeout: 15000 });
}

/** 現在のドキュメントを指定形式で書き出し、outDir に保存する */
async function exportAs(page, format, fileName) {
  await page.selectOption('select[aria-label="ファイル形式"]', format);
  const [download] = await Promise.all([
    page.waitForEvent("download", { timeout: 15000 }),
    page.click("text=ダウンロード"),
  ]);
  const src = await download.path();
  const dest = `${outDir}/${fileName}`;
  const fs = await import("node:fs");
  fs.copyFileSync(src, dest);
  return { path: dest, bytes: readFileSync(dest).length };
}

// ===========================================================================
// ① 文書 → .docx / .md / .txt / .html
// ===========================================================================
{
  const ctx = await browser.newContext({ locale: "ja-JP", acceptDownloads: true });
  const page = await ctx.newPage();
  const errors = [];
  page.on("pageerror", (e) => errors.push(String(e)));
  page.on("console", (m) => {
    if (m.type() === "error") errors.push(m.text());
  });

  await boot(page);
  await page.click('.create[data-kind="doc"]');
  await page.waitForSelector('input.title');
  await page.fill("input.title", "Poccham 文書テスト");
  await page.click('[contenteditable="true"]');
  await page.keyboard.type("1 行目の本文です。");
  await page.keyboard.press("Enter");
  await page.keyboard.type("2 行目の本文です。");
  await page.waitForTimeout(1200);

  const docx = await exportAs(page, "docx", "doc.docx");
  check("文書を .docx で書き出せる", docx.bytes > 1000, `${docx.bytes} bytes`);

  const md = await exportAs(page, "md", "doc.md");
  const mdText = readFileSync(md.path, "utf8");
  check("文書を .md で書き出せる", mdText.includes("1 行目の本文です"), JSON.stringify(mdText.slice(0, 40)));

  const txt = await exportAs(page, "txt", "doc.txt");
  check("文書を .txt で書き出せる", readFileSync(txt.path, "utf8").includes("2 行目の本文です"));

  const html = await exportAs(page, "html", "doc.html");
  check("文書を .html で書き出せる", readFileSync(html.path, "utf8").includes("<html"));

  // -------------------------------------------------------------------------
  // ② 表計算 → .xlsx
  // -------------------------------------------------------------------------
  await page.click('.create[data-kind="sheet"]');
  await page.waitForSelector('[data-cell="A1"]');
  await page.fill(".sheet-shell input.title", "Poccham 表計算テスト");
  const typeCell = async (ref, text) => {
    await page.dblclick(`[data-cell="${ref}"]`);
    await page.keyboard.type(text);
    await page.keyboard.press("Enter");
    await page.waitForTimeout(60);
  };
  await typeCell("A1", "10");
  await typeCell("A2", "20");
  await typeCell("A3", "=SUM(A1:A2)");
  await page.waitForTimeout(1200);
  const xlsx = await exportAs(page, "xlsx", "sheet.xlsx");
  check("表計算を .xlsx で書き出せる", xlsx.bytes > 800, `${xlsx.bytes} bytes`);

  // -------------------------------------------------------------------------
  // ③ スライド → .pptx ＆ プレゼン
  // -------------------------------------------------------------------------
  await page.click('.create[data-kind="slide"]');
  await page.waitForSelector('input[aria-label="見出し"]');
  await page.fill(".slide-shell input.title", "Poccham スライドテスト");
  await page.fill('input[aria-label="見出し"]', "1 枚目の見出し");
  await page.fill('textarea[aria-label="本文"]', "箇条書き 1\\n箇条書き 2");
  await page.click("text=＋ 追加");
  await page.fill('input[aria-label="見出し"]', "2 枚目の見出し");
  await page.fill('textarea[aria-label="本文"]', "2 枚目の本文");
  await page.waitForTimeout(1400);

  const pptx = await exportAs(page, "pptx", "slides.pptx");
  check("スライドを .pptx で書き出せる", pptx.bytes > 1500, `${pptx.bytes} bytes`);

  // プレゼンテーション（全画面）: 開く → 次へ → Esc で閉じる
  await page.click("text=スライドショー");
  await page.waitForSelector(".present", { timeout: 5000 });
  const first = await page.locator(".present h1").innerText();
  await page.keyboard.press("ArrowRight");
  await page.waitForTimeout(200);
  const second = await page.locator(".present h1").innerText();
  check(
    "プレゼンが全画面で開き ←/→ で移動できる",
    first.includes("1 枚目の見出し") && second.includes("2 枚目の見出し"),
    `${first} → ${second}`,
  );
  await page.keyboard.press("Escape");
  await page.waitForTimeout(300);
  check("Esc でプレゼンを終了できる", (await page.locator(".present").count()) === 0);

  // -------------------------------------------------------------------------
  // ④ 統合ネイティブ形式 .poccham
  // -------------------------------------------------------------------------
  const poccham = await exportAs(page, "poccham", "suite.poccham");
  const data = JSON.parse(readFileSync(poccham.path, "utf8"));
  const kinds = new Set(data.documents.map((d) => d.kind));
  check(
    ".poccham に文書・表計算・スライドがすべて入る",
    data.format === "poccham" && kinds.has("doc") && kinds.has("sheet") && kinds.has("slide"),
    `${data.documents.length} 件 / ${[...kinds].join(",")}`,
  );

  check("コンソールエラーなし（書き出し一連）", errors.length === 0, errors.slice(0, 3).join(" | "));
  await ctx.close();
}

// ===========================================================================
// ⑤ 多言語: システム言語（en-US）に追従する
// ===========================================================================
{
  const ctx = await browser.newContext({ locale: "en-US", acceptDownloads: true });
  const page = await ctx.newPage();
  await page.goto(base, { waitUntil: "networkidle" });
  await page.waitForSelector(".setup input", { timeout: 15000 });
  const setupText = await page.locator(".setup").innerText();
  check(
    "システム言語が英語なら UI も英語になる",
    setupText.includes("What should we call you?") && setupText.includes("Get started"),
    setupText.split("\n").slice(1, 3).join(" / "),
  );
  await page.fill(".setup input", "Poccham");
  await page.click(".setup button.primary");
  await page.waitForSelector('.create[data-kind="doc"]', { timeout: 15000 });
  const aside = await page.locator("aside").innerText();
  check("英語 UI のサイドバーが出る", aside.includes("Document") && aside.includes("Spreadsheet"), aside.split("\n").slice(1, 4).join(" / "));

  // 設定画面で日本語へ切り替えられる
  await page.click("aside .footer button.ghost");
  await page.waitForSelector(".settings");
  await page.selectOption('.settings select[aria-label="Language"]', "ja");
  await page.waitForTimeout(300);
  const settingsJa = await page.locator(".settings").innerText();
  check("設定から言語を切り替えられる（英語 → 日本語）", settingsJa.includes("設定") && settingsJa.includes("プロフィール"), settingsJa.split("\n").slice(0, 3).join(" / "));
  await ctx.close();
}

await browser.close();

const failed = results.filter((r) => !r.ok);
console.log(`\n${results.length - failed.length}/${results.length} PASS`);
process.exit(failed.length === 0 ? 0 : 1);
