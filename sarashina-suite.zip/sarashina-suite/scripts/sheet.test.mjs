// 表計算エンジンの単体テスト（ブラウザ不要）。
//   node scripts/sheet.test.mjs
// 内部で esbuild を使って src/lib/sheet.ts を一時的に ESM へ変換してから読み込む。
import { execFileSync } from "node:child_process";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";

const outDir = mkdtempSync(join(tmpdir(), "poccham-sheet-"));
const outFile = join(outDir, "sheet.mjs");
execFileSync("npx", ["esbuild", "src/lib/sheet.ts", "--bundle", "--format=esm", `--outfile=${outFile}`, "--log-level=warning"], {
  stdio: "inherit",
});
const S = await import(outFile);
process.on("exit", () => rmSync(outDir, { recursive: true, force: true }));

const G = (rows) => {
  const cols = Math.max(...rows.map(r => r.length));
  return rows.map(r => Array.from({length: cols}, (_, i) => r[i] ?? ''));
};
const grid = G([
  ['商品','数量','単価','金額'],
  ['りんご', 3, 120, '=B2*C2'],
  ['みかん', 5, 80, '=B3*C3'],
  ['ぶどう', 2, 450, '=B4*C4'],
  ['合計', '=SUM(B2:B4)', '', '=SUM(D2:D4)'],
  ['平均', '=AVERAGE(B2:B4)', '', '=ROUND(AVERAGE(D2:D4),0)'],
  ['最大', '=MAX(D2:D4)', '', '=MIN(D2:D4)'],
  ['', '', '', ''],
  ['条件', '=COUNTIF(B2:B4,">2")', '=SUMIF(B2:B4,">2",D2:D4)', '=IF(D5>2000,"達成","未達")'],
  ['文字', '=LEN("日本語")', '=UPPER("abc")', '=CONCATENATE("a",1,"b")'],
  ['参照', '=VLOOKUP("みかん",A2:D4,4,FALSE)', '=INDEX(B2:B4,2)', '=MATCH("ぶどう",A2:A4,0)'],
  ['日付', '=DATE(2026,11,16)', '=YEAR(B12)', '=MONTH(B12)'],
  ['誤り', '=1/0', '=UNKNOWN(1)', '=SQRT(-1)'],
  ['安全', '=IFERROR(1/0,"ゼロ")', '=ISERROR(1/0)', '=AND(TRUE,1>0)'],
]);

const v = S.evaluateGrid(grid);
let pass = 0, fail = 0;
const eq = (label, got, want) => {
  const ok = got === want;
  ok ? pass++ : fail++;
  console.log(`${ok ? 'ok  ' : 'FAIL'} ${label}: got=${JSON.stringify(got)} want=${JSON.stringify(want)}`);
};
eq('D2 =B2*C2', v[1][3], 360);
eq('B5 SUM', v[4][1], 10);
eq('D5 SUM', v[4][3], 1660);
eq('B6 AVERAGE', v[5][1], 10/3);
eq('D6 ROUND', v[5][3], 553);
eq('B7 MAX', v[6][1], 900);
eq('D7 MIN', v[6][3], 360);
eq('B9 COUNTIF >2', v[8][1], 2);
eq('C9 SUMIF >2', v[8][2], 760);
eq('D9 IF true', v[8][3], '未達');
eq('B10 LEN', v[9][1], 3);
eq('C10 UPPER', v[9][2], 'ABC');
eq('D10 CONCATENATE', v[9][3], 'a1b');
eq('B11 VLOOKUP', v[10][1], 400);
eq('C11 INDEX', v[10][2], 5);
eq('D11 MATCH', v[10][3], 3);
eq('B12 DATE serial', v[11][1], S.dateToSerial(new Date(2026,10,16)));
eq('C12 YEAR', v[11][2], 2026);
eq('D12 MONTH', v[11][3], 11);
eq('B13 DIV/0', v[12][1], '#DIV/0!');
eq('C13 NAME?', v[12][2], '#NAME?');
eq('D13 NUM!', v[12][3], '#NUM!');
eq('B14 IFERROR', v[13][1], 'ゼロ');
eq('C14 ISERROR', v[13][2], true);
eq('D14 AND', v[13][3], true);
eq("E2 範囲外は undefined", v[1][4], undefined);

// 追加の演算子・書式
const g2 = G([
  ['10', '20', '=A1+B1'],
  ['=A1&"点"', '=2^10', '=10%'],
  ['=1<>2', '="a"<"b"', '=IF(A1=10,"yes","no")'],
  ['=SUMPRODUCT(A1:A2,B1:B2)', '=MEDIAN(1,3,5,7)', '=STDEV(2,4,4,4,5,5,7,9)'],
  ['=TODAY()', '=COUNTBLANK(A1:C1)', '=TEXT(1234.567,"#,##0.00")'],
]);
const w = S.evaluateGrid(g2);
eq('C1 加算', w[0][2], 30);
eq('A2 連結', w[1][0], '10点');
eq('B2 べき乗', w[1][1], 1024);
eq('C2 パーセント', w[1][2], 0.1);
eq('A3 <>', w[2][0], true);
eq('B3 文字比較', w[2][1], true);
eq('C3 IF', w[2][2], 'yes');
eq('A4 SUMPRODUCT', w[3][0], 10*20 + 20*0); // A1..A2 = 10, A1&"点" は数値でない
eq('B4 MEDIAN', w[3][1], 4);
eq('C4 STDEV', w[3][2], 2.138089935299395);
eq('A5 TODAY', w[4][0], S.dateToSerial(new Date()));
eq('B5 COUNTBLANK', w[4][1], 0);
eq('C5 TEXT', w[4][2], '1,234.57');

// 循環参照
const cyc = S.evaluateGrid([['=B1','=A1']]);
eq('循環参照', cyc[0][0], '#CYCLE!');

// 書式
eq('format #,##0', S.formatCell(1234567, '#,##0'), '1,234,567');
eq('format 0.00', S.formatCell(3.14159, '0.00'), '3.14');
eq('format 0%', S.formatCell(0.256, '0%'), '26%');
eq('format ¥', S.formatCell(1234.5, '¥#,##0'), '¥1,235');
eq('format date', S.formatCell(S.dateToSerial(new Date(2026,10,16)), 'date'), '2026-11-16');
eq('format general', S.formatCell(0.1+0.2, 'general'), '0.3');

// 参照移動（フィル）
eq('adjustFormula 縦', S.adjustFormula('=SUM(B2:B4)', 1, 0), '=SUM(B3:B5)');
eq('adjustFormula 横', S.adjustFormula('=A1+$B$1', 0, 1), '=B1+$B$1');
eq('adjustFormula 文字列保護', S.adjustFormula('="A1"&A1', 1, 0), '="A1"&A2');

// 範囲集計
eq('summarize', JSON.stringify(S.summarize([[1,2],[3,'x']], {r0:0,c0:0,r1:1,c1:1})), JSON.stringify({count:3,sum:6,average:2,min:1,max:3}));
eq('rectToRef', S.rectToRef({r0:0,c0:0,r1:2,c1:1}), 'A1:B3');
eq('colLabel 26', S.colLabel(26), 'AA');
eq('colIndex AA', S.colIndex('AA'), 26);

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
