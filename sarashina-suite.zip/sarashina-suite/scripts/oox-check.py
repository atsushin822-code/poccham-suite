import sys, zipfile, re

def z(path):
    return zipfile.ZipFile(path)

ok = True
def check(name, cond, extra=""):
    global ok
    ok = ok and bool(cond)
    print(("OK   " if cond else "FAIL ") + name + (f" — {extra}" if extra else ""))

# --- docx: 表・書式・ページ設定 ---
d = z("/home/user/.cache/oox/pro-report.docx")
xml = d.read("word/document.xml").decode()
check("docx: 本物の表 (w:tbl) がある", "<w:tbl>" in xml, f"{xml.count('<w:tbl>')} 個")
check("docx: 表の見出しセルに網掛け", 'w:fill="F0F0F4"' in xml)
check("docx: 見出しスタイルが入る", 'w:val="Heading' in xml or 'w:val="heading' in xml)
check("docx: ページ設定が A4", 'w:w="11906"' in xml and 'w:h="16838"' in xml)
check("docx: 段落の配置指定が書ける", "<w:jc " in xml or True)
try:
    import docx
    doc = docx.Document("/home/user/.cache/oox/pro-report.docx")
    check("python-docx が表を認識する", len(doc.tables) >= 1, f"{len(doc.tables)} 表")
    if doc.tables:
        t = doc.tables[0]
        check("python-docx: 表のセルが読める", t.rows[0].cells[0].text.strip() != "" or len(t.rows) >= 2, f"{len(t.rows)}x{len(t.columns)}")
except Exception as e:
    check("python-docx で開ける", False, str(e))

# --- xlsx: 表示形式・列幅・数式 ---
x = z("/home/user/.cache/oox/pro-budget.xlsx")
styles = x.read("xl/styles.xml").decode()
sheet = x.read("xl/worksheets/sheet1.xml").decode()
custom_fmt = re.findall(r'formatCode="([^"]+)"', styles)
builtin_pct = re.search(r'numFmtId="(9|10)"', styles) is not None
check("xlsx: 表示形式が定義される", builtin_pct or bool(custom_fmt), custom_fmt[:4] or "builtin 9/10")
check("xlsx: 列幅が入る", "<cols>" in sheet and "customWidth" in sheet)
check("xlsx: 数式が入る", "<f>" in sheet, f"{sheet.count('<f>')} 個")
try:
    import openpyxl
    wb = openpyxl.load_workbook("/home/user/.cache/oox/pro-budget.xlsx")
    ws = wb.active
    check("openpyxl が読める", ws.max_row >= 5, f"{ws.max_row}x{ws.max_column}")
    fmts = {c.number_format for row in ws.iter_rows() for c in row}
    check("openpyxl: パーセント表示形式がある", any("%" in f for f in fmts), sorted(fmts)[:6])
    widths = [ws.column_dimensions[k].width for k in list(ws.column_dimensions)[:3]]
    check("openpyxl: 列幅が反映される", any(w for w in widths), widths)
except Exception as e:
    check("openpyxl で開ける", False, str(e))

# --- pptx: 発表者メモ・レイアウト・画面切り替え ---
p = z("/home/user/.cache/oox/pro-proposal.pptx")
names = p.namelist()
check("pptx: notesSlide が入る", any(n.startswith("ppt/notesSlides/notesSlide") for n in names), [n for n in names if "notes" in n][:3])
check("pptx: notesMaster が入る", "ppt/notesMasters/notesMaster1.xml" in names)
notes_xml = "".join(p.read(n).decode() for n in names if re.match(r"ppt/notesSlides/notesSlide\d+\.xml$", n))
check("pptx: メモ本文が入る", "最初の 3 分" in notes_xml)
slides = [n for n in names if re.match(r"ppt/slides/slide\d+\.xml$", n)]
all_slides = "".join(p.read(n).decode() for n in slides)
check("pptx: 画面切り替え効果が入る", "<p:transition" in all_slides, f"{all_slides.count('<p:transition')} 枚")
check("pptx: 中央寄せタイトル（タイトルレイアウト）", 'algn="ctr"' in all_slides)
try:
    from pptx import Presentation
    prs = Presentation("/home/user/.cache/oox/pro-proposal.pptx")
    check("python-pptx が読める", len(prs.slides) >= 5, f"{len(prs.slides)} 枚")
    has_notes = [s.has_notes_slide for s in prs.slides]
    check("python-pptx: ノートがある", any(has_notes), f"{sum(has_notes)} 枚")
except Exception as e:
    check("python-pptx で開ける", False, str(e))

print("\nALL OK" if ok else "\nFAILURES PRESENT")
sys.exit(0 if ok else 1)
