//! フロントエンドへ送るイベント名と、その送信ヘルパ。

use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;

use serde_json::json;
use tauri::{AppHandle, Emitter};

use sarashina_core::download::{DownloadPhase, DownloadProgress, ProgressSink};
use sarashina_core::inference::{EngineStatus, TokenSink};

/// モデルダウンロード進捗
pub const DOWNLOAD_PROGRESS: &str = "download://progress";
/// 推論エンジンの状態変化
pub const ENGINE_STATUS: &str = "engine://status";
/// 生成トークンのストリーミング
pub const LLM_TOKEN: &str = "llm://token";
/// 生成完了（統計付き）
pub const LLM_DONE: &str = "llm://done";
/// 生成エラー
pub const LLM_ERROR: &str = "llm://error";

fn phase_str(phase: DownloadPhase) -> &'static str {
    match phase {
        DownloadPhase::Preparing => "preparing",
        DownloadPhase::Downloading => "downloading",
        DownloadPhase::Verifying => "verifying",
        DownloadPhase::Completed => "completed",
        DownloadPhase::Cancelled => "cancelled",
        DownloadPhase::Failed => "failed",
    }
}

/// ダウンロード進捗をイベントとして流すシンク
pub struct DownloadSink {
    app: AppHandle,
    model_id: String,
    cancel: Arc<AtomicBool>,
    /// `completed` を自分で流すか。
    /// コマンド層は「台帳登録 → エンジンへのロード」が終わってから completed を
    /// 1 回だけ流したいので、core 側の completed は抑止する（二重発火の防止）。
    emit_completed: bool,
}

impl DownloadSink {
    #[allow(dead_code)] // 進捗をそのまま流したい呼び出し元（CLI / テスト）向けの既定コンストラクタ
    pub fn new(app: AppHandle, model_id: impl Into<String>, cancel: Arc<AtomicBool>) -> Self {
        Self { app, model_id: model_id.into(), cancel, emit_completed: true }
    }

    /// core の completed を抑止し、自前で 1 回だけ流す版
    pub fn deferred_completion(app: AppHandle, model_id: impl Into<String>, cancel: Arc<AtomicBool>) -> Self {
        Self { app, model_id: model_id.into(), cancel, emit_completed: false }
    }

    pub fn emit_completed(&self, bytes: u64) {
        let _ = self.app.emit(
            DOWNLOAD_PROGRESS,
            json!({
                "modelId": self.model_id,
                "phase": "completed",
                "downloaded": bytes,
                "total": bytes,
                "bytesPerSec": 0.0,
                "etaSecs": 0,
                "message": null,
            }),
        );
    }

    pub fn emit_error(&self, message: &str) {
        let _ = self.app.emit(
            DOWNLOAD_PROGRESS,
            json!({
                "modelId": self.model_id,
                "phase": "failed",
                "downloaded": 0,
                "total": 0,
                "bytesPerSec": 0.0,
                "etaSecs": null,
                "message": message,
            }),
        );
    }
}

impl ProgressSink for DownloadSink {
    fn progress(&self, p: DownloadProgress) {
        if p.phase == DownloadPhase::Completed && !self.emit_completed {
            return;
        }
        let _ = self.app.emit(
            DOWNLOAD_PROGRESS,
            json!({
                "modelId": self.model_id,
                "phase": phase_str(p.phase),
                "downloaded": p.downloaded,
                "total": p.total,
                "bytesPerSec": p.bytes_per_sec,
                "etaSecs": p.eta_secs,
                "message": p.message,
            }),
        );
    }

    fn cancelled(&self) -> bool {
        self.cancel.load(Ordering::SeqCst)
    }
}

/// 生成トークンをイベントとして流すシンク
pub struct EventTokenSink {
    app: AppHandle,
    request_id: String,
}

impl EventTokenSink {
    pub fn new(app: AppHandle, request_id: impl Into<String>) -> Self {
        Self { app, request_id: request_id.into() }
    }
}

impl TokenSink for EventTokenSink {
    fn on_token(&mut self, delta: &str) {
        let _ = self.app.emit(
            LLM_TOKEN,
            json!({ "requestId": self.request_id, "delta": delta }),
        );
    }
}

/// エンジン状態を手動で流す（設定変更時など）
pub fn emit_engine_status(app: &AppHandle, status: &EngineStatus) {
    let _ = app.emit(ENGINE_STATUS, status.clone());
}
