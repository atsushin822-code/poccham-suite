use serde::Serialize;
use tauri::State;

use sarashina_core::catalog;
use sarashina_core::db::{DbStats, Database};
use sarashina_core::error::{CoreError, Result};
use sarashina_core::inference::BACKEND_NAME;

use super::blocking;
use crate::state::AppState;

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct AppInfo {
    pub version: String,
    pub backend: String,
    pub platform: String,
    pub data_dir: String,
    pub db_path: String,
    pub models_dir: String,
    pub cache_dir: String,
    pub active_model_id: Option<String>,
    pub recommended_model_id: String,
}

#[tauri::command]
pub async fn app_info(state: State<'_, AppState>) -> Result<AppInfo> {
    let paths = state.paths.clone();
    let db: std::sync::Arc<Database> = state.db.clone();
    let active = blocking(move || db.get_setting("active_model_id")).await?;
    Ok(AppInfo {
        version: env!("CARGO_PKG_VERSION").to_string(),
        backend: BACKEND_NAME.to_string(),
        platform: std::env::consts::OS.to_string(),
        data_dir: paths.data_dir.clone(),
        db_path: paths.db_path.clone(),
        models_dir: paths.models_dir.clone(),
        cache_dir: paths.cache_dir.clone(),
        active_model_id: active,
        recommended_model_id: catalog::recommended().id.to_string(),
    })
}

#[tauri::command]
pub async fn db_stats(state: State<'_, AppState>) -> Result<DbStats> {
    let db = state.db.clone();
    blocking(move || db.stats()).await
}

#[tauri::command]
pub async fn setting_get(state: State<'_, AppState>, key: String) -> Result<Option<String>> {
    let db = state.db.clone();
    blocking(move || db.get_setting(&key)).await
}

#[tauri::command]
pub async fn setting_set(state: State<'_, AppState>, key: String, value: String) -> Result<()> {
    if key.trim().is_empty() {
        return Err(CoreError::Invalid("設定キーが空です".into()));
    }
    let db = state.db.clone();
    blocking(move || db.set_setting(&key, &value)).await
}
