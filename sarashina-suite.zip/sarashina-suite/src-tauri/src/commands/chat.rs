use std::sync::atomic::AtomicBool;
use std::sync::Arc;

use serde_json::json;
use tauri::{AppHandle, Emitter, State};

use sarashina_core::db::ChatMessageRow;
use sarashina_core::error::{CoreError, Result};
use sarashina_core::inference::{new_cancel_flag, ChatTurn, GenOptions, GenStats};

use super::blocking;
use crate::events::{EventTokenSink, LLM_DONE, LLM_ERROR};
use crate::state::AppState;

#[tauri::command]
pub async fn ensure_session(
    state: State<'_, AppState>,
    document_id: Option<String>,
) -> Result<String> {
    let db = state.db.clone();
    blocking(move || db.ensure_session(document_id.as_deref())).await
}

#[tauri::command]
pub async fn list_messages(
    state: State<'_, AppState>,
    session_id: String,
    limit: Option<i64>,
) -> Result<Vec<ChatMessageRow>> {
    let db = state.db.clone();
    let limit = limit.unwrap_or(100).clamp(1, 1000);
    blocking(move || db.list_messages(&session_id, limit)).await
}

#[tauri::command]
pub async fn append_message(
    state: State<'_, AppState>,
    session_id: String,
    role: String,
    content: String,
) -> Result<ChatMessageRow> {
    if !["user", "assistant", "system"].contains(&role.as_str()) {
        return Err(CoreError::Invalid(format!("不正な role: {role}")));
    }
    let db = state.db.clone();
    blocking(move || db.append_message(&session_id, &role, &content)).await
}

/// 生成を実行する。トークンは `llm://token`、完了は `llm://done` で流れる。
/// 完了時には統計（tok/s 等）を返し、DB にログを残す。
#[tauri::command]
pub async fn chat_generate(
    app: AppHandle,
    state: State<'_, AppState>,
    request_id: String,
    messages: Vec<ChatTurn>,
    options: Option<GenOptions>,
) -> Result<GenStats> {
    if messages.is_empty() {
        return Err(CoreError::Invalid("メッセージが空です".into()));
    }
    if !state.engine.status().state.eq("ready") {
        let status = state.engine.status();
        return Err(CoreError::Model(
            status
                .message
                .unwrap_or_else(|| "モデルがまだ読み込まれていません（ダウンロード完了後に再試行してください）".into()),
        ));
    }

    let cancel: Arc<AtomicBool> = new_cancel_flag();
    if let Ok(mut guard) = state.cancels.lock() {
        guard.insert(request_id.clone(), cancel.clone());
    }

    let sink = Box::new(EventTokenSink::new(app.clone(), request_id.clone()));
    let receiver = state
        .engine
        .generate(messages, options.unwrap_or_default(), cancel, sink)?;

    let result = receiver
        .await
        .map_err(|_| CoreError::Inference("生成結果の受信に失敗（ワーカー停止）".into()))?;

    if let Ok(mut guard) = state.cancels.lock() {
        guard.remove(&request_id);
    }

    match result {
        Ok(stats) => {
            let db = state.db.clone();
            let model_id = state.engine.status().model_id;
            let s = stats.clone();
            let _ = blocking(move || {
                db.log_generation(
                    model_id.as_deref(),
                    s.prompt_tokens as i64,
                    s.completion_tokens as i64,
                    s.elapsed_ms as i64,
                    s.tokens_per_sec as f64,
                )
            })
            .await;

            let _ = app.emit(
                LLM_DONE,
                json!({
                    "requestId": request_id,
                    "promptTokens": stats.prompt_tokens,
                    "completionTokens": stats.completion_tokens,
                    "elapsedMs": stats.elapsed_ms,
                    "tokensPerSec": stats.tokens_per_sec,
                    "cancelled": stats.cancelled,
                    "finishReason": stats.finish_reason,
                }),
            );
            Ok(stats)
        }
        Err(e) => {
            let _ = app.emit(
                LLM_ERROR,
                json!({ "requestId": request_id, "message": e.to_string() }),
            );
            Err(e)
        }
    }
}

/// 生成の中断（ユーザーが「停止」を押した時）
#[tauri::command]
pub async fn chat_cancel(state: State<'_, AppState>, request_id: String) -> Result<()> {
    let guard = state
        .cancels
        .lock()
        .map_err(|_| CoreError::Other("状態ロックが破損".into()))?;
    if let Some(flag) = guard.get(&request_id) {
        sarashina_core::inference::request_cancel(flag);
        Ok(())
    } else {
        Err(CoreError::NotFound("実行中の生成がありません".into()))
    }
}
