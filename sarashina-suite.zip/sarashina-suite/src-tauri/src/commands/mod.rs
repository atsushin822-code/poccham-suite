//! Tauri コマンド（フロントエンドから `invoke()` で呼ばれる境界）。
//!
//! 役割は「引数の受け取り → core の呼び出し → DTO 返却 / イベント emit」のみ。
//! ビジネスロジックをここに書かないこと（テスト不能になる）。

mod app;
mod chat;
mod documents;
mod files;
mod models;

pub use app::*;
pub use chat::*;
pub use documents::*;
pub use files::*;
pub use models::*;

use sarashina_core::error::{CoreError, Result};

/// 同期処理（SQLite / ファイル I/O）をブロッキングプールへ逃がす。
/// async ランタイムを塞がないための定型。
pub(crate) async fn blocking<T, F>(f: F) -> Result<T>
where
    T: Send + 'static,
    F: FnOnce() -> Result<T> + Send + 'static,
{
    tauri::async_runtime::spawn_blocking(f)
        .await
        .map_err(|e| CoreError::Other(format!("バックグラウンドタスクが失敗: {e}")))?
}
