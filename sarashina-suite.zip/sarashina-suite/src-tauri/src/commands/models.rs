use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;

use serde::Serialize;
use tauri::{AppHandle, State};

use sarashina_core::catalog::{self, ModelVariant};
use sarashina_core::db::ModelRecord;
use sarashina_core::download::{self, DownloadRequest};
use sarashina_core::error::{CoreError, Result};
use sarashina_core::inference::EngineStatus;
use sarashina_core::now_ms;

use super::blocking;
use crate::events::DownloadSink;
use crate::state::AppState;

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ModelView {
    pub id: String,
    pub display_name: String,
    pub family: String,
    pub params: String,
    pub quant: String,
    pub file_name: String,
    pub size_bytes: u64,
    pub sha256: Option<String>,
    pub min_ram_gb: f32,
    pub recommended: bool,
    pub description: String,
    /// notInstalled | partial | installed | downloading | broken
    pub status: String,
    pub installed: bool,
    pub path: Option<String>,
    pub downloaded_bytes: u64,
    pub last_used_at: Option<i64>,
}

fn to_view(v: &ModelVariant, record: Option<&ModelRecord>, part_bytes: u64, downloading: bool) -> ModelView {
    let (status, installed) = match record {
        Some(r) if r.status == "installed" => ("installed", true),
        Some(_) => ("broken", false),
        None if downloading => ("downloading", false),
        None if part_bytes > 0 => ("partial", false),
        None => ("notInstalled", false),
    };
    ModelView {
        id: v.id.to_string(),
        display_name: v.display_name.to_string(),
        family: v.family.to_string(),
        params: v.params.to_string(),
        quant: v.quant.to_string(),
        file_name: v.file_name.to_string(),
        size_bytes: v.size_bytes,
        sha256: v.sha256.map(str::to_string),
        min_ram_gb: v.min_ram_gb,
        recommended: v.recommended,
        description: v.description.to_string(),
        status: status.to_string(),
        installed,
        path: record.map(|r| r.path.clone()),
        downloaded_bytes: if installed { v.size_bytes } else { part_bytes },
        last_used_at: record.and_then(|r| r.last_used_at),
    }
}

#[tauri::command]
pub async fn list_models(state: State<'_, AppState>) -> Result<Vec<ModelView>> {
    let db = state.db.clone();
    let models_dir = state.paths.models_dir.clone();
    let downloading: Vec<String> = state
        .downloads
        .lock()
        .map(|m| m.keys().cloned().collect())
        .unwrap_or_default();

    blocking(move || {
        let installed = db.list_models()?;
        let mut out = Vec::with_capacity(catalog::CATALOG.len());
        for v in catalog::CATALOG {
            let record = installed.iter().find(|r| r.id == v.id);
            let part = download::part_path(&std::path::Path::new(&models_dir).join(v.file_name));
            let part_bytes = std::fs::metadata(&part).map(|m| m.len()).unwrap_or(0);
            out.push(to_view(v, record, part_bytes, downloading.contains(&v.id.to_string())));
        }
        Ok(out)
    })
    .await
}

/// 非同期でダウンロードを開始し、進捗は `download://progress` イベントで通知する。
#[tauri::command]
pub async fn download_model(
    app: AppHandle,
    state: State<'_, AppState>,
    model_id: String,
) -> Result<()> {
    let variant = catalog::find(&model_id)
        .ok_or_else(|| CoreError::Invalid(format!("未知のモデル ID: {model_id}")))?;

    // 二重起動防止
    {
        let guard = state
            .downloads
            .lock()
            .map_err(|_| CoreError::Other("状態ロックが破損".into()))?;
        if guard.contains_key(&model_id) {
            return Err(CoreError::Invalid("このモデルは既にダウンロード中です".into()));
        }
    }

    let cancel = Arc::new(AtomicBool::new(false));
    if let Ok(mut guard) = state.downloads.lock() {
        guard.insert(model_id.clone(), cancel.clone());
    }

    let client = state.client.clone();
    let db = state.db.clone();
    let engine = state.engine.clone();
    let downloads = state.downloads.clone();
    let dest = std::path::Path::new(&state.paths.models_dir).join(variant.file_name);
    let db_mirror = blocking({
        let db = state.db.clone();
        move || db.get_setting("model_mirror")
    })
    .await?;
    let url = variant.download_url(db_mirror.as_deref());

    // 再開状態を記録（UI 表示用）
    let _ = db.upsert_download(&sarashina_core::db::DownloadState {
        model_id: model_id.clone(),
        url: url.clone(),
        downloaded: 0,
        total: variant.size_bytes as i64,
        etag: None,
        updated_at: now_ms(),
    });

    tauri::async_runtime::spawn(async move {
        // completed は core ではなくここで流す（台帳登録とロードの後 = UI が状態を取り違えない）
        let sink = DownloadSink::deferred_completion(app.clone(), model_id.clone(), cancel.clone());
        let request = DownloadRequest {
            url,
            dest: dest.clone(),
            expected_size: Some(variant.size_bytes),
            expected_sha256: variant.sha256.map(str::to_string),
        };

        let outcome = download::download(&client, &request, &sink).await;

        // どの結末でも「ダウンロード中」の印は先に外す（UI が downloading のまま固まらないように）
        if let Ok(mut guard) = downloads.lock() {
            guard.remove(&model_id);
        }

        match outcome {
            Ok(path) => {
                if !download::is_valid_gguf(&path) {
                    let _ = tokio::fs::remove_file(&path).await;
                    let _ = db.clear_download(&model_id);
                    sink.emit_error("モデルファイルが壊れていたため削除しました。もう一度ダウンロードしてください");
                } else {
                    let record = ModelRecord {
                        id: variant.id.to_string(),
                        display_name: variant.display_name.to_string(),
                        file_name: variant.file_name.to_string(),
                        path: path.display().to_string(),
                        size_bytes: variant.size_bytes as i64,
                        sha256: variant.sha256.map(str::to_string),
                        status: "installed".to_string(),
                        installed_at: now_ms(),
                        last_used_at: Some(now_ms()),
                    };
                    if let Err(e) = db.upsert_model(&record) {
                        sink.emit_error(&format!("台帳登録に失敗: {e}"));
                    }
                    let _ = db.clear_download(&model_id);

                    // アクティブモデルが未設定 / 消えている場合はこのモデルを有効化して読み込む
                    let active = db.get_setting("active_model_id").ok().flatten();
                    let active_usable = active
                        .as_deref()
                        .filter(|id| !id.is_empty())
                        .and_then(|id| db.get_model(id).ok().flatten())
                        .map(|r| std::path::Path::new(&r.path).exists())
                        .unwrap_or(false);
                    if !active_usable {
                        let _ = db.set_setting("active_model_id", variant.id);
                        engine.load(variant.id, path.clone(), None);
                    } else if active.as_deref() == Some(variant.id) {
                        engine.load(variant.id, path.clone(), None);
                    }

                    // 台帳登録もロードも済んだので、ここで 1 回だけ completed を流す
                    sink.emit_completed(variant.size_bytes);
                }
            }
            Err(CoreError::Cancelled) => {
                tracing::info!("ダウンロードをキャンセルしました: {model_id}");
                let _ = db.clear_download(&model_id);
            }
            Err(e) => {
                let _ = db.clear_download(&model_id);
                sink.emit_error(&e.to_string());
            }
        }
    });

    Ok(())
}

#[tauri::command]
pub async fn cancel_download(state: State<'_, AppState>, model_id: String) -> Result<()> {
    let guard = state
        .downloads
        .lock()
        .map_err(|_| CoreError::Other("状態ロックが破損".into()))?;
    if let Some(flag) = guard.get(&model_id) {
        flag.store(true, Ordering::SeqCst);
        Ok(())
    } else {
        Err(CoreError::NotFound("実行中のダウンロードがありません".into()))
    }
}

#[tauri::command]
pub async fn delete_model(state: State<'_, AppState>, model_id: String) -> Result<()> {
    let db = state.db.clone();
    let models_dir = state.paths.models_dir.clone();
    let engine = state.engine.clone();

    let record = blocking({
        let db = db.clone();
        let id = model_id.clone();
        move || db.get_model(&id)
    })
    .await?;

    // 台帳に無くても（＝途中で止まった .part だけが残っていても）消せるようにする
    if let Some(variant) = catalog::find(&model_id) {
        let base = std::path::Path::new(&models_dir).join(variant.file_name);
        let _ = std::fs::remove_file(&base);
        let _ = std::fs::remove_file(download::part_path(&base));
    }

    if let Some(record) = record {
        let path = std::path::PathBuf::from(&record.path);
        let _ = std::fs::remove_file(&path);
        let _ = std::fs::remove_file(download::part_path(&path));
        let _ = std::fs::remove_file(std::path::Path::new(&models_dir).join(&record.file_name));

        let db2 = db.clone();
        let id = model_id.clone();
        blocking(move || {
            db2.delete_model(&id)?;
            let _ = db2.clear_download(&id);
            if db2.get_setting("active_model_id")?.as_deref() == Some(id.as_str()) {
                db2.set_setting("active_model_id", "")?;
            }
            Ok(())
        })
        .await?;
        engine.shutdown();
    } else {
        let db2 = db.clone();
        let id = model_id.clone();
        blocking(move || {
            let _ = db2.clear_download(&id);
            Ok(())
        })
        .await?;
    }
    Ok(())
}

#[tauri::command]
pub async fn activate_model(state: State<'_, AppState>, model_id: String) -> Result<()> {
    let db = state.db.clone();
    let engine = state.engine.clone();
    let record = blocking({
        let db = db.clone();
        let id = model_id.clone();
        move || db.get_model(&id)
    })
    .await?
    .ok_or_else(|| CoreError::NotFound(format!("モデル {model_id} は未インストールです")))?;

    let path = std::path::PathBuf::from(&record.path);
    if !path.exists() {
        return Err(CoreError::NotFound(format!("モデルファイルが見つかりません: {}", record.path)));
    }

    let db2 = db.clone();
    let id = model_id.clone();
    blocking(move || {
        db2.set_setting("active_model_id", &id)?;
        db2.touch_model(&id)
    })
    .await?;

    // すでに同じモデルが読み込み済みなら、数 GB の再ロードを避ける
    let status = engine.status();
    if status.state == "ready" && status.model_id.as_deref() == Some(model_id.as_str()) {
        return Ok(());
    }
    engine.load(model_id, path, None);
    Ok(())
}

#[tauri::command]
pub async fn engine_status(state: State<'_, AppState>) -> Result<EngineStatus> {
    Ok(state.engine.status())
}

/// 推論パラメータを保存し、次のロードから反映する。
#[tauri::command]
pub async fn engine_configure(
    app: AppHandle,
    state: State<'_, AppState>,
    n_ctx: u32,
    n_threads: i32,
    n_gpu_layers: u32,
) -> Result<EngineStatus> {
    let db = state.db.clone();
    let n_ctx = n_ctx.clamp(512, 32768);
    let n_threads = n_threads.clamp(1, 64);
    blocking(move || {
        db.set_setting("n_ctx", &n_ctx.to_string())?;
        db.set_setting("n_threads", &n_threads.to_string())?;
        db.set_setting("n_gpu_layers", &n_gpu_layers.to_string())
    })
    .await?;

    state.engine.set_config(sarashina_core::inference::EngineConfig { n_ctx, n_threads, n_gpu_layers });

    crate::events::emit_engine_status(&app, &state.engine.status());

    // モデルを再ロードして反映
    let db = state.db.clone();
    let active = blocking(move || db.get_setting("active_model_id")).await?;
    if let Some(id) = active.filter(|s| !s.is_empty()) {
        let db = state.db.clone();
        let id2 = id.clone();
        if let Some(record) = blocking(move || db.get_model(&id2)).await? {
            state.engine.load(id, std::path::PathBuf::from(record.path), None);
        }
    }
    Ok(state.engine.status())
}
