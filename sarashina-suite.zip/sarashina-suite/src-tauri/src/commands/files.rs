//! 書き出したファイル（.docx / .xlsx / .pptx / .poccham など）を実ディスクへ保存する。
//!
//! フロントエンドが組み立てたバイト列を base64 で受け取り、
//! データフォルダ配下の `exports/` に書き出して絶対パスを返す。
//! （ブラウザ版は同じデータを Blob ダウンロードするので、両者の結果は一致する）

use std::path::PathBuf;

use tauri::State;

use sarashina_core::error::{CoreError, Result};

use super::blocking;
use crate::state::AppState;

/// 標準の base64（パディングあり）をデコードする。外部クレートを増やさないための最小実装。
fn decode_base64(input: &str) -> Result<Vec<u8>> {
    fn value(c: u8) -> Option<u8> {
        match c {
            b'A'..=b'Z' => Some(c - b'A'),
            b'a'..=b'z' => Some(c - b'a' + 26),
            b'0'..=b'9' => Some(c - b'0' + 52),
            b'+' => Some(62),
            b'/' => Some(63),
            _ => None,
        }
    }

    let bytes: Vec<u8> = input.bytes().filter(|b| !b.is_ascii_whitespace()).collect();
    let mut out = Vec::with_capacity(bytes.len() / 4 * 3);
    let mut buffer = 0u32;
    let mut bits = 0u32;
    for b in bytes {
        if b == b'=' {
            break;
        }
        let v = value(b).ok_or_else(|| CoreError::Invalid("base64 の形式が不正です".into()))?;
        buffer = (buffer << 6) | v as u32;
        bits += 6;
        if bits >= 8 {
            bits -= 8;
            out.push((buffer >> bits) as u8);
        }
    }
    Ok(out)
}

/// ファイル名として安全な形に落とす（パス区切りや制御文字を除去）
fn sanitize_name(name: &str) -> String {
    let cleaned: String = name
        .chars()
        .map(|c| match c {
            '/' | '\\' | ':' | '*' | '?' | '"' | '<' | '>' | '|' => '_',
            c if (c as u32) < 0x20 => '_',
            c => c,
        })
        .collect();
    let trimmed = cleaned.trim();
    if trimmed.is_empty() {
        "export".to_string()
    } else {
        trimmed.chars().take(120).collect()
    }
}

#[tauri::command]
pub async fn save_export_file(
    state: State<'_, AppState>,
    name: String,
    base64: String,
) -> Result<String> {
    let dir = PathBuf::from(&state.paths.data_dir).join("exports");
    let file_name = sanitize_name(&name);
    let data = decode_base64(&base64)?;

    blocking(move || {
        std::fs::create_dir_all(&dir)?;
        let path = dir.join(&file_name);
        // 同名は上書き（連番にすると「どこに保存されたか」が分かりにくくなる）
        std::fs::write(&path, &data)?;
        Ok(path.display().to_string())
    })
    .await
}

/// 書き出しフォルダのパスを返す（設定画面の表示用）
#[tauri::command]
pub fn exports_dir(state: State<'_, AppState>) -> String {
    PathBuf::from(&state.paths.data_dir)
        .join("exports")
        .display()
        .to_string()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn base64_roundtrip() {
        let raw = b"hello poccham";
        let encoded = "aGVsbG8gcG9jY2hhbQ==";
        assert_eq!(decode_base64(encoded).unwrap(), raw.to_vec());
        assert_eq!(decode_base64("aGVsbG8gcG9jY2hhbQ").unwrap(), raw.to_vec());
    }

    #[test]
    fn sanitize_blocks_traversal() {
        assert_eq!(sanitize_name("../../etc/passwd"), ".._.._etc_passwd");
        assert_eq!(sanitize_name("   "), "export");
    }
}
