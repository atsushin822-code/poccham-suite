// リリースビルドではコンソールウィンドウを出さない（Windows）
#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

fn main() {
    sarashina_suite_lib::run()
}
