# Suite with Poccham AI — コア・アーキテクチャ設計書

対象読者: 実装を引き継ぐエンジニア。設計判断の「なぜ」を残すことを目的とする。

---

## 0. 設計原則

1. **オフライン・ファースト** — ネットワークが無くても全機能が動く。通信は「モデル取得」の 1 機能に閉じ込め、
   その他の機能から `reqwest` を見えなくする（`sarashina-core::download` 以外で HTTP を呼ばない）。
2. **ローカル・ファースト** — すべての状態は SQLite（単一ファイル）に落ちる。同期サーバもアカウントも存在しない。
3. **UI スレッドを止めない** — 推論は専用 OS スレッド、I/O と DB は `spawn_blocking`。
4. **ロジックは Tauri 非依存** — `crates/sarashina-core` は Tauri を一切参照しない（テスト可能性の源泉）。
5. **壊れたモデルで推論しない** — サイズ + SHA-256 + GGUF マジックの 3 段検証を通るまで rename しない。
6. **危険な unsafe を書かない** — llama.cpp のライフタイム問題は「所有権をワーカースレッドに閉じる」設計で回避。

---

## 1. レイヤ構成

```
┌──────────────────────────────────────────────────────────────────────┐
│  WebView (Svelte 5 / TypeScript)                                     │
│  App.svelte ─ Workspace ─ {Sidebar, Editor|SheetEditor|SlideEditor,  │
│                            AIPanel}                                  │
│      ▲ invoke()          ▲ event(listen)                             │
└──────┼───────────────────┼──────────────────────────────────────────┘
       │                   │
┌──────┴───────────────────┴──────────────────────────────────────────┐
│  src-tauri (薄いアダプタ層)                                          │
│  commands/*  →  DTO 変換 / イベント emit / キャンセルフラグ管理       │
│  state.rs    →  AppState { db, engine, client, paths, cancels }      │
└──────┬────────────────────────────────────────────┬─────────────────┘
       │                                            │
┌──────┴───────────────────────┐   ┌────────────────┴────────────────┐
│  sarashina-core (純ロジック)  │   │  Inference Worker (専用スレッド)  │
│  db / catalog / download     │   │  LlamaBackend + LlamaModel       │
│  export / prompt             │◄──┤  LlamaContext (リクエスト毎)      │
└──────┬───────────────────────┘   └────────────────┬────────────────┘
       │                                            │
┌──────┴───────────┐  ┌──────────────────┐  ┌───────┴──────────────┐
│ SQLite (WAL/FTS5)│  │  ~/…/models/*.gguf│  │ llama.cpp (静的リンク) │
└──────────────────┘  └──────────────────┘  └──────────────────────┘
```

**なぜ 2 クレートに分けるか**: Tauri の `Command` は OS 依存でテストしづらく、
`cargo test` のたびに WebView のリンクが必要になる。ドメインを切り離すことで
DB マイグレーション・FTS 検索・プロンプト構築・ダウンロード検証をミリ秒単位で回帰テストできる。

---

## 1.5 文書種別（doc / sheet / slide）の扱い

**判断: 種別ごとにエディタを分けるが、保存・検索・書き出しの経路は共通にする。**

| | 実装 | 理由 |
|---|---|---|
| 保存 | `documents.kind` に文字列（`doc`/`sheet`/`slide`）、本文は `content` に HTML | テーブル追加マイグレーション不要。FTS5 の索引も 1 本で済む |
| 表計算 | 本文を `<table data-sheet="1">`、数式は `data-f` 属性、セル本文は計算結果 | 検索・書き出しは「HTML を読む」既存コードがそのまま使える。数式は再計算できる |
| スライド | 本文を `<section data-slide="1">` の連なり（`h2` + `p`） | 同上。1 枚 = 1 section で並べ替えも容易 |
| ロジック | `src/lib/sheet.ts` / `src/lib/slides.ts`（Svelte 非依存の純関数） | ブラウザなしで単体検証できる。UI は表示だけを担う |
| ルーティング | `Workspace.svelte` が `activeDoc.kind` で 3 コンポーネントを出し分け | 種別は文書の属性なので URL ルータは不要 |

数式評価は再帰下降パーサ（`evaluateFormula`）で、参照解決は `evaluateGrid` がメモ化 + 循環検出
（visiting セット）付きで行う。セル間の依存は評価時に解決するため、保存データに計算結果だけを
持たせても再計算できる（`data-f` が真実、セル本文はキャッシュ）。

## 2. オフラインデータ管理（SQLite）

### 2.1 接続設定

```sql
PRAGMA journal_mode = WAL;      -- 読み書き同時実行・クラッシュ耐性
PRAGMA synchronous  = NORMAL;   -- WAL と組み合わせた実用的な耐久性/速度
PRAGMA foreign_keys = ON;
PRAGMA busy_timeout = 5000;
PRAGMA temp_store   = MEMORY;
```

デスクトップアプリの書き込み頻度（自動保存で数回/秒）では 1 コネクション + `Mutex` が最も単純で速い。
将来バルクインポート等が必要になったら読み取り専用コネクションを追加する（`Database::with` の内側だけを変えれば済む）。

### 2.2 スキーマ（`crates/sarashina-core/migrations/001_init.sql`）

| テーブル | 役割 | 主な設計判断 |
|---|---|---|
| `documents` | 文書本体 | 本文は**サニタイズ済み HTML 1 種類**。表計算/スライドも `kind` で区別し将来拡張。削除は `deleted_at` によるソフトデリート（誤操作復帰が効く）|
| `document_versions` | 版スナップショット | 保存のたびに 1 行追加し、`keep=20` で剪定。バイト数も記録して肥大化を監視 |
| `documents_fts` | 全文検索 | FTS5 + **trigram トークナイザ**。日本語は分かち書きしないため `unicode61` では実用にならない。trigram なら辞書なしで部分一致が効く（クエリは 2〜3 文字以上を推奨）|
| `chat_sessions` / `chat_messages` | AI 会話 | セッションはドキュメントに 1 対 1 相当で紐づく。`document_id` は `ON DELETE SET NULL` |
| `models` | インストール済み GGUF 台帳 | 絶対パス・サイズ・SHA-256・状態を持つ。ここが「何が使えるか」の唯一の真実 |
| `downloads` | 中断復帰用 | URL と受信済みバイト数を永続化。アプリ再起動後も `.part` から再開できる |
| `generation_logs` | 性能計測 | tok/s の推移をローカルに記録するだけ（外部送信なし）|
| `settings` | KVS | `active_model_id`, `n_ctx`, `n_threads`, `n_gpu_layers`, `model_mirror` |

### 2.3 マイグレーション

`PRAGMA user_version` を単調増加させ、`migrate()` 内で `version < N` のときだけ SQL を流す。
SQL ファイルは `include_str!` でバイナリに埋め込む（実行時に外部ファイルを探さない）。

```rust
let tx = conn.transaction()?;
let version: i64 = tx.pragma_query_value(None, "user_version", |r| r.get(0))?;
if version < 1 { tx.execute_batch(MIGRATION_001)?; }
if version < SCHEMA_VERSION { tx.pragma_update(None, "user_version", SCHEMA_VERSION)?; }
tx.commit()
```

**したがって既存マイグレーションは絶対に書き換えない**。変更は `002_*.sql` を追加する。

### 2.4 FTS5 の同期

外部コンテンツ FTS（`content='documents'`）に対して INSERT/UPDATE/DELETE トリガで同期する。
アプリ側で二重管理しないので、`save_document` の 1 クエリだけで検索インデックスが常に正しくなる。

---

## 3. Poccham AI のモデル ダウンロード機能

### 3.1 カタログ（`catalog.rs`）

モデルは**アプリに同梱しない**（インストーラを軽く保ち、ライセンス上も素直）。
カタログはバイナリに埋め込んだ静的データで、以下を保持する。

| ID | 表示名（UI） | 量子化 | サイズ | 想定 RAM | 推奨 |
|---|---|---|---|---|---|
| `sarashina-1b-q4_k_m` | **Poccham 1B** | Q4_K_M | 931 MB | 4GB+ | ✅ 既定 |
| `sarashina-1b-q8_0` | **Poccham 1B** | Q8_0 | 1,498 MB | 6GB+ | |
| `sarashina-3b-q4_k_m` | **Poccham 3B** | Q4_K_M | 2,066 MB | 8GB+ | |

UI・ログ・エラー文には**必ず `display_name`（Poccham 1B / 3B）を出す**。`id` と `file_name` は
取得対象ファイルを一意に指すための技術的識別子で、画面には出さない（表示は必ず `display_name`）。
`sha256` は配布元の LFS oid（= ファイルの実ハッシュ）を転記しており、**オフラインで完全性検証ができる**。
ネットワーク制限のある環境向けに `model_mirror` 設定で URL プレフィックスを差し替え可能。

### 3.2 ダウンロードの状態遷移

```
Preparing ──► Downloading ──► Verifying ──► Completed
    │              │              │
    └──────────────┴──────────────┴──► Cancelled / Failed
```

`prepare` → `GET`（既存 `.part` があれば `Range: bytes=N-`）→ 追記ストリーム →
サイズ検証 → SHA-256 全数検証 → `.part` を本体へ `rename`（原子的）。

* **206 Partial Content** = サーバが Range を尊重 → 追記再開
* **200 OK** = Range 非対応 → 最初から（安全側に倒す）
* **416 Range Not Satisfiable** = 既に完成サイズ → 検証のみ実行

### 3.3 進捗イベント（`download://progress`）

100ms でスロットリングし、速度は指数移動平均（EMA）で平滑化する。
WebView へ毎チャンク emit すると IPC が飽和して UI がカクつくため、これは必須の最適化。

```jsonc
{
  "modelId": "sarashina-1b-q4_k_m",
  "phase": "downloading",          // preparing | downloading | verifying | completed | cancelled | failed
  "downloaded": 419430400,
  "total": 931179392,
  "bytesPerSec": 52428800,
  "etaSecs": 10,
  "message": null
}
```

### 3.4 失敗時の扱い

| 事象 | 挙動 |
|---|---|
| 回線断 | `.part` を保持して `Failed`。次回は同じ位置から再開 |
| サイズ不一致 | `.part` を削除して `Failed`（カタログ更新や破損を疑う）|
| SHA-256 不一致 | `.part` を削除して `Failed`（改ざん・転送破損）|
| GGUF マジック不正 | 完成ファイルを削除し台帳に登録しない |
| ユーザーキャンセル | `.part` 保持（再開可能）|

---

## 4. ローカル推論エンジン（llama.cpp）

### 4.1 スレッドモデル（unsafe を書かないための設計）

`LlamaModel` / `LlamaContext<'a>` は `Send` でなく、コンテキストはモデルへの参照を持つ。
これを `Mutex<Option<LlamaModel>>` に入れて `'static` に変換しようとすると unsafe が必要になる。

そこで **モデルの所有権を専用スレッドに閉じ込める**:

```
EngineHandle (Clone, Send)           Inference Worker thread (sarashina-inference)
  tx: Sender<Job>  ─── Job ───────►  loop {
  status: Arc<Mutex<..>>             backend.load() / backend.generate()
  config: Arc<Mutex<..>>  ◄── status   }
```

* ハンドルは Tauri の `State` に置ける（`Clone` で共有可能）
* ワーカーは `LlamaBackend`（プロセスで 1 回だけ `init`）と `LlamaModel` を保持し続ける
* 生成は `Job::Generate { messages, options, cancel, sink, reply }` を投げ、
  `oneshot::Receiver<Result<GenStats>>` で完了を受け取る
* トークンは `TokenSink::on_token(&str)` → `EventTokenSink` → `llm://token` イベント

### 4.2 推論の流れ（`llama.rs`）

```rust
let params = LlamaModelParams::default()
    .with_n_gpu_layers(config.n_gpu_layers)   // 0=CPU, 999=全層GPU
    .with_use_mmap(true);                     // 数GB の GGUF でも起動が速い
let model = LlamaModel::load_from_file(&backend, path, &params)?;
let template = model.chat_template(None).ok(); // GGUF 埋め込みテンプレート
```

1. **プロンプト構築** — `apply_chat_template(tmpl, messages, true)`。対象モデルは
   `<|system|>…</s><|user|>…</s><|assistant|>` 形式。テンプレート欠落時のみ `prompt.rs` のフォールバックを使う。
2. **コンテキスト予算** — `tokens.len() + max_tokens > n_ctx` なら古いメッセージから捨てて再トークン化（最大 8 回）。
   単体で溢れる場合は末尾を切り詰める。超過したまま推論すると llama.cpp 側で失敗するため先に潰す。
3. **プロンプトのデコード** — `n_batch`（512）ずつ `LlamaBatch` に詰めて `ctx.decode()`。最後のトークンだけ `logits=true`。
4. **サンプリングチェーン** — `penalties → temp → top_k → top_p → dist`。
   `temperature <= 0.01` の場合は `greedy`（校正・整形など決定性が欲しい用途）。
5. **生成ループ** — 毎トークンごとに `cancel` フラグを確認 → `is_eog` で終了判定 →
   `token_to_piece_into` で得たバイト列を **UTF-8 境界を跨がないように持ち越して** sink へ流す。
6. **統計** — `prompt_tokens / completion_tokens / elapsed_ms / tok/s / finish_reason` を返し、`generation_logs` に記録。

### 4.3 日本語トークンの落とし穴

llama.cpp のトークン境界は文字境界と一致しない（絵文字・結合文字・一部の漢字）。
バイト列をそのまま `String::from_utf8` すると **生成が途中でエラーになる**。本実装は
`flush_utf8()` で「有効な接頭辞だけ送出し、残りは次トークンへ持ち越す」処理を入れている。

### 4.4 1 リクエスト = 1 コンテキスト

会話を跨いで KV キャッシュを再利用したくなるが、**必ずリクエスト毎に `LlamaContext` を生成**している。
理由は (a) 履歴の編集・再生成・停止が自由になる (b) 前のプロンプトの残響（汚染）を防げる。
`n_ctx=4096` のコンテキスト生成は 1B モデルで数十 ms 程度であり、体感に影響しない。

### 4.5 スタブバックエンド

`--no-default-features` では `stub.rs` が使われ、固定のダミー応答を疑似ストリーミングする。
**C++ ツールチェーンなしで UI・イベント・キャンセル・DB 書き込みまで E2E で検証できる**ため、
CI とフロントエンド開発の標準経路にしている。

---

## 5. フロントエンド（Svelte 5）

### 5.1 状態管理

`src/lib/stores/app.svelte.ts` に runes ベースのクラス（`$state`）を 1 つ置き、
`app_info` / `models` / `engine` を保持する。`engine://status` を購読してサイドバーの状態表示が自動更新される。

### 5.2 エディタと自動保存

* 本文は `contenteditable` + `document.execCommand`（WKWebView / WebView2 / WebKitGTK で動作）。
  リッチテキストエディタのフル機能（協調編集・IME 対応の高度化）が必要になったら TipTap/ProseMirror へ移行する前提で、
  **保存形式は HTML 1 種類**に固定してある（移行時に JSON へ変換すればよい）。
* 入力のたびに `pending` ペイロードを更新し、800ms デバウンスで `save_document`。
  ドキュメント切替時は必ずフラッシュしてから差し替える（`$effect` 内で `flush()`）。
* 保存前に `sanitizeHtml()` で `<script>` / `on*=` / `javascript:` を除去（多層防御）。

### 5.3 イベント購読

`subscribe()`（`src/lib/api.ts`）が唯一の購読窓口。Tauri 実行時は `@tauri-apps/api/event` の
`listen`、ブラウザ実行時は `demo.ts` の内部バスに切り替わる。

| イベント | ペイロード | 用途 |
|---|---|---|
| `download://progress` | `DownloadEvent` | 進捗バー / 完了通知 / 失敗表示 |
| `engine://status` | `EngineStatus` | サイドバーと設定画面の状態 |
| `llm://token` | `{requestId, delta}` | ストリーミング描画 |
| `llm://done` | 統計 | tok/s 表示 |
| `llm://error` | `{requestId, message}` | エラー表示 |

### 5.4 プロンプト設計（AI パネル）

system プロンプトで役割を固定し、user メッセージに「本文（最大 6000 字）+ 依頼」を入れる。
プリセットは 校正 / 要約 / 箇条書き化 / 続きを書く / 敬語チェック。
生成は `requestId` で相関を取るため、複数リクエストの混線やキャンセルが安全に行える。

---

## 6. マルチプラットフォーム・ビルド

### 6.1 バンドル設定（`src-tauri/tauri.conf.json`）

```jsonc
"bundle": {
  "targets": ["deb", "appimage", "rpm", "dmg", "app", "nsis", "msi"],
  "windows": {
    "nsis": { "installMode": "perMachine", "languages": ["Japanese", "English"] },
    "wix":  { "language": ["ja-JP", "en-US"] },
    "webviewInstallMode": { "type": "downloadBootstrapper", "silent": true }
  },
  "macOS": { "minimumSystemVersion": "10.15", "entitlements": "./entitlements.plist" },
  "linux": { "deb": { "depends": ["libwebkit2gtk-4.1-0", "libgtk-3-0"] } }
}
```

* **Windows `.exe`** = NSIS インストーラ（`setup.exe`）、**`.msi`** = WiX。両方同時に出力する。
  `downloadBootstrapper` により WebView2 未導入の端末でもインストール時に自動取得する。
* **macOS `.dmg`** は `aarch64` / `x64` を別ジョブでビルド（ユニバーサルにする場合は `--target universal-apple-darwin`）。
  Metal を使うため `--features metal`。
* **Linux `.AppImage` / `.deb` / `.rpm`** は `ubuntu-22.04` 上でビルド（glibc の下限を下げるため。24.04 で作ると古いディストロで動かない）。
* アイコンは `npm run icons` で `src-tauri/icons/source.png` から生成する。

### 6.2 CI/CD（`.github/workflows/build.yml` 1 本）

`v*` タグ push、または手動実行（`workflow_dispatch`）で検証 + 4 ジョブが並列実行され、成果物が Artifacts と Release に出力される。

ワークフローは **zip 単体でも動く**ように、最初のステップで `tauri.conf.json` を探索し、
見つからなければリポジトリ直下の `*.zip` を展開してからプロジェクトルートを解決する
（`steps.locate.outputs.dir` を以降の全ステップの `working-directory` に使う）。
これにより「zip をアップロード + yml を 1 枚置く」だけで CI が成立する。

| ジョブ | ランナー | 出力 |
|---|---|---|
| Linux x86_64 | `ubuntu-22.04` | AppImage / deb / rpm |
| Windows x64 | `windows-latest` | NSIS(.exe) / msi |
| macOS ARM64 | `macos-15` | dmg（Metal 有効）|
| macOS x64 | `macos-15-intel` | dmg |

ポイント:

* `llama-cpp-sys-2` をビルドするため **cmake / clang を明示的に導入**（Linux は `libclang-dev` も）。
* **ランナーラベルは廃止される**: `macos-14` 系は 2026-11-02 に廃止（brownout を経て削除）。
  新規作成時は `macos-15`（arm64）/ `macos-15-intel`（x64）を使い、変数で上書き可能にしておく。
* **Web 版（静的配信）**: Tauri が無い環境では `src/lib/api.ts` が自動的に `src/lib/web.ts` の
  `WebBackend` に切り替わる（`?demo=1` のときだけ `demo.ts` のモック）。
  文書/会話/設定は IndexedDB に保存し、`GGUF` 推論は提供しない（`engineStatus` が error を返し、
  UI は「Web 版では AI なし」を表示）。書き出しは Blob ダウンロードで実装。
  ビルドは `vite build`（`base: "./"`）で、成果物はサブディレクトリ配信でも動く。
* **起動スクリプト**: `launchers/Start-Suite-with-Poccham-AI.{bat,sh,command}`。
  成果物の収集ステップが OS ごとに該当スクリプトを配布物へコピーする
  （Windows はポータブル zip の中にも入れる / macOS は `.app` とセットで zip 化 / Linux は AppImage の隣に置く想定）。
* **アイコン**: `src-tauri/icons/source.png`（1254×1254）から `npm run icons` で全形式を生成。
  AI モチーフのスパークルは入れていない（文書モチーフのみ）。
* **Windows ポータブル配布**: Tauri の生バイナリ（`target/release/sarashina-suite.exe`）は
  WebView2 ランタイム以外の依存を持たないため、インストーラ無しで起動できる。CI はこれを
  `SuiteWithPocchamAI-<ver>-portable-x64.exe` / `.zip`（中身の exe 名も `SuiteWithPocchamAI.exe`）として成果物に同梱する。
* **失敗時は診断ステップ**: `if: failure()` で環境情報とディレクトリ構成を
  `$GITHUB_STEP_SUMMARY` と artifact に出力する（ログを貼れない状況でも原因を特定できる）。
* **成果物の場所**: ルート `Cargo.toml` が `[workspace]` のため cargo の target dir は
  `<project>/target`。Tauri の bundle もここに出る（`src-tauri/target` ではない）。
* **Windows の MSI**: WiX 3 のデータベースはコードページがロケール依存（en-US=1252 / ja-JP=932）。
  日本語の `shortDescription` を含む場合、en-US ロケールの MSI 生成が `LGHT0311` で失敗する。
  `bundle.windows.wix.language` を `"ja-JP"` に限定し、さらに CI では MSI 失敗時に NSIS へフォールバックする。
* **macOS は署名なしが既定**: ⓪署名あり(APPLE_SIGNING=true のみ) → ①Metal → ②CPU → ③.app のみ。
  署名は既定で試さないため、証明書の不備でビルド時間を消費しない。
* **macOS の Metal**: Xcode 26 以降は Metal シェーダコンパイラが別コンポーネント化されたため、
  `xcodebuild -downloadComponent MetalToolchain` を先に実行する。それでも失敗する環境向けに、
  `CMAKE_TOOLCHAIN_FILE` で `GGML_METAL=OFF` を強制する一時ツールチェインファイルを生成して
  CPU 版で再試行する（llama-cpp-sys-2 は macOS では `CMAKE_TOOLCHAIN_FILE` を自前定義しないため env で差し替え可能）。
* **matrix はジョブレベルの `if:` で参照できない**（利用可能なコンテキストは `github` / `inputs` / `needs` / `vars` のみ）。
  そのため `plan` ジョブが選択された対象の matrix JSON を `outputs` に出し、`build` ジョブが
  `matrix: ${{ fromJSON(needs.plan.outputs.matrix) }}` で受け取る構成にしている。
* `Swatinem/rust-cache` に target 別キーを設定し、C++ ビルド成果物もキャッシュ。2 回目以降は大幅に短縮。
* 署名は Secrets の有無で自動的に切り替わる（未設定なら未署名ビルド）。
  * macOS: `APPLE_CERTIFICATE` / `APPLE_CERTIFICATE_PASSWORD` / `APPLE_SIGNING_IDENTITY` / `APPLE_ID` / `APPLE_PASSWORD` / `APPLE_TEAM_ID`
  * Windows: `TAURI_SIGNING_PRIVATE_KEY`（updater 用）+ Authenticode 証明書
* `tauri-action` が Release 作成・アップロード・（設定時）updater 用 `latest.json` 生成まで行う。

### 6.3 サイズと起動時間

| 項目 | 目安 |
|---|---|
| フロントエンド | JS 183.5KB / CSS 27KB（gzip 合計 約 66KB）|
| アプリ本体（llama.cpp 静的リンク込み） | 20〜35MB（LTO + strip 有効）|
| モデル | 931MB（1B Q4_K_M）。初回のみダウンロード |
| コールドスタート | 1〜2 秒 + モデルロード 1〜3 秒 |

---

## 7. セキュリティ / プライバシー

* **CSP**: `default-src 'self'` + `connect-src` は `ipc:` のみ。外部オリジンへの通信は WebView 側から不可能。
* **Tauri capabilities**: `core:default` / `dialog` / `opener` のみ。`fs` プラグインは**あえて入れていない**
  （ファイル操作は Rust 側のコマンドに限定し、パスの検証をサーバ側で行う）。
* **HTML サニタイズ**: 保存時とエクスポート時に危険タグ・属性を除去。
* **モデル完全性**: カタログの SHA-256 と実ファイルを照合。改ざんされたモデルは台帳に載らない。
* **テレメトリなし**: 送信処理そのものが存在しない。`generation_logs` はローカル計測のみ。
* **シークレット**: API キー等は存在しない（クラウド AI を使わない設計）。

---

## 7.5 書き出し / 多言語 / プレゼン / スクロール（実装メモ）

### 7.5.1 ネイティブ書き出し（`src/lib/exporters.ts` + `src/lib/zip.ts`）

`.docx` / `.xlsx` / `.pptx` は **OOXML を自前で組み立てる**。外部ライブラリを足すとバンドルが数 MB 増え、
ライセンス表記も増えるため、必要最小限のパーツだけを書く方針にした。

* `zip.ts` — CRC32 + ローカルヘッダ + 中央ディレクトリだけの最小 ZIP ライタ（無圧縮 = store）。
  OOXML は zip コンテナであれば圧縮方式を問わないため、実装を 100 行程度に抑えられる。
* `docx` — `word/document.xml` に段落（`w:p`）と run（`w:r`）。見出しは `w:pStyle`、太字/斜体/下線は `w:rPr`。
* `xlsx` — `xl/worksheets/sheet1.xml`（複数シートは `sheetN.xml`）+ `xl/sharedStrings.xml` + `workbook.xml`。
  数式は `<f>` と**計算結果のキャッシュ `<v>`** を両方書き込む（Excel 以外のビューアでも値が出る）。
* `pptx` — `ppt/slides/slideN.xml` を 16:9（`12192000 x 6858000` EMU）。1 枚目はタイトル + 本文の 2 プレースホルダ相当。
* `.poccham` — 3 種を 1 ファイルに同梱する JSON。`{format:"poccham", version:1, app:"Suite with Poccham AI", exportedAt, documents:[…]}`。
* Web は Blob + `a.download`、Tauri は `api.saveExportFile(name, base64)` で `{data_dir}/exports/` に保存する
  （`fs` プラグインを入れず、パス検証を Rust 側に閉じ込める設計を維持）。

**はまりどころ**: `contenteditable` の `innerHTML` は `"1 行目<div>2 行目</div>"` のように
**先頭がテキストノード**になる。`body.children` だけを走査すると 1 行目が消えるため、
`childNodes` を走査して `TEXT_NODE` も段落化する。ブロック開始タグでは改行を入れてから
テキスト化しないと、見出しと本文が 1 段落に潰れる。

### 7.5.2 多言語（`src/lib/i18n.svelte.ts`）

* 辞書は 6 言語（ja / en / zh / ko / es / de）を 1 ファイルに持ち、`t("workspace.newDoc")` 形式で引く。
* 設定値 `locale` は `auto` を既定とし、`navigator.language` から解決する（`systemLocale()`）。
  `auto` のときは `languagechange` を購読して**再起動なしで追従**する。
* UI 文言はすべて辞書経由。**プレースホルダ（透かし）は使わず**、可視ラベル + `aria-label` で提示する
  （コントラストと読み上げの両方を確保するため）。
* 初回起動は `NameSetup.svelte` で名前と言語だけを聞く（`スキップ` 可）。名前は `settings.user_name` に保存し、
  あいさつ文と AI への文脈付けに使う。

### 7.5.3 プレゼン（`src/lib/components/Presentation.svelte`）

* スライドの `content` を 16:9 の固定ステージに描画し、`position: fixed` の全面オーバーレイで表示。
* `→ / Space / ← / Esc / Home / End` とクリックでページ送り。キー購読は `svelte:window` に 1 箇所だけ置く。
* 編集中の state をそのまま参照するので、発表前の書き出しや変換は不要。

### 7.5.4 スクロール（`src/app.css`）

デスクトップ WebView で「画面全体が動かない / 二重スクロールになる」問題への対処。

* `html { overflow: hidden }` + `body { overflow: auto; overscroll-behavior: none }`
  — スクロールコンテナを `body` 1 つに固定する（WebView ごとの差分を吸収できる）。
* `#app { display: flex; flex-direction: column; min-height: 100% }` で高さを伝播させる。
* スクロールバーは `scrollbar-width: thin` + `::-webkit-scrollbar`（11px）で**常時表示**。
  一覧・エディタ内のスクロール領域（`.scroll`）は `overscroll-behavior: contain` で内側に閉じる。

## 8. 拡張ロードマップ

| 優先 | 項目 | 実装方針 |
|---|---|---|
| 高 | 大規模シートの仮想スクロール | 40×12 の固定グリッドを可変サイズ + ウィンドウイングへ拡張 |
| 高 | モデル選択 UI の拡充 | `catalog.rs` に量子化バリエーションを追加するだけで UI は自動追従 |
| 中 | 自動アップデータ | `tauri-plugin-updater` + `TAURI_SIGNING_PRIVATE_KEY`。`latest.json` は `tauri-action` が生成 |
| 中 | 執筆支援の深化 | 選択範囲だけを対象にしたインライン校正（`Editor` から選択テキストを渡す）|
| 中 | OCR / 音声 | TTS 用 GGUF を追加し、同じ `catalog` + `download` 基盤で配布 |
| 低 | ユニバーサルバイナリ | `--target universal-apple-darwin` で dmg 1 本に統合 |
| 低 | 複数ウィンドウ | ドキュメントごとに `WebviewWindow`。状態は SQLite 経由で共有 |
