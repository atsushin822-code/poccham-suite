<script lang="ts">
  import { onMount } from "svelte";
  import NameSetup from "./lib/views/NameSetup.svelte";
  import Onboarding from "./lib/views/Onboarding.svelte";
  import Workspace from "./lib/views/Workspace.svelte";
  import Settings from "./lib/views/Settings.svelte";
  import { store } from "./lib/stores/app.svelte";
  import { t } from "./lib/i18n.svelte";

  type View = "loading" | "name" | "onboarding" | "workspace" | "settings";

  let view = $state<View>("loading");
  let bootError = $state<string | null>(null);

  onMount(async () => {
    try {
      await store.boot();
    } catch (e) {
      bootError = e instanceof Error ? e.message : String(e);
    }
    if (bootError) return;

    // ① 初回はまず名前を聞く（親しみやすい入口）
    if (!store.userName) {
      view = "name";
      return;
    }
    // ② モデルが 1 つも無ければセットアップ（Web 版はモデルを持てないので不要）
    view = !store.web && !store.hasModel ? "onboarding" : "workspace";
  });

  /** 名前の入力後: デスクトップ版でモデル未導入ならモデル選択へ */
  function afterName() {
    view = !store.web && !store.hasModel ? "onboarding" : "workspace";
  }
</script>

{#if view === "loading" || store.booting}
  <div class="boot center">
    <div class="mark">P</div>
    {#if bootError}
      <p class="muted err">{bootError}</p>
    {:else}
      <p class="muted">{t("boot.loading")}</p>
    {/if}
  </div>
{:else if view === "name"}
  <NameSetup ondone={afterName} />
{:else if view === "onboarding"}
  <Onboarding ondone={() => (view = "workspace")} />
{:else if view === "settings"}
  <Settings onback={() => (view = "workspace")} />
{:else}
  <Workspace
    onsettings={() => (view = "settings")}
    oninstall={() => (view = "onboarding")}
  />
{/if}

<style>
  .boot { height: 100vh; flex-direction: column; gap: 14px; background: var(--bg); }
  .mark {
    width: 46px; height: 46px; border-radius: 14px;
    background: linear-gradient(135deg, var(--accent), #22d3ee);
    color: #fff; font-size: 22px; font-weight: 700;
    display: grid; place-items: center;
    animation: pulse 1.6s ease-in-out infinite;
  }
  .err { color: var(--danger); max-width: 40ch; text-align: center; font-size: 12px; }
</style>
