<script lang="ts">
  import { onMount } from "svelte";
  import ModelCard from "../components/ModelCard.svelte";
  import { api, subscribe } from "../api";
  import { store } from "../stores/app.svelte";
  import { LOCALES, LOCALE_LABEL, t, type Locale } from "../i18n.svelte";
  import { formatBytes } from "../format";
  import type { DbStats, DownloadEvent } from "../types";

  let { onback }: { onback: () => void } = $props();

  let stats = $state<DbStats | null>(null);
  let progress = $state<Record<string, DownloadEvent>>({});
  let nCtx = $state(4096);
  let nThreads = $state(4);
  let nGpuLayers = $state(0);
  let mirror = $state("");
  let savedNote = $state("");
  let nameInput = $state(store.userName);
  let nameNote = $state("");
  let exportsPath = $state("");
  let unsub: (() => void) | undefined;

  onMount(() => {
    void init();
    return () => unsub?.();
  });

  async function init() {
    await store.refreshModels();
    stats = await api.dbStats();
    exportsPath = await api.exportsDir().catch(() => "");
    const [ctx, threads, gpu, mirrorSetting] = await Promise.all([
      api.settingGet("n_ctx"),
      api.settingGet("n_threads"),
      api.settingGet("n_gpu_layers"),
      api.settingGet("model_mirror"),
    ]);
    if (ctx) nCtx = Number(ctx);
    if (threads) nThreads = Number(threads);
    if (gpu) nGpuLayers = Number(gpu);
    mirror = mirrorSetting ?? "";

    unsub = await subscribe<DownloadEvent>("download://progress", (event) => {
      progress = { ...progress, [event.modelId]: event };
      if (event.phase === "completed") {
        void (async () => {
          await store.waitForInstalled(event.modelId, 20_000);
          await store.waitForEngine(120_000);
          stats = await api.dbStats();
        })();
      } else if (event.phase === "failed" || event.phase === "cancelled") {
        void store.refreshModels();
      }
    });
  }

  async function applyEngine() {
    await api.engineConfigure(nCtx, nThreads, nGpuLayers);
    await api.settingSet("model_mirror", mirror);
    await store.refreshModels();
    savedNote = t("set.nameSaved");
    setTimeout(() => (savedNote = ""), 2600);
  }

  async function saveName() {
    await store.setUserName(nameInput);
    nameInput = store.userName;
    nameNote = t("set.nameSaved");
    setTimeout(() => (nameNote = ""), 2000);
  }

  async function download(id: string) {
    await api.downloadModel(id).catch((e) => {
      progress = {
        ...progress,
        [id]: {
          modelId: id,
          phase: "failed",
          downloaded: 0,
          total: 0,
          bytesPerSec: 0,
          etaSecs: null,
          message: e instanceof Error ? e.message : String(e),
        },
      };
    });
  }
  async function cancel(id: string) {
    await api.cancelDownload(id).catch(() => {});
    setTimeout(() => void store.refreshModels(), 400);
  }
  async function remove(id: string) {
    await api.deleteModel(id);
    await store.refreshModels();
    stats = await api.dbStats();
  }
  async function activate(id: string) {
    await api.activateModel(id);
    await store.refreshModels();
  }
</script>

<div class="settings scroll">
  <div class="inner">
    <header class="row">
      <button class="ghost sm" onclick={onback}>← {t("set.back")}</button>
      <h1>{t("set.title")}</h1>
      <div class="spacer"></div>
      <span class="tag mono">v{store.info?.version ?? "0.2.0"}</span>
    </header>

    <section class="card">
      <h2>{t("set.profile")}</h2>
      <div class="grid">
        <label>
          <span>{t("set.name")}</span>
          <input bind:value={nameInput} maxlength="40" aria-label={t("set.name")} autocomplete="off" />
        </label>
        <label>
          <span>{t("set.language")}</span>
          <select
            value={store.localeSetting}
            onchange={(e) => store.setLocale((e.currentTarget as HTMLSelectElement).value as Locale | "auto")}
            aria-label={t("set.language")}
          >
            <option value="auto">{t("setup.auto")}</option>
            {#each LOCALES as code (code)}
              <option value={code}>{LOCALE_LABEL[code]}</option>
            {/each}
          </select>
        </label>
      </div>
      <div class="row">
        <button class="primary sm" onclick={saveName}>{t("set.nameSave")}</button>
        {#if nameNote}<span class="ok-note">{nameNote}</span>{/if}
      </div>
    </section>

    <section>
      <h2 class="plain">{t("set.ai")}</h2>
      <p class="note">{t("set.aiLead")}</p>
      <div class="cards">
        {#each store.models as model (model.id)}
          <ModelCard
            {model}
            progress={progress[model.id] ?? null}
            active={store.engine?.modelId === model.id || store.info?.activeModelId === model.id}
            ondownload={download}
            oncancel={cancel}
            ondelete={remove}
            onactivate={activate}
          />
        {/each}
      </div>
    </section>

    <section class="card">
      <h2>{t("set.engine")}</h2>
      <div class="grid">
        <label>
          <span>{t("set.ctx")}</span>
          <input type="number" min="512" max="32768" step="512" bind:value={nCtx} />
        </label>
        <label>
          <span>{t("set.threads")}</span>
          <input type="number" min="1" max="64" bind:value={nThreads} />
        </label>
        <label>
          <span>{t("set.gpu")}</span>
          <input type="number" min="0" max="999" bind:value={nGpuLayers} />
        </label>
        <label>
          <span>mirror</span>
          <input type="text" bind:value={mirror} />
        </label>
      </div>
      <div class="row">
        <button class="primary sm" onclick={applyEngine}>{t("set.apply")}</button>
        {#if savedNote}<span class="ok-note">{savedNote}</span>{/if}
        <div class="spacer"></div>
        <span class="tag mono">{store.engine?.backend ?? "—"} / {store.engine?.state ?? "—"}</span>
      </div>
    </section>

    <section class="card">
      <h2>{t("set.data")}</h2>
      <div class="kv mono">
        <div><span>{t("set.dataDir")}</span><span>{store.info?.dataDir}</span></div>
        <div><span>{t("set.dbPath")}</span><span>{store.info?.dbPath}</span></div>
        <div><span>{t("set.modelsDir")}</span><span>{store.info?.modelsDir}</span></div>
        {#if exportsPath}
          <div><span>{t("work.export")}</span><span>{exportsPath}</span></div>
        {/if}
      </div>
      {#if stats}
        <div class="stats">
          <div><span class="n">{stats.documents}</span><span class="l">{t("set.docs")}</span></div>
          <div><span class="n">{stats.characters.toLocaleString()}</span><span class="l">chars</span></div>
          <div><span class="n">{stats.chatMessages}</span><span class="l">messages</span></div>
          <div><span class="n">{stats.models}</span><span class="l">models</span></div>
          <div><span class="n">v{stats.schemaVersion}</span><span class="l">schema</span></div>
        </div>
      {/if}
      {#if store.models.some((m) => m.installed)}
        <p class="note">
          {formatBytes(store.models.filter((m) => m.installed).reduce((n, m) => n + m.sizeBytes, 0))}
        </p>
      {/if}
      {#if store.web}
        <div class="webnote">
          <strong>{t("set.web")}</strong>
          <p>{t("set.webLead")}</p>
        </div>
      {/if}
    </section>
  </div>
</div>

<style>
  .settings { height: 100vh; height: 100dvh; overflow-y: auto; overscroll-behavior: contain; background: var(--bg); }
  .inner { max-width: 880px; margin: 0 auto; padding: 26px 32px 80px; display: flex; flex-direction: column; gap: 22px; }
  header h1 { font-size: 19px; margin: 0 0 0 6px; }
  h2 { font-size: 14px; margin: 0 0 10px; }
  h2.plain { margin-left: 2px; }
  .card { padding: 18px; }
  .note { font-size: 12px; color: var(--text-soft); line-height: 1.75; margin: 0 0 14px; }
  .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(210px, 1fr)); gap: 12px; margin-bottom: 14px; }
  label { display: flex; flex-direction: column; gap: 5px; font-size: 12px; color: var(--text-soft); }
  label input, label select { width: 100%; }
  .ok-note { font-size: 12px; color: var(--ok); }
  .cards { display: flex; flex-direction: column; gap: 12px; }
  .kv { font-size: 11.5px; display: flex; flex-direction: column; gap: 6px; margin-bottom: 14px; }
  .kv div { display: flex; gap: 12px; }
  .kv span:first-child { color: var(--text-faint); width: 92px; flex: none; }
  .kv span:last-child { color: var(--text-soft); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .stats { display: flex; gap: 22px; flex-wrap: wrap; margin-bottom: 12px; }
  .stats div { display: flex; flex-direction: column; }
  .n { font-size: 17px; font-weight: 650; font-variant-numeric: tabular-nums; }
  .l { font-size: 10.5px; color: var(--text-faint); }
  .webnote {
    font-size: 12px; color: var(--text-soft); background: var(--accent-soft);
    border-radius: 10px; padding: 10px 12px;
  }
  .webnote p { margin: 4px 0 0; line-height: 1.7; }
</style>
