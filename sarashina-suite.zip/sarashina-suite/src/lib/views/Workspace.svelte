<script lang="ts">
  import { onMount } from "svelte";
  import Sidebar from "../components/Sidebar.svelte";
  import Editor from "../components/Editor.svelte";
  import SheetEditor from "../components/SheetEditor.svelte";
  import SlideEditor from "../components/SlideEditor.svelte";
  import AIPanel from "../components/AIPanel.svelte";
  import Presentation from "../components/Presentation.svelte";
  import { api } from "../api";
  import { store } from "../stores/app.svelte";
  import { t } from "../i18n.svelte";
  import { evaluateGrid, htmlToGrid } from "../sheet";
  import { htmlToSlides, type Slide } from "../slides";
  import { exportDocument, formatsFor, type ExportFormat } from "../exporters";
  import { saveFile } from "../save";
  import type { Doc, DocumentKind, DocumentSummary } from "../types";

  let {
    onsettings,
    oninstall,
  }: { onsettings: () => void; oninstall: () => void } = $props();

  let documents = $state<DocumentSummary[]>([]);
  let activeId = $state<string | null>(null);
  let activeDoc = $state<Doc | null>(null);
  let aiOpen = $state(true);
  let exportFormat = $state<ExportFormat>("docx");
  let exportNote = $state<string | null>(null);
  let presenting = $state(false);
  let presentSlides = $state<Slide[]>([]);

  const kindLabel = (kind: DocumentKind) =>
    kind === "sheet" ? t("kind.sheet") : kind === "slide" ? t("kind.slide") : t("kind.doc");

  const formats = $derived(activeDoc ? formatsFor(activeDoc.kind) : (["poccham"] as ExportFormat[]));

  // 種別が変わったら書き出し形式をその種別の既定に合わせる
  let lastKind = $state<DocumentKind | null>(null);
  $effect(() => {
    const kind = activeDoc?.kind ?? null;
    if (kind === lastKind) return;
    lastKind = kind;
    if (kind) exportFormat = formatsFor(kind)[0];
  });

  async function refresh(selectId?: string) {
    documents = await api.listDocuments();
    const id = selectId ?? activeId ?? documents[0]?.id ?? null;
    if (id) await open(id);
  }

  async function open(id: string) {
    if (activeDoc && activeDoc.id !== id) {
      await api
        .saveDocument(activeDoc.id, activeDoc.title, activeDoc.content, activeDoc.plainText)
        .catch(() => {});
    }
    activeId = id;
    activeDoc = await api.getDocument(id);
  }

  async function create(kind: DocumentKind = "doc") {
    const doc = await api.createDocument(undefined, kind);
    await refresh(doc.id);
  }

  async function remove(id: string) {
    await api.deleteDocument(id, false);
    if (activeId === id) activeDoc = null;
    await refresh();
    if (documents.length === 0) create();
  }

  async function pin(id: string, pinned: boolean) {
    await api.pinDocument(id, pinned);
    await refresh();
  }

  function onSaved(updatedAt: number, title: string) {
    if (activeDoc) {
      activeDoc = { ...activeDoc, title, updatedAt };
    }
    const entry = documents.find((d) => d.id === activeDoc?.id);
    if (entry) {
      entry.title = title;
      entry.updatedAt = updatedAt;
      documents = [...documents].sort(
        (a, b) => Number(b.pinned) - Number(a.pinned) || b.updatedAt - a.updatedAt,
      );
    }
  }

  /** 統合ネイティブ形式（.poccham）は全ドキュメントを 1 ファイルにまとめる */
  async function collectAllDocs(): Promise<Doc[]> {
    const docs: Doc[] = [];
    for (const summary of documents) {
      const full = await api.getDocument(summary.id);
      if (full) docs.push(full);
    }
    if (activeDoc && !docs.some((d) => d.id === activeDoc!.id)) docs.push(activeDoc);
    return docs;
  }

  async function doExport() {
    if (!activeDoc) return;
    try {
      // エディタ側の自動保存は非同期なので、保存済みの最新内容を必ず読み直してから変換する
      const doc = (await api.getDocument(activeDoc.id)) ?? activeDoc;
      activeDoc = doc;
      const extra: Parameters<typeof exportDocument>[2] = {};
      if (exportFormat === "xlsx") {
        const grid = htmlToGrid(doc.content);
        extra.grid = grid;
        extra.values = evaluateGrid(grid);
      }
      if (exportFormat === "pptx" || exportFormat === "md" || exportFormat === "txt") {
        if (doc.kind === "slide") extra.slides = htmlToSlides(doc.content);
      }
      if (exportFormat === "poccham") extra.allDocs = await collectAllDocs();

      const file = exportDocument(doc, exportFormat, extra);
      const path = await saveFile(file.name, file.data);
      exportNote = t("work.exported", { path });
    } catch (e) {
      exportNote = e instanceof Error ? e.message : t("work.exportFailed");
    }
    setTimeout(() => (exportNote = null), 5000);
  }

  async function present() {
    if (!activeDoc || activeDoc.kind !== "slide") return;
    const doc = (await api.getDocument(activeDoc.id)) ?? activeDoc;
    activeDoc = doc;
    presentSlides = htmlToSlides(doc.content);
    presenting = true;
  }

  onMount(async () => {
    await refresh();
    if (documents.length === 0) await create();
  });
</script>

<div class="layout" class:ai-closed={!aiOpen}>
  <Sidebar
    {documents}
    activeId={activeId}
    engineLabel={store.engineLabel}
    demo={store.demo}
    web={store.web}
    onselect={open}
    oncreate={create}
    ondelete={remove}
    onpin={pin}
    {onsettings}
    {oninstall}
  />

  <main>
    <div class="topbar">
      <span class="crumb">
        {activeDoc ? kindLabel(activeDoc.kind) : t("app.name")}
        <span class="faint">/</span>
        {activeDoc?.title ?? t("work.untitled")}
      </span>
      <div class="spacer"></div>
      {#if exportNote}
        <span class="faint mono exportnote">{exportNote}</span>
      {/if}
      {#if activeDoc}
        {#if activeDoc.kind === "slide"}
          <button class="ghost sm" onclick={present} title={t("work.present")}>▶ {t("work.present")}</button>
        {/if}
        <select class="fmt" bind:value={exportFormat} aria-label={t("work.exportFormat")}>
          {#each formats as format (format)}
            <option value={format}>{t(`fmt.${format}`)}</option>
          {/each}
        </select>
        <button class="ghost sm" onclick={doExport}>{t("work.export")}</button>
      {/if}
      <button class="ghost sm" onclick={() => (aiOpen = !aiOpen)}>
        {aiOpen ? t("work.aiHide") : t("work.aiShow")}
      </button>
    </div>
    <div class="editor-area">
      {#if activeDoc?.kind === "sheet"}
        <SheetEditor doc={activeDoc} {onSaved} />
      {:else if activeDoc?.kind === "slide"}
        <SlideEditor doc={activeDoc} {onSaved} onpresent={present} />
      {:else}
        <Editor doc={activeDoc} {onSaved} />
      {/if}
    </div>
  </main>

  {#if aiOpen}
    <div class="ai">
      <AIPanel
        doc={activeDoc}
        web={store.web}
        engineReady={store.engineReady}
        engineLabel={store.engineLabel}
        onRequestInstall={oninstall}
      />
    </div>
  {/if}
</div>

{#if presenting}
  <Presentation slides={presentSlides} onclose={() => (presenting = false)} />
{/if}

<style>
  .layout {
    display: grid;
    grid-template-columns: 272px minmax(0, 1fr) 348px;
    height: 100vh;
    height: 100dvh;
    min-height: 0;
    overflow: hidden;
    background: var(--bg);
  }
  .layout.ai-closed { grid-template-columns: 272px minmax(0, 1fr); }
  main {
    display: flex;
    flex-direction: column;
    min-width: 0;
    min-height: 0;
    overflow: hidden;
  }
  .fmt {
    font: inherit; font-size: 12px; padding: 4px 6px; border-radius: 8px;
    border: 1px solid var(--border); background: var(--bg); color: var(--text);
    max-width: 190px;
  }
  .exportnote {
    font-size: 11px; max-width: 240px;
    white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
  }
  .topbar {
    display: flex; align-items: center; gap: 10px;
    padding: 8px 14px; border-bottom: 1px solid var(--border);
    background: var(--bg-elev); min-height: 41px; flex: none;
  }
  .crumb { font-size: 12.5px; color: var(--text-soft); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .editor-area { flex: 1; min-height: 0; display: flex; flex-direction: column; overflow: hidden; }
  .ai { min-width: 0; min-height: 0; overflow: hidden; }
  @media (max-width: 1180px) {
    .layout { grid-template-columns: 232px minmax(0, 1fr); }
    .ai { display: none; }
  }
</style>
