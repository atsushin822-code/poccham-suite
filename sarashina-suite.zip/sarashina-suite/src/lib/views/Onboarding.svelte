<script lang="ts">
  import { onMount } from "svelte";
  import ModelCard from "../components/ModelCard.svelte";
  import { api, subscribe } from "../api";
  import { store } from "../stores/app.svelte";
  import { t } from "../i18n.svelte";
  import type { DownloadEvent } from "../types";

  let { ondone }: { ondone: () => void } = $props();

  let progress = $state<Record<string, DownloadEvent>>({});
  let error = $state<string | null>(null);
  let phase = $state<"idle" | "downloading" | "loading" | "ready">("idle");
  let unsub: (() => void) | undefined;
  // completed は 1 回だけ処理する（二重発火しても遷移が重ならないように）
  const handled = new Set<string>();

  onMount(() => {
    void init();
    return () => unsub?.();
  });

  async function init() {
    await store.refreshModels();
    unsub = await subscribe<DownloadEvent>("download://progress", (event) => {
      progress = { ...progress, [event.modelId]: event };
      if (event.phase === "failed") {
        error = event.message ?? t("model.failed");
        phase = "idle";
      }
      if (event.phase === "cancelled") {
        error = null;
        phase = "idle";
        void store.refreshModels();
      }
      if (event.phase === "completed") {
        if (handled.has(event.modelId)) return;
        handled.add(event.modelId);
        void finish(event.modelId);
      }
    });
  }

  /**
   * ダウンロード完了後の流れ。
   * ① 台帳（installed）に反映されるまで待つ → ② エンジンが ready になるまで待つ → ③ 進む
   * （以前は「completed を受けたら 900ms で遷移」だったため、モデル未登録のまま進むことがあった）
   */
  async function finish(modelId: string) {
    error = null;
    phase = "loading";
    const installed = await store.waitForInstalled(modelId, 20_000);
    if (!installed) {
      error = t("model.failed");
      phase = "idle";
      handled.delete(modelId);
      return;
    }
    // アクティブモデルが無ければこのモデルを使う
    if (!store.info?.activeModelId || !store.models.some((m) => m.installed && m.id === store.info?.activeModelId)) {
      await api.activateModel(modelId).catch(() => {});
      await store.refreshModels();
    }
    await store.waitForEngine(120_000);
    phase = "ready";
    setTimeout(ondone, 700);
  }

  async function download(id: string) {
    error = null;
    handled.delete(id);
    phase = "downloading";
    try {
      await api.downloadModel(id);
    } catch (e) {
      error = e instanceof Error ? e.message : String(e);
      phase = "idle";
    }
  }

  async function cancel(id: string) {
    await api.cancelDownload(id).catch(() => {});
    phase = "idle";
    // キャンセル後は .part の残量が変わらないことがあるので少し待ってから再読込
    setTimeout(() => void store.refreshModels(), 400);
  }

  async function remove(id: string) {
    await api.deleteModel(id);
    await store.refreshModels();
  }

  async function activate(id: string) {
    await api.activateModel(id);
    await store.refreshModels();
  }
</script>

<div class="onboarding scroll">
  <div class="inner">
    <header>
      <div class="badge">{t("onb.badge")}</div>
      <h1>{store.userName ? t("onb.title", { name: store.userName }) : t("app.name")}</h1>
      <p class="lead">{t("onb.lead")} — {t("app.name")}</p>
      <div class="facts">
        <div><span class="k">{t("onb.engine")}</span><span class="v">llama.cpp（CPU / Metal / CUDA / Vulkan）</span></div>
        <div><span class="k">{t("onb.modelsDir")}</span><span class="v mono">{store.info?.modelsDir ?? "—"}</span></div>
        <div><span class="k">{t("onb.backend")}</span><span class="v mono">{store.info?.backend ?? "—"}</span></div>
      </div>
    </header>

    {#if error}
      <div class="error">{error}</div>
    {/if}
    {#if phase === "loading"}
      <div class="status">{t("onb.preparing")}</div>
    {:else if phase === "ready"}
      <div class="status ok">{t("onb.ready")}</div>
    {/if}

    <div class="cards">
      {#each store.models as model (model.id)}
        <ModelCard
          {model}
          progress={progress[model.id] ?? null}
          busy={phase === "loading"}
          active={store.info?.activeModelId === model.id || store.engine?.modelId === model.id}
          ondownload={download}
          oncancel={cancel}
          ondelete={remove}
          onactivate={activate}
        />
      {/each}
    </div>

    <footer>
      <p class="faint small">{t("onb.resume")}</p>
      <button class="ghost" onclick={ondone}>{t("onb.later")}</button>
    </footer>
  </div>
</div>

<style>
  .onboarding { height: 100vh; height: 100dvh; overflow-y: auto; overscroll-behavior: contain; background: var(--bg); }
  .inner { max-width: 880px; margin: 0 auto; padding: 56px 32px 80px; }
  header { margin-bottom: 28px; }
  .badge {
    display: inline-block; font-size: 11px; letter-spacing: 0.06em;
    padding: 3px 10px; border-radius: 999px; margin-bottom: 14px;
    background: var(--accent-soft); color: var(--accent-text); font-weight: 600;
  }
  h1 { font-size: 28px; margin: 0 0 12px; letter-spacing: -0.015em; }
  .lead { font-size: 14px; color: var(--text-soft); margin: 0 0 18px; line-height: 1.85; max-width: 62ch; }
  .facts {
    display: grid; gap: 6px; font-size: 12.5px;
    border: 1px solid var(--border); border-radius: var(--radius);
    padding: 12px 14px; background: var(--bg-elev);
  }
  .facts div { display: flex; gap: 12px; }
  .k { color: var(--text-faint); width: 62px; flex: none; }
  .v { color: var(--text-soft); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .cards { display: flex; flex-direction: column; gap: 12px; }
  .error {
    margin-bottom: 14px; padding: 11px 13px; border-radius: 10px; font-size: 13px;
    color: var(--danger); background: rgba(220, 38, 38, 0.07);
    border: 1px solid rgba(220, 38, 38, 0.2); white-space: pre-wrap;
  }
  .status {
    margin-bottom: 14px; padding: 11px 13px; border-radius: 10px; font-size: 13px;
    background: var(--accent-soft); color: var(--accent-text);
  }
  .status.ok { background: rgba(15, 157, 88, 0.1); color: var(--ok); }
  footer { margin-top: 26px; display: flex; align-items: center; justify-content: space-between; gap: 16px; }
  .small { font-size: 11.5px; line-height: 1.7; max-width: 52ch; margin: 0; }
</style>
