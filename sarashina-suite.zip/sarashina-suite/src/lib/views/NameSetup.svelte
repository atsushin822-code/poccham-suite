<script lang="ts">
  // 初回起動のセットアップ。名前を入力してもらうだけで、アプリがその人向けになる。
  import { LOCALES, LOCALE_LABEL, systemLocale, t, type Locale } from "../i18n.svelte";
  import { store } from "../stores/app.svelte";

  let { ondone }: { ondone: () => void } = $props();

  let name = $state(store.userName);
  let locale = $state<Locale | "auto">(store.localeSetting);
  let busy = $state(false);

  async function pick(next: Locale | "auto") {
    locale = next;
    await store.setLocale(next);
  }

  async function start() {
    busy = true;
    try {
      await store.setUserName(name);
    } finally {
      busy = false;
      ondone();
    }
  }

  function onKeydown(event: KeyboardEvent) {
    if (event.key === "Enter") {
      event.preventDefault();
      void start();
    }
  }

  const detected = systemLocale();
</script>

<div class="setup">
  <div class="card">
    <div class="mark">P</div>
    <div class="badge">{t("setup.hello")}</div>
    <h1>{t("setup.title")}</h1>
    <p class="lead">{t("setup.lead")}</p>

    <label class="field">
      <span>{t("setup.nameLabel")}</span>
      <!-- 透かし文字（placeholder）は使わない -->
      <input
        bind:value={name}
        onkeydown={onKeydown}
        aria-label={t("setup.nameLabel")}
        maxlength="40"
        autocomplete="off"
      />
    </label>

    <label class="field">
      <span>{t("setup.language")}</span>
      <select
        value={locale}
        onchange={(e) => pick((e.currentTarget as HTMLSelectElement).value as Locale | "auto")}
        aria-label={t("setup.language")}
      >
        <option value="auto">{t("setup.auto")}（{LOCALE_LABEL[detected]}）</option>
        {#each LOCALES as code (code)}
          <option value={code}>{LOCALE_LABEL[code]}</option>
        {/each}
      </select>
    </label>

    <div class="actions">
      <button class="primary" onclick={start} disabled={busy}>{t("setup.start")}</button>
      <button class="ghost" onclick={ondone}>{t("setup.skip")}</button>
    </div>
  </div>
</div>

<style>
  .setup {
    height: 100vh;
    display: grid;
    place-items: center;
    background: radial-gradient(circle at 20% 20%, var(--accent-soft), var(--bg) 60%);
    padding: 24px;
    overflow-y: auto;
  }
  .card {
    width: min(460px, 100%);
    background: var(--bg-elev);
    border: 1px solid var(--border);
    border-radius: var(--radius-lg);
    box-shadow: var(--shadow-md);
    padding: 30px 28px 26px;
    display: flex;
    flex-direction: column;
    gap: 16px;
  }
  .mark {
    width: 46px;
    height: 46px;
    border-radius: 14px;
    background: linear-gradient(135deg, var(--accent), #22d3ee);
    color: #fff;
    font-size: 22px;
    font-weight: 700;
    display: grid;
    place-items: center;
    box-shadow: var(--shadow-sm);
  }
  .badge {
    align-self: flex-start; font-size: 11px; font-weight: 600; letter-spacing: 0.05em;
    padding: 3px 10px; border-radius: 999px;
    background: var(--accent-soft); color: var(--accent-text);
  }
  h1 { margin: 0; font-size: 23px; letter-spacing: -0.01em; line-height: 1.35; }
  .lead { margin: 0; font-size: 13px; color: var(--text-soft); line-height: 1.8; }
  .field { display: flex; flex-direction: column; gap: 6px; font-size: 12px; color: var(--text-soft); }
  .field input, .field select { width: 100%; font-size: 14px; padding: 10px 12px; }
  .actions { display: flex; align-items: center; gap: 8px; margin-top: 4px; }
  .actions button { padding: 9px 18px; }
</style>
