// スライドの純ロジック。保存形式は HTML の section 連なり:
//   <section data-slide="1" data-layout="content" data-transition="fade"
//            data-notes="発表者メモ" data-img="data:...">
//     <h2>見出し</h2><p>本文</p>
//   </section>
// これにより既存の保存・検索・書き出し（HTML→md/txt）がそのまま使える。

export type SlideLayout = "title" | "section" | "content" | "twoCol" | "image" | "quote";
export type SlideTransition = "none" | "fade" | "slide" | "zoom";

export const LAYOUTS: SlideLayout[] = ["title", "section", "content", "twoCol", "image", "quote"];
export const TRANSITIONS: SlideTransition[] = ["none", "fade", "slide", "zoom"];

export interface Slide {
  title: string;
  body: string;
  /** スライドに貼る画像（data URI か https URL）。未設定なら画像なし */
  image?: string;
  /** 発表者メモ（スライドショーでは観客に見せない） */
  notes?: string;
  layout?: SlideLayout;
  transition?: SlideTransition;
}

const escapeHtml = (t: string) =>
  t.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

export function emptySlide(index = 1, layout: SlideLayout = "content"): Slide {
  return {
    title: index === 1 ? "新しいスライド" : `スライド ${index}`,
    body: "",
    layout: index === 1 ? "title" : layout,
  };
}

export function slidesToHtml(slides: Slide[]): string {
  return slides
    .map((s) => {
      const body = escapeHtml(s.body).replace(/\r?\n/g, "<br>");
      const attrs = [
        s.image ? `data-img="${escapeJsAttr(s.image)}"` : "",
        s.layout && s.layout !== "content" ? `data-layout="${s.layout}"` : "",
        s.transition && s.transition !== "none" ? `data-transition="${s.transition}"` : "",
        s.notes ? `data-notes="${escapeJsAttr(s.notes)}"` : "",
      ].filter(Boolean).join(" ");
      return `<section data-slide="1"${attrs ? ` ${attrs}` : ""}><h2>${escapeHtml(s.title)}</h2><p>${body}</p></section>`;
    })
    .join("");
}

const escapeJsAttr = (t: string) => escapeHtml(t).replace(/\r?\n/g, "&#10;");

function unescapeAttr(value: string): string {
  return value
    .replace(/&#10;/g, "\n")
    .replace(/&quot;/g, '"')
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&amp;/g, "&");
}

export function htmlToSlides(html: string): Slide[] {
  if (!html.trim()) return [emptySlide()];
  try {
    const doc = new DOMParser().parseFromString(html, "text/html");
    const sections = Array.from(doc.querySelectorAll("section"));
    if (sections.length === 0) {
      // 旧形式（ただの HTML）は 1 枚のスライドとして取り込む
      return [{ title: doc.querySelector("h1,h2")?.textContent ?? "スライド 1", body: doc.body.textContent ?? "", layout: "title" }];
    }
    return sections.map((sec, i) => {
      const image = sec.getAttribute("data-img") ?? undefined;
      const notesRaw = sec.getAttribute("data-notes") ?? undefined;
      const layoutRaw = sec.getAttribute("data-layout") as SlideLayout | null;
      const transRaw = sec.getAttribute("data-transition") as SlideTransition | null;
      const slide: Slide = {
        title: sec.querySelector("h2")?.textContent ?? `スライド ${i + 1}`,
        body: (sec.querySelector("p")?.innerHTML ?? "")
          .replace(/<br\s*\/?>/gi, "\n")
          .replace(/<[^>]+>/g, ""),
      };
      if (image) slide.image = image;
      if (notesRaw) slide.notes = unescapeAttr(notesRaw);
      if (layoutRaw && LAYOUTS.includes(layoutRaw)) slide.layout = layoutRaw;
      if (transRaw && TRANSITIONS.includes(transRaw)) slide.transition = transRaw;
      return slide;
    });
  } catch {
    return [emptySlide()];
  }
}

export function slidesToText(slides: Slide[]): string {
  return slides
    .map((s, i) => {
      const head = `[${i + 1}] ${s.title}`;
      const body = s.body.trim();
      const notes = s.notes?.trim() ? `\n（メモ）${s.notes.trim()}` : "";
      return `${head}\n${body}${notes}`.trim();
    })
    .join("\n\n");
}

/** 本文を「行 → 箇条書き項目」に分解する（2 列レイアウトでは空行で分割） */
export function splitBody(slide: Slide): { left: string[]; right: string[] } {
  const lines = slide.body.split(/\r?\n/).map((l) => l.trim()).filter((l) => l !== "");
  if (slide.layout !== "twoCol") return { left: lines, right: [] };
  const blank = slide.body.indexOf("\n\n");
  if (blank < 0) {
    const mid = Math.ceil(lines.length / 2);
    return { left: lines.slice(0, mid), right: lines.slice(mid) };
  }
  const left = slide.body.slice(0, blank).split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  const right = slide.body.slice(blank).split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  return { left, right };
}

/** スライドショーの総所要時間の目安（秒）*/
export function estimatedSeconds(slides: Slide[]): number {
  return slides.reduce((acc, s) => acc + 4 + Math.ceil(s.body.length / 40), 0);
}
