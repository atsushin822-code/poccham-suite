// スライドの純ロジック。保存形式は HTML の section 連なり:
//   <section data-slide="1"><h2>見出し</h2><p>1行目<br>2行目</p></section>
// これにより既存の保存・検索・書き出し（HTML→md/txt）がそのまま使える。

export interface Slide {
  title: string;
  body: string;
}

const escapeHtml = (t: string) =>
  t.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

export function emptySlide(index = 1): Slide {
  return { title: index === 1 ? "新しいスライド" : `スライド ${index}`, body: "" };
}

export function slidesToHtml(slides: Slide[]): string {
  return slides
    .map((s) => {
      const body = escapeHtml(s.body).replace(/\r?\n/g, "<br>");
      return `<section data-slide="1"><h2>${escapeHtml(s.title)}</h2><p>${body}</p></section>`;
    })
    .join("");
}

export function htmlToSlides(html: string): Slide[] {
  if (!html.trim()) return [emptySlide()];
  try {
    const doc = new DOMParser().parseFromString(html, "text/html");
    const sections = Array.from(doc.querySelectorAll("section"));
    if (sections.length === 0) {
      // 旧形式（ただの HTML）は 1 枚のスライドとして取り込む
      return [{ title: doc.querySelector("h1,h2")?.textContent ?? "スライド 1", body: doc.body.textContent ?? "" }];
    }
    return sections.map((sec, i) => ({
      title: sec.querySelector("h2")?.textContent ?? `スライド ${i + 1}`,
      body: (sec.querySelector("p")?.innerHTML ?? "")
        .replace(/<br\s*\/?>/gi, "\n")
        .replace(/<[^>]+>/g, ""),
    }));
  } catch {
    return [emptySlide()];
  }
}

export function slidesToText(slides: Slide[]): string {
  return slides
    .map((s, i) => `[${i + 1}] ${s.title}\n${s.body}`.trim())
    .join("\n\n");
}
