// アプリ全体で共有する状態（Svelte 5 runes をモジュール内で使う）
import { api, isWeb, subscribe } from "../api";
import { i18n, normalizeLocale, systemLocale, type Locale } from "../i18n.svelte";
import type { AppInfo, EngineStatus, ModelView } from "../types";

class AppStore {
  info = $state<AppInfo | null>(null);
  models = $state<ModelView[]>([]);
  engine = $state<EngineStatus | null>(null);
  booting = $state(true);
  /** 静的 Web 版（ブラウザ配信）で動作中か */
  web = $state(isWeb);
  demo = $state(false);
  /** 初期セットアップで入力した名前（未設定なら空） */
  userName = $state("");
  /** 表示言語の設定（"auto" = システム言語に追従） */
  localeSetting = $state<Locale | "auto">("auto");

  /** モデルが 1 つでもインストール済みか（= AI が使える状態か） */
  get hasModel(): boolean {
    return this.models.some((m) => m.installed);
  }

  /** 推論エンジンが実際に使える状態か */
  get engineReady(): boolean {
    return this.engine?.state === "ready";
  }

  get activeModel(): ModelView | null {
    const id = this.engine?.modelId ?? this.info?.activeModelId;
    return this.models.find((m) => m.id === id) ?? null;
  }

  /** 画面に出す実行環境ラベル */
  get envLabel(): string {
    if (this.web) return i18n.translate("nav.offline");
    if (this.demo) return i18n.translate("nav.demo");
    return i18n.translate("nav.offline");
  }

  get engineLabel(): string {
    if (this.web) return i18n.translate("nav.webNoAi");
    if (this.demo) return i18n.translate("nav.demo");
    switch (this.engine?.state) {
      case "ready":
        return i18n.translate("ai.ready");
      case "loading":
        return i18n.translate("onb.preparing");
      case "generating":
        return i18n.translate("model.downloading");
      case "error":
        return i18n.translate("common.error");
      default:
        return i18n.translate("model.preparing");
    }
  }

  async boot(): Promise<void> {
    try {
      const [info, models, engine] = await Promise.all([
        api.appInfo(),
        api.listModels(),
        api.engineStatus(),
      ]);
      this.info = info;
      this.models = models;
      this.engine = engine;
      this.demo = info.backend.startsWith("demo");

      await this.loadProfile();

      await subscribe<EngineStatus>("engine://status", (status) => {
        this.engine = status;
      });
    } finally {
      this.booting = false;
    }
  }

  /** 名前と言語の設定を読み込む（未設定ならシステム言語を使う） */
  async loadProfile(): Promise<void> {
    const [name, locale] = await Promise.all([
      api.settingGet("user_name").catch(() => null),
      api.settingGet("locale").catch(() => null),
    ]);
    this.userName = name?.trim() ?? "";
    const normalized = normalizeLocale(locale);
    if (normalized) {
      this.localeSetting = normalized;
      i18n.set(normalized, false);
    } else {
      this.localeSetting = "auto";
      i18n.set(systemLocale(), true);
    }
  }

  async setUserName(name: string): Promise<void> {
    const trimmed = name.trim();
    this.userName = trimmed;
    await api.settingSet("user_name", trimmed);
  }

  async setLocale(locale: Locale | "auto"): Promise<void> {
    this.localeSetting = locale;
    if (locale === "auto") {
      i18n.set(systemLocale(), true);
      await api.settingSet("locale", "");
    } else {
      i18n.set(locale, false);
      await api.settingSet("locale", locale);
    }
  }

  async refreshModels(): Promise<void> {
    this.models = await api.listModels();
    this.engine = await api.engineStatus();
  }

  /** モデルのインストールが台帳に反映されるまで待つ（download 完了イベント直後の競合対策） */
  async waitForInstalled(modelId: string, timeoutMs = 20_000): Promise<boolean> {
    const started = Date.now();
    for (;;) {
      await this.refreshModels();
      if (this.models.find((m) => m.id === modelId)?.installed) return true;
      if (Date.now() - started > timeoutMs) return false;
      await new Promise((r) => setTimeout(r, 400));
    }
  }

  /** 推論エンジンが ready になるまで待つ */
  async waitForEngine(timeoutMs = 90_000): Promise<boolean> {
    const started = Date.now();
    for (;;) {
      const status = await api.engineStatus();
      this.engine = status;
      if (status.state === "ready") return true;
      if (status.state === "error") return false;
      if (Date.now() - started > timeoutMs) return false;
      await new Promise((r) => setTimeout(r, 600));
    }
  }
}

export const store = new AppStore();
