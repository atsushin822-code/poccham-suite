// Rust 側 DTO（serde rename_all = "camelCase"）と 1:1 で対応する型定義。
// 変更時は crates/sarashina-core/src/db.rs と必ずセットで更新すること。

export type DocumentKind = "doc" | "sheet" | "slide";

export interface DocumentSummary {
  id: string;
  title: string;
  kind: DocumentKind;
  preview: string;
  pinned: boolean;
  createdAt: number;
  updatedAt: number;
}

export interface Doc {
  id: string;
  title: string;
  kind: DocumentKind;
  content: string;
  plainText: string;
  pinned: boolean;
  createdAt: number;
  updatedAt: number;
}

export interface SearchHit {
  id: string;
  title: string;
  snippet: string;
  updatedAt: number;
}

export interface AppInfo {
  version: string;
  backend: string;
  platform: string;
  dataDir: string;
  dbPath: string;
  modelsDir: string;
  cacheDir: string;
  activeModelId: string | null;
  recommendedModelId: string;
}

export type ModelStatus = "notInstalled" | "partial" | "downloading" | "installed" | "broken";

export interface ModelView {
  id: string;
  displayName: string;
  family: string;
  params: string;
  quant: string;
  fileName: string;
  sizeBytes: number;
  sha256: string | null;
  minRamGb: number;
  recommended: boolean;
  description: string;
  status: ModelStatus;
  installed: boolean;
  path: string | null;
  downloadedBytes: number;
  lastUsedAt: number | null;
}

export interface EngineStatus {
  state: "unloaded" | "loading" | "ready" | "generating" | "error";
  backend: string;
  modelId: string | null;
  modelPath: string | null;
  nCtx: number;
  message: string | null;
}

export type DownloadPhase = "preparing" | "downloading" | "verifying" | "completed" | "cancelled" | "failed";

export interface DownloadEvent {
  modelId: string;
  phase: DownloadPhase;
  downloaded: number;
  total: number;
  bytesPerSec: number;
  etaSecs: number | null;
  message: string | null;
}

export interface ChatTurn {
  role: "system" | "user" | "assistant";
  content: string;
}

export interface ChatMessageRow {
  id: string;
  sessionId: string;
  role: "system" | "user" | "assistant";
  content: string;
  createdAt: number;
}

export interface GenOptions {
  maxTokens: number;
  temperature: number;
  topP: number;
  topK: number;
  repeatPenalty: number;
  seed: number;
  nCtx: number;
}

export interface GenStats {
  promptTokens: number;
  completionTokens: number;
  elapsedMs: number;
  tokensPerSec: number;
  cancelled: boolean;
  finishReason: string;
}

export interface DbStats {
  documents: number;
  characters: number;
  chatMessages: number;
  models: number;
  schemaVersion: number;
}

export const DEFAULT_GEN_OPTIONS: GenOptions = {
  maxTokens: 512,
  temperature: 0.7,
  topP: 0.95,
  topK: 40,
  repeatPenalty: 1.1,
  seed: 0,
  nCtx: 0,
};
