// ブラウザ単体（`npm run dev` を Tauri なしで開いた場合）で UI を確認するための
// インメモリ・モックバックエンド。Tauri 実行時は一切使われない。

import type {
  AppInfo, ChatMessageRow, ChatTurn, DbStats, Doc, DocumentKind, DocumentSummary, DownloadEvent,
  EngineStatus, GenOptions, GenStats, ModelView, SearchHit,
} from "./types";

export type Emit = (event: string, payload: unknown) => void;

// 種別ごとの既定タイトル
export const DEFAULT_TITLE: Record<DocumentKind, string> = {
  doc: "無題のドキュメント",
  sheet: "無題の表計算",
  slide: "無題のスライド",
};


const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
const now = () => Date.now();

const SAMPLE_MODELS: ModelView[] = [
  {
    id: "sarashina-1b-q4_k_m",
    displayName: "Poccham 1B (Q4_K_M)",
    family: "Poccham", params: "1B", quant: "Q4_K_M",
    fileName: "sarashina2.2-1b-instruct-v0.1-Q4_K_M.gguf",
    sizeBytes: 931_179_392, sha256: "750b8837…21d0c2", minRamGb: 4, recommended: true,
    description: "軽量・高速。CPU のみでも快適。校正・要約・箇条書き生成向け。",
    status: "notInstalled", installed: false, path: null, downloadedBytes: 0, lastUsedAt: null,
  },
  {
    id: "sarashina-1b-q8_0",
    displayName: "Poccham 1B (Q8_0)",
    family: "Poccham", params: "1B", quant: "Q8_0",
    fileName: "sarashina2.2-1b-instruct-v0.1-Q8_0.gguf",
    sizeBytes: 1_498_333_056, sha256: "f26ea13b…c89935", minRamGb: 6, recommended: false,
    description: "1B のほぼロスレス版。品質重視だが RAM 消費は増える。",
    status: "notInstalled", installed: false, path: null, downloadedBytes: 0, lastUsedAt: null,
  },
  {
    id: "sarashina-3b-q4_k_m",
    displayName: "Poccham 3B (Q4_K_M)",
    family: "Poccham", params: "3B", quant: "Q4_K_M",
    fileName: "sarashina2.2-3b-instruct-v0.1-Q4_K_M.gguf",
    sizeBytes: 2_066_390_112, sha256: "d96f4d98…9038f0f2", minRamGb: 8, recommended: false,
    description: "長文の構成や推論が得意。8GB 以上の RAM か GPU 搭載機向け。",
    status: "notInstalled", installed: false, path: null, downloadedBytes: 0, lastUsedAt: null,
  },
];

const DEMO_REPLY = `要点を整理すると、次の3点に集約できます。

1. **目的の明確化** — 誰に向けた文書かを最初に固定すると、以降の推敲が速くなります。
2. **構成の単純化** — 見出しは3階層までに抑え、1セクション1メッセージを守ります。
3. **表現の統一** — です・ます調と断定調を混在させないことが読みやすさに直結します。

（これはデモモードの応答です。デスクトップアプリとして起動すると、ローカルに保存したモデルで Poccham AI が実際に推論します。）`;

export class DemoBackend {
  private docs: Doc[] = [];
  private messages = new Map<string, ChatMessageRow[]>();
  private models = SAMPLE_MODELS.map((m) => ({ ...m }));
  private engine: EngineStatus = {
    state: "unloaded", backend: "demo", modelId: null, modelPath: null, nCtx: 0,
    message: "デモモード（ブラウザ実行）",
  };
  private cancelled = new Set<string>();
  private downloads = new Map<string, boolean>();

  constructor(private emit: Emit) {
    const seed: Array<[string, string]> = [
      ["四半期レビュー議事録", "<h1>四半期レビュー</h1><p>売上は前年比 120% で着地した。来期は保守運用の自動化に投資する。</p>"],
      ["新製品の企画メモ", "<h2>コンセプト</h2><p>オフラインで完結する文書作成環境。通信できない現場でも使えることを最優先にする。</p>"],
    ];
    this.docs = seed.map(([title, content], i) => ({
      id: `demo-${i + 1}`,
      title,
      kind: "doc",
      content,
      plainText: content.replace(/<[^>]+>/g, ""),
      pinned: i === 0,
      createdAt: now() - (i + 1) * 86_400_000,
      updatedAt: now() - i * 3_600_000,
    }));
  }

  appInfo(): AppInfo {
    return {
      version: "0.2.0", backend: "demo (browser)", platform: "web",
      dataDir: "(ブラウザのため未使用)", dbPath: "(未使用)", modelsDir: "(未使用)", cacheDir: "(未使用)",
      activeModelId: this.models.find((m) => m.installed)?.id ?? null,
      recommendedModelId: "sarashina-1b-q4_k_m",
    };
  }

  dbStats(): DbStats {
    return {
      documents: this.docs.length,
      characters: this.docs.reduce((n, d) => n + d.plainText.length, 0),
      chatMessages: [...this.messages.values()].reduce((n, m) => n + m.length, 0),
      models: this.models.filter((m) => m.installed).length,
      schemaVersion: 1,
    };
  }

  settingGet(): string | null {
    return null;
  }
  settingSet(): void {}

  listDocuments(): DocumentSummary[] {
    return [...this.docs]
      .sort((a, b) => Number(b.pinned) - Number(a.pinned) || b.updatedAt - a.updatedAt)
      .map((d) => ({
        id: d.id, title: d.title, kind: d.kind, preview: d.plainText.slice(0, 140),
        pinned: d.pinned, createdAt: d.createdAt, updatedAt: d.updatedAt,
      }));
  }

  getDocument(id: string): Doc | null {
    return this.docs.find((d) => d.id === id) ?? null;
  }

  createDocument(title?: string | null, kind: DocumentKind = "doc"): Doc {
    const doc: Doc = {
      id: `demo-${crypto.randomUUID()}`,
      title: title?.trim() || DEFAULT_TITLE[kind],
      kind, content: "", plainText: "", pinned: false,
      createdAt: now(), updatedAt: now(),
    };
    this.docs.push(doc);
    return doc;
  }

  saveDocument(id: string, title: string, content: string, plainText: string): number {
    const doc = this.docs.find((d) => d.id === id);
    if (doc) {
      doc.title = title.trim() || "無題のドキュメント";
      doc.content = content;
      doc.plainText = plainText;
      doc.updatedAt = now();
    }
    return now();
  }

  deleteDocument(id: string): void {
    this.docs = this.docs.filter((d) => d.id !== id);
  }

  pinDocument(id: string, pinned: boolean): void {
    const doc = this.docs.find((d) => d.id === id);
    if (doc) doc.pinned = pinned;
  }

  searchDocuments(query: string): SearchHit[] {
    const q = query.trim();
    if (!q) return [];
    return this.docs
      .filter((d) => d.title.includes(q) || d.plainText.includes(q))
      .map((d) => ({
        id: d.id, title: d.title,
        snippet: d.plainText.replace(q, `<<${q}>>`).slice(0, 120),
        updatedAt: d.updatedAt,
      }));
  }

  exportDocument(id: string, format: string): { path: string; format: string } {
    const doc = this.docs.find((d) => d.id === id);
    const blob = new Blob([doc?.content ?? ""], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${doc?.title ?? "document"}.${format === "markdown" ? "md" : format}`;
    a.click();
    URL.revokeObjectURL(url);
    return { path: a.download, format };
  }

  saveExportFile(name: string, base64: string): string {
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i);
    const blob = new Blob([bytes], { type: "application/octet-stream" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = name;
    a.click();
    URL.revokeObjectURL(url);
    return name;
  }

  exportsDir(): string {
    return "ダウンロード";
  }

  listModels(): ModelView[] {
    return this.models;
  }

  async downloadModel(modelId: string): Promise<void> {
    if (this.downloads.get(modelId)) return;
    this.downloads.set(modelId, true);
    const model = this.models.find((m) => m.id === modelId);
    if (!model) return;
    const total = model.sizeBytes;
    const start = model.downloadedBytes;
    const speed = 48 * 1024 * 1024; // 48MB/s
    let done = start;

    const push = (phase: DownloadEvent["phase"], message: string | null = null) => {
      const ev: DownloadEvent = {
        modelId, phase, downloaded: done, total,
        bytesPerSec: speed, etaSecs: Math.max(0, Math.round((total - done) / speed)),
        message,
      };
      this.emit("download://progress", ev);
    };

    push("preparing", "接続しています…");
    while (done < total) {
      if (this.cancelled.delete(`download:${modelId}`)) {
        push("cancelled", "ダウンロードを中断しました");
        this.downloads.delete(modelId);
        return;
      }
      await sleep(120);
      done = Math.min(total, done + speed * 0.12);
      model.downloadedBytes = done;
      model.status = "downloading";
      push("downloading");
    }
    push("verifying", "SHA-256 を検証しています…");
    await sleep(500);
    model.status = "installed";
    model.installed = true;
    model.path = `/Models/${model.fileName}`;
    model.downloadedBytes = total;
    model.lastUsedAt = now();
    push("completed", "インストール完了");
    this.downloads.delete(modelId);

    this.engine = {
      state: "ready", backend: "demo", modelId, modelPath: model.path, nCtx: 4096, message: null,
    };
    this.emit("engine://status", this.engine);
  }

  cancelDownload(modelId: string): void {
    this.cancelled.add(`download:${modelId}`);
  }

  deleteModel(modelId: string): void {
    const model = this.models.find((m) => m.id === modelId);
    if (model) {
      model.installed = false;
      model.status = "notInstalled";
      model.path = null;
      model.downloadedBytes = 0;
    }
    if (this.engine.modelId === modelId) {
      this.engine = { ...this.engine, state: "unloaded", modelId: null, modelPath: null };
      this.emit("engine://status", this.engine);
    }
  }

  activateModel(modelId: string): void {
    const model = this.models.find((m) => m.id === modelId);
    if (!model?.installed) return;
    this.engine = {
      state: "ready", backend: "demo", modelId, modelPath: model.path, nCtx: 4096, message: null,
    };
    this.emit("engine://status", this.engine);
  }

  engineStatus(): EngineStatus {
    return this.engine;
  }

  engineConfigure(nCtx: number): EngineStatus {
    this.engine = { ...this.engine, nCtx };
    return this.engine;
  }

  private session = new Map<string, string>();

  ensureSession(documentId: string | null): string {
    const key = documentId ?? "global";
    if (!this.session.has(key)) this.session.set(key, `demo-session-${key}`);
    return this.session.get(key)!;
  }

  listMessages(sessionId: string): ChatMessageRow[] {
    return this.messages.get(sessionId) ?? [];
  }

  appendMessage(sessionId: string, role: ChatMessageRow["role"], content: string): ChatMessageRow {
    const row: ChatMessageRow = {
      id: crypto.randomUUID(), sessionId, role, content, createdAt: now(),
    };
    const list = this.messages.get(sessionId) ?? [];
    list.push(row);
    this.messages.set(sessionId, list);
    return row;
  }

  async chatGenerate(requestId: string, messages: ChatTurn[], options?: Partial<GenOptions>): Promise<GenStats> {
    const started = Date.now();
    const maxTokens = options?.maxTokens ?? 512;
    const chars = [...DEMO_REPLY];
    let buffer = "";
    let tokens = 0;
    for (let i = 0; i < chars.length; i += 3) {
      if (this.cancelled.delete(requestId)) break;
      if (tokens >= maxTokens) break;
      await sleep(24);
      const delta = chars.slice(i, i + 3).join("");
      buffer += delta;
      tokens += 1;
      this.emit("llm://token", { requestId, delta });
    }
    const elapsedMs = Date.now() - started;
    const stats: GenStats = {
      promptTokens: messages.reduce((n, m) => n + Math.ceil(m.content.length / 1.5), 0),
      completionTokens: tokens,
      elapsedMs,
      tokensPerSec: tokens / Math.max(0.001, elapsedMs / 1000),
      cancelled: false,
      finishReason: "stop",
    };
    this.emit("llm://done", { requestId, ...stats });
    return { ...stats, cancelled: buffer.length === 0 };
  }

  chatCancel(requestId: string): void {
    this.cancelled.add(requestId);
  }
}
