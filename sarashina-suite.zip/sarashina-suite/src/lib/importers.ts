// ネイティブ形式（.docx / .xlsx / .csv / .pptx / .poccham）の取り込み。
//
// 方針:
//  * 外部ライブラリを使わない（zip.ts の ZIP リーダ + DOMParser だけで解析する）
//  * 取り込んだ内容は**アプリの保存形式そのもの**（doc = HTML / sheet = table / slide = section）に
//    変換する。こうすると保存・検索（FTS5）・書き出し・AI 連携がすべて既存経路のまま動く
//  * 解析に失敗したら ImportError（i18n キー付き）を投げ、UI が翻訳して表示する

import { htmlToPlainText } from "./format";
import { evaluateGrid, gridToHtml, SHEET_COLS, SHEET_ROWS, type Grid } from "./sheet";
import { slidesToHtml, slidesToText, type Slide } from "./slides";
import type { DocumentKind } from "./types";
import { readZip, type ZipArchive } from "./zip";

/** 取り込み可能な拡張子（`<input accept>` 用） */
export const IMPORT_ACCEPT = ".docx,.xlsx,.csv,.pptx,.poccham";

export interface ImportedDoc {
  title: string;
  kind: DocumentKind;
  content: string;
  plainText: string;
  /** 元ファイル名（複数シートを分割したときに使う） */
  source: string;
  /** 追加の注意（i18n キー）。例: 行数が上限を超えて切り詰めた */
  note?: string;
}

export class ImportError extends Error {
  /** i18n キー（imp.*） */
  readonly key: string;
  constructor(key: string) {
    super(key);
    this.name = "ImportError";
    this.key = key;
  }
}

// --- 汎用ヘルパ -----------------------------------------------------------

const escapeHtml = (text: string) =>
  text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");

const xmlParser = new DOMParser();

function parseXml(text: string): Document {
  const doc = xmlParser.parseFromString(text, "application/xml");
  if (doc.getElementsByTagName("parsererror").length > 0) throw new ImportError("imp.broken");
  return doc;
}

const local = (el: Element): string => el.localName ?? el.nodeName.replace(/^.*:/, "");

/** 名前空間接頭辞に依存せず属性を読む（w:val / a:val どちらでも拾う） */
function attr(el: Element | null | undefined, name: string): string | null {
  if (!el) return null;
  const direct = el.getAttribute(name);
  if (direct !== null) return direct;
  for (const a of Array.from(el.attributes)) {
    const ln = a.localName ?? a.name.replace(/^.*:/, "");
    if (ln === name) return a.value;
  }
  return null;
}

/** 子孫をすべて集める（同名の要素を深さ優先で） */
function findAll(root: Element | Document, name: string): Element[] {
  const out: Element[] = [];
  const start = "documentElement" in root ? root.documentElement : root;
  if (!start) return out;
  const walk = (node: Element) => {
    for (const child of Array.from(node.children)) {
      if (local(child) === name) out.push(child);
      walk(child);
    }
  };
  if (local(start) === name) out.push(start);
  walk(start);
  return out;
}

function childOf(el: Element | null, name: string): Element | null {
  if (!el) return null;
  for (const child of Array.from(el.children)) if (local(child) === name) return child;
  return null;
}

function base64(bytes: Uint8Array): string {
  let binary = "";
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
  }
  return btoa(binary);
}

const MIME_BY_EXT: Record<string, string> = {
  png: "image/png",
  jpg: "image/jpeg",
  jpeg: "image/jpeg",
  gif: "image/gif",
  bmp: "image/bmp",
  webp: "image/webp",
  svg: "image/svg+xml",
  tif: "image/tiff",
  tiff: "image/tiff",
  emf: "image/emf",
  wmf: "image/wmf",
};

function mimeOf(path: string): string {
  const ext = path.split(".").pop()?.toLowerCase() ?? "";
  return MIME_BY_EXT[ext] ?? "application/octet-stream";
}

/** リレーション（rId → パッケージ内パス）を読む */
function readRels(zip: ZipArchive, relsPath: string, baseDir: string): Map<string, string> {
  const map = new Map<string, string>();
  const text = zip.text(relsPath);
  if (!text) return map;
  const doc = parseXml(text);
  for (const rel of findAll(doc, "Relationship")) {
    const id = attr(rel, "Id");
    const target = attr(rel, "Target");
    if (!id || !target) continue;
    if (attr(rel, "TargetMode") === "External") {
      map.set(id, target);
      continue;
    }
    const normalized = target.startsWith("/")
      ? target.slice(1)
      : `${baseDir}${target}`.replace(/[^/]+\/\.\.\//g, "");
    map.set(id, normalized);
  }
  return map;
}

/** パッケージ内の画像を data URI にする（見つからなければ null） */
function mediaDataUri(zip: ZipArchive, path: string | undefined): string | null {
  if (!path) return null;
  if (/^https?:/i.test(path)) return null; // 外部参照は取り込まない（オフライン前提）
  const bytes = zip.bytes(path);
  if (!bytes || bytes.length === 0) return null;
  const mime = mimeOf(path);
  if (mime === "application/octet-stream") return null;
  return `data:${mime};base64,${base64(bytes)}`;
}

function baseName(fileName: string): string {
  const name = fileName.split(/[\\/]/).pop() ?? fileName;
  return name.replace(/\.[^.]+$/, "").trim() || name;
}

// --- .docx ----------------------------------------------------------------

interface DocxCtx {
  zip: ZipArchive;
  rels: Map<string, string>;
}

function drawingHtml(node: Element, ctx: DocxCtx): string {
  for (const blip of findAll(node, "blip")) {
    const embed = attr(blip, "embed") ?? attr(blip, "link");
    const uri = mediaDataUri(ctx.zip, embed ? ctx.rels.get(embed) : undefined);
    if (uri) return `<img src="${uri}" alt="" style="max-width:100%">`;
  }
  // 旧形式（VML）の <v:imagedata r:id>
  for (const img of findAll(node, "imagedata")) {
    const uri = mediaDataUri(ctx.zip, ctx.rels.get(attr(img, "id") ?? ""));
    if (uri) return `<img src="${uri}" alt="" style="max-width:100%">`;
  }
  return "";
}

function runHtml(run: Element, ctx: DocxCtx): string {
  let inner = "";
  for (const child of Array.from(run.children)) {
    const name = local(child);
    if (name === "t") inner += escapeHtml(child.textContent ?? "");
    else if (name === "tab") inner += "&nbsp;&nbsp;&nbsp;&nbsp;";
    else if (name === "br" || name === "cr") inner += "<br>";
    else if (name === "noBreakHyphen") inner += "-";
    else if (name === "drawing" || name === "pict" || name === "object") inner += drawingHtml(child, ctx);
    else if (name === "sym") inner += escapeHtml(child.textContent ?? "");
  }
  if (!inner) return "";
  const rPr = childOf(run, "rPr");
  if (rPr) {
    const flag = (name: string) => {
      const el = childOf(rPr, name);
      if (!el) return false;
      const value = attr(el, "val");
      return value === null || !/^(0|false|none|off)$/i.test(value);
    };
    if (flag("b")) inner = `<strong>${inner}</strong>`;
    if (flag("i")) inner = `<em>${inner}</em>`;
    if (flag("u")) inner = `<u>${inner}</u>`;
    if (flag("strike")) inner = `<s>${inner}</s>`;
  }
  return inner;
}

function inlineHtml(node: Element, ctx: DocxCtx): string {
  let html = "";
  for (const child of Array.from(node.children)) {
    const name = local(child);
    if (name === "r") html += runHtml(child, ctx);
    else if (name === "pPr" || name === "rPr") continue;
    else if (name === "hyperlink") {
      const inner = inlineHtml(child, ctx);
      if (!inner) continue;
      const href = ctx.rels.get(attr(child, "id") ?? "");
      html += href && /^https?:/i.test(href)
        ? `<a href="${escapeHtml(href)}" target="_blank" rel="noopener">${inner}</a>`
        : inner;
    } else if (name === "del") {
      const inner = inlineHtml(child, ctx);
      if (inner) html += `<s>${inner}</s>`;
    } else html += inlineHtml(child, ctx); // smartTag / ins / sdt / sdtContent など
  }
  return html;
}

function headingLevel(styleId: string | null): number {
  if (!styleId) return 0;
  const m = /^(?:Heading|見出し)\s*([1-6])$/i.exec(styleId.trim());
  if (m) return Number(m[1]);
  if (/^(Title|タイトル)$/i.test(styleId.trim())) return 1;
  return 0;
}

function docxHtml(zip: ZipArchive): { html: string; title: string | null } {
  const documentXml = zip.text("word/document.xml");
  if (!documentXml) throw new ImportError("imp.broken");
  const ctx: DocxCtx = { zip, rels: readRels(zip, "word/_rels/document.xml.rels", "word/") };
  const doc = parseXml(documentXml);
  const body = findAll(doc, "body")[0] ?? doc.documentElement;
  const out: string[] = [];
  let inList = false;
  let firstHeading = "";

  const closeList = () => {
    if (inList) {
      out.push("</ul>");
      inList = false;
    }
  };

  for (const block of Array.from(body.children)) {
    const name = local(block);
    if (name === "p") {
      const pPr = childOf(block, "pPr");
      const styleId = attr(childOf(pPr, "pStyle"), "val");
      // 箇条書きは「段落の numPr」か「リスト系スタイル」で判定する
      // （python-docx や Word は ListBullet / ListNumber などのスタイル名を使う）
      const numbered =
        Boolean(childOf(pPr, "numPr")) ||
        /^(List|ListParagraph|ListBullet|ListBullet2|ListNumber|ListNumber2|箇条書き|段落番号)/i.test(styleId ?? "");
      const inner = inlineHtml(block, ctx).trim();
      if (numbered) {
        if (!inList) {
          out.push("<ul>");
          inList = true;
        }
        out.push(`<li>${inner || "<br>"}</li>`);
        continue;
      }
      closeList();
      const level = headingLevel(styleId);
      if (level) {
        if (!firstHeading) firstHeading = plainOf(inner);
        out.push(`<h${level}>${inner || "<br>"}</h${level}>`);
      } else {
        out.push(`<p>${inner || "<br>"}</p>`);
      }
    } else if (name === "tbl") {
      closeList();
      // 表は表のまま取り込む（見出し行は trPr/tblHeader か、セルが太字なら th にする）
      const trs = findAll(block, "tr");
      const rowsHtml: string[] = [];
      trs.forEach((tr, rowIndex) => {
        const tcs = Array.from(tr.children).filter((tc) => local(tc) === "tc");
        if (!tcs.length) return;
        const headerFlag = Boolean(childOf(childOf(tr, "trPr"), "tblHeader"));
        const cells = tcs.map((tc) => {
          const text = findAll(tc, "p").map((p) => inlineHtml(p, ctx).trim()).filter(Boolean).join("<br>");
          const bold = findAll(tc, "b").length > 0;
          return { text: text || "<br>", bold };
        });
        const isHeader = headerFlag || (rowIndex === 0 && cells.every((c) => c.bold));
        const tag = isHeader ? "th" : "td";
        rowsHtml.push(`<tr>${cells.map((c) => `<${tag}>${c.text}</${tag}>`).join("")}</tr>`);
      });
      if (rowsHtml.length) out.push(`<table class="tbl"><tbody>${rowsHtml.join("")}</tbody></table>`);
    }
  }
  closeList();

  if (out.length === 0) throw new ImportError("imp.empty");

  // 文書タイトル（docProps/core.xml があれば優先）
  let title: string | null = null;
  const core = zip.text("docProps/core.xml");
  if (core) {
    const coreDoc = parseXml(core);
    const titleEl = findAll(coreDoc, "title")[0];
    const text = (titleEl?.textContent ?? "").trim();
    if (text) title = text;
  }
  if (!title && firstHeading) title = firstHeading.slice(0, 80);
  return { html: out.join(""), title };
}

function plainOf(html: string): string {
  const el = document.createElement("div");
  el.innerHTML = html;
  return (el.textContent ?? "").replace(/\s+/g, " ").trim();
}

// --- .xlsx ----------------------------------------------------------------

const SUPPORTED_FN = /^(SUM|AVERAGE|AVG|COUNT|MIN|MAX|ABS|ROUND)$/;

/**
 * このアプリの数式エンジンで評価できる式かどうか。
 * 評価できない関数（VLOOKUP など）は「計算済みの値」を文字として取り込む方が実用的。
 */
function isSupportedFormula(formula: string): boolean {
  const body = formula.replace(/"[^"]*"/g, "");
  if (/[![\]&|^']/.test(body)) return false;
  for (const match of body.matchAll(/([A-Za-z][A-Za-z0-9.]*)\s*\(/g)) {
    if (!SUPPORTED_FN.test(match[1].toUpperCase())) return false;
  }
  if (/[A-Za-z]+\s*:\s*[A-Za-z]+(?![0-9])/.test(body)) return false; // A:A 形式
  return true;
}

function sharedStrings(zip: ZipArchive): string[] {
  const text = zip.text("xl/sharedStrings.xml");
  if (!text) return [];
  const doc = parseXml(text);
  return findAll(doc, "si").map((si) =>
    findAll(si, "t")
      .map((t) => t.textContent ?? "")
      .join(""),
  );
}

function colFromRef(ref: string): number {
  const m = /^([A-Z]+)/i.exec(ref);
  if (!m) return -1;
  let n = 0;
  for (const ch of m[1].toUpperCase()) n = n * 26 + (ch.charCodeAt(0) - 64);
  return n - 1;
}

function cellText(cell: Element, shared: string[]): string {
  const type = attr(cell, "t") ?? "";
  if (type === "inlineStr") {
    return findAll(cell, "t")
      .map((t) => t.textContent ?? "")
      .join("");
  }
  const v = findAll(cell, "v")[0]?.textContent ?? "";
  if (type === "s") {
    const index = Number(v);
    return shared[index] ?? "";
  }
  if (type === "b") return v === "1" ? "TRUE" : v === "0" ? "FALSE" : v;
  return v;
}

function xlsxSheets(zip: ZipArchive): { name: string; grid: Grid; truncated: boolean }[] {
  const workbookPath = "xl/workbook.xml";
  const workbookXml = zip.text(workbookPath);
  if (!workbookXml) throw new ImportError("imp.broken");
  const rels = readRels(zip, "xl/_rels/workbook.xml.rels", "xl/");
  const shared = sharedStrings(zip);
  const workbook = parseXml(workbookXml);

  const declared = findAll(workbook, "sheet").map((sheet) => ({
    name: attr(sheet, "name") ?? "Sheet",
    path: rels.get(attr(sheet, "id") ?? "") ?? null,
  }));

  // r:id が読めない実装向けのフォールバック（worksheets/sheetN.xml を昇順に）
  const fallback = zip.names
    .filter((n) => /^xl\/worksheets\/sheet\d+\.xml$/.test(n))
    .sort((a, b) => Number(a.replace(/\D/g, "")) - Number(b.replace(/\D/g, "")));

  const targets = declared.length
    ? declared.map((s, i) => ({ name: s.name, path: s.path ?? fallback[i] ?? null }))
    : fallback.map((path, i) => ({ name: `Sheet${i + 1}`, path }));

  const result: { name: string; grid: Grid; truncated: boolean }[] = [];
  for (const target of targets) {
    if (!target.path) continue;
    const xml = zip.text(target.path);
    if (!xml) continue;
    const doc = parseXml(xml);
    const grid: Grid = Array.from({ length: SHEET_ROWS }, () =>
      Array.from({ length: SHEET_COLS }, () => ""),
    );
    let truncated = false;
    let rowIndex = 0;
    for (const row of findAll(doc, "row")) {
      const r = Number(attr(row, "r") ?? rowIndex + 1) - 1;
      rowIndex = r + 1;
      if (r < 0) continue;
      let c = 0;
      for (const cell of Array.from(row.children)) {
        if (local(cell) !== "c") continue;
        const ref = attr(cell, "r");
        const col = ref ? colFromRef(ref) : c;
        c = col + 1;
        if (r >= SHEET_ROWS || col < 0 || col >= SHEET_COLS) {
          truncated = true;
          continue;
        }
        const value = cellText(cell, shared);
        const formula = findAll(cell, "f")[0]?.textContent ?? "";
        if (formula && isSupportedFormula(formula)) {
          grid[r][col] = formula.startsWith("=") ? formula : `=${formula}`;
        } else {
          grid[r][col] = value;
        }
      }
    }
    result.push({ name: target.name, grid, truncated });
  }
  if (result.length === 0) throw new ImportError("imp.empty");
  return result;
}

// --- .csv -----------------------------------------------------------------

function detectDelimiter(text: string): string {
  const line = text.split(/\r?\n/, 1)[0] ?? "";
  const counts: [string, number][] = [
    [",", (line.match(/,/g) ?? []).length],
    [";", (line.match(/;/g) ?? []).length],
    ["\t", (line.match(/\t/g) ?? []).length],
  ];
  counts.sort((a, b) => b[1] - a[1]);
  return counts[0][1] > 0 ? counts[0][0] : ",";
}

/** RFC4180 ベースの CSV パーサ（引用符・改行入りセル対応） */
export function parseCsv(text: string, delimiter = detectDelimiter(text)): string[][] {
  const src = text.replace(/^\uFEFF/, "");
  const rows: string[][] = [];
  let row: string[] = [];
  let cell = "";
  let quoted = false;
  for (let i = 0; i < src.length; i += 1) {
    const ch = src[i];
    if (quoted) {
      if (ch === '"') {
        if (src[i + 1] === '"') {
          cell += '"';
          i += 1;
        } else quoted = false;
      } else cell += ch;
      continue;
    }
    if (ch === '"') {
      quoted = true;
      continue;
    }
    if (ch === delimiter) {
      row.push(cell);
      cell = "";
      continue;
    }
    if (ch === "\r") continue;
    if (ch === "\n") {
      row.push(cell);
      rows.push(row);
      row = [];
      cell = "";
      continue;
    }
    cell += ch;
  }
  if (cell !== "" || row.length) {
    row.push(cell);
    rows.push(row);
  }
  return rows.filter((r) => r.some((c) => c.trim() !== ""));
}

function csvToDoc(fileName: string, text: string): ImportedDoc {
  const rows = parseCsv(text);
  if (rows.length === 0) throw new ImportError("imp.empty");
  const grid: Grid = Array.from({ length: SHEET_ROWS }, () =>
    Array.from({ length: SHEET_COLS }, () => ""),
  );
  let truncated = false;
  rows.forEach((cells, r) => {
    if (r >= SHEET_ROWS) {
      truncated = true;
      return;
    }
    cells.forEach((value, c) => {
      if (c >= SHEET_COLS) {
        truncated = true;
        return;
      }
      grid[r][c] = value;
    });
  });
  const html = gridToHtml(grid, evaluateGrid(grid));
  return {
    title: baseName(fileName),
    kind: "sheet",
    content: html,
    plainText: rows
      .map((cells) => cells.join("\t"))
      .join("\n")
      .slice(0, 20000),
    source: fileName,
    note: truncated ? "imp.truncated" : undefined,
  };
}

// --- .pptx ----------------------------------------------------------------

function pptxSlides(zip: ZipArchive): Slide[] {
  const presentationXml = zip.text("ppt/presentation.xml");
  const rels = readRels(zip, "ppt/_rels/presentation.xml.rels", "ppt/");
  const order: string[] = [];
  if (presentationXml) {
    const doc = parseXml(presentationXml);
    for (const sldId of findAll(doc, "sldId")) {
      const path = rels.get(attr(sldId, "id") ?? "");
      if (path) order.push(path);
    }
  }
  if (order.length === 0) {
    const found = zip.names
      .filter((n) => /^ppt\/slides\/slide\d+\.xml$/.test(n))
      .sort((a, b) => Number(a.replace(/\D/g, "")) - Number(b.replace(/\D/g, "")));
    order.push(...found);
  }

  const slides: Slide[] = [];
  for (const path of order) {
    const xml = zip.text(path);
    if (!xml) continue;
    const doc = parseXml(xml);
    // リレーションの Target はスライドのフォルダ（ppt/slides/）からの相対パス
    const slideRels = readRels(zip, path.replace(/slides\/([^/]+)$/, "slides/_rels/$1.rels"), "ppt/slides/");
    let title = "";
    const bodyParts: string[] = [];
    let image: string | undefined;

    for (const shape of findAll(doc, "sp")) {
      const ph = findAll(shape, "ph")[0];
      const type = attr(ph, "type") ?? (ph ? "body" : "");
      const paragraphs = findAll(shape, "p").map((p) => {
        let text = "";
        for (const t of findAll(p, "t")) text += t.textContent ?? "";
        for (const br of findAll(p, "br")) text += br ? "\n" : "";
        return text.trim();
      });
      const text = paragraphs.filter(Boolean).join("\n");
      if (!image) {
        for (const pic of findAll(shape, "pic")) {
          for (const blip of findAll(pic, "blip")) {
            const uri = mediaDataUri(zip, slideRels.get(attr(blip, "embed") ?? ""));
            if (uri) {
              image = uri;
              break;
            }
          }
          if (image) break;
        }
      }
      if (!text) continue;
      if (type === "title" || type === "ctrTitle") {
        if (!title) title = text;
      } else bodyParts.push(text);
    }

    // 図形に入っていない画像（グループ化された図など）も拾う
    if (!image) {
      for (const blip of findAll(doc, "blip")) {
        const uri = mediaDataUri(zip, slideRels.get(attr(blip, "embed") ?? ""));
        if (uri) {
          image = uri;
          break;
        }
      }
    }

    slides.push({ title: title || `スライド ${slides.length + 1}`, body: bodyParts.join("\n"), image });
  }
  if (slides.length === 0) throw new ImportError("imp.empty");
  return slides;
}

// --- .poccham -------------------------------------------------------------

interface PocchamDoc {
  title?: string;
  kind?: string;
  content?: string;
  plainText?: string;
}

function isKind(value: string | undefined): value is DocumentKind {
  return value === "doc" || value === "sheet" || value === "slide";
}

function pocchamDocs(text: string): ImportedDoc[] {
  let parsed: unknown;
  try {
    parsed = JSON.parse(text);
  } catch {
    throw new ImportError("imp.broken");
  }
  const data = parsed as { format?: string; documents?: PocchamDoc[] } | null;
  if (!data || !Array.isArray(data.documents)) throw new ImportError("imp.broken");
  const docs = data.documents
    .filter((d) => d && typeof d.content === "string")
    .map((d, i) => {
      const kind = isKind(d.kind) ? d.kind : "doc";
      const title = (d.title ?? "").trim() || `poccham ${i + 1}`;
      const content = d.content ?? "";
      return {
        title,
        kind,
        content,
        plainText: (d.plainText ?? "").trim() || plainOf(content),
        source: "poccham",
      } satisfies ImportedDoc;
    });
  if (docs.length === 0) throw new ImportError("imp.empty");
  return docs;
}

// --- 入口 -----------------------------------------------------------------

/**
 * ファイル名とバイト列から、アプリのドキュメント（複数可）を作る。
 * @throws ImportError（`imp.*` の i18n キー付き）
 */
export function importFile(fileName: string, bytes: Uint8Array): ImportedDoc[] {
  const name = fileName.toLowerCase();
  const isZip = bytes.length > 4 && bytes[0] === 0x50 && bytes[1] === 0x4b;

  if (name.endsWith(".csv") || name.endsWith(".tsv")) {
    const text = new TextDecoder("utf-8").decode(bytes);
    return [csvToDoc(fileName, text)];
  }

  if (name.endsWith(".poccham") || (!isZip && bytes.length && bytes[0] === 0x7b)) {
    const text = new TextDecoder("utf-8").decode(bytes);
    return pocchamDocs(text);
  }

  if (!isZip) throw new ImportError("imp.unsupported");

  let zip: ZipArchive;
  try {
    zip = readZip(bytes);
  } catch {
    throw new ImportError("imp.broken");
  }

  try {
    if (name.endsWith(".docx") || zip.has("word/document.xml")) {
      const { html, title } = docxHtml(zip);
      return [
        {
          title: title || baseName(fileName),
          kind: "doc",
          content: html,
          plainText: htmlToPlainText(html).slice(0, 20000),
          source: fileName,
        },
      ];
    }
    if (name.endsWith(".xlsx") || name.endsWith(".xlsm") || zip.has("xl/workbook.xml")) {
      const sheets = xlsxSheets(zip);
      const base = baseName(fileName);
      return sheets.map((sheet) => {
        const title = sheets.length === 1 ? base : `${base} - ${sheet.name}`;
        return {
          title,
          kind: "sheet" as DocumentKind,
          content: gridToHtml(sheet.grid, evaluateGrid(sheet.grid)),
          plainText: sheet.grid
            .map((row) => row.join("\t").replace(/\t+$/, ""))
            .filter((line) => line.trim() !== "")
            .join("\n")
            .slice(0, 20000),
          source: fileName,
          note: sheet.truncated ? "imp.truncated" : undefined,
        };
      });
    }
    if (name.endsWith(".pptx") || zip.has("ppt/presentation.xml")) {
      const slides = pptxSlides(zip);
      return [
        {
          title: baseName(fileName),
          kind: "slide",
          content: slidesToHtml(slides),
          plainText: slidesToText(slides).slice(0, 20000),
          source: fileName,
        },
      ];
    }
  } catch (e) {
    if (e instanceof ImportError) throw e;
    throw new ImportError("imp.broken");
  }

  throw new ImportError("imp.unsupported");
}
