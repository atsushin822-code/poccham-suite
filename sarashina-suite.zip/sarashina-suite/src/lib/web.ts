// 静的 Web 版（Tauri なし）用のバックエンド。
//
// ・文書 / 会話履歴 / 設定はブラウザ内（IndexedDB）に保存する＝サーバー不要・オフライン動作
// ・AI 推論は提供しない（GGUF のローカル実行はデスクトップ版のみ）。
//   代わりに「Web 版では使えない」ことを UI に明示する。
//
// 契約は crates/sarashina-core の DTO と api.ts の fallback シグネチャに合わせてある。

import type {
  AppInfo, ChatMessageRow, ChatTurn, DbStats, Doc, DocumentKind, DocumentSummary,
  EngineStatus, GenOptions, GenStats, ModelView, SearchHit,
} from "./types";

export type Emit = (event: string, payload: unknown) => void;

// 種別ごとの既定タイトル
export const DEFAULT_TITLE: Record<DocumentKind, string> = {
  doc: "無題のドキュメント",
  sheet: "無題の表計算",
  slide: "無題のスライド",
};


const now = () => Date.now();
const MEM_FALLBACK = "web (メモリのみ)";
const MEM_NOTE = "ブラウザの保存領域が使えないため、このタブを閉じると内容は失われます";

/** IndexedDB が使えない環境（file:// 直開き等）ではメモリに退避する */
interface Storage {
  readonly persistent: boolean;
  allDocs(): Promise<Doc[]>;
  getDoc(id: string): Promise<Doc | null>;
  putDoc(doc: Doc): Promise<void>;
  delDoc(id: string): Promise<void>;
  messages(sessionId: string): Promise<ChatMessageRow[]>;
  putMessage(row: ChatMessageRow): Promise<void>;
  getSetting(key: string): Promise<string | null>;
  setSetting(key: string, value: string): Promise<void>;
}

function promisify<T>(req: IDBRequest<T>): Promise<T> {
  return new Promise((resolve, reject) => {
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

class IdbStorage implements Storage {
  readonly persistent = true;
  private dbp: Promise<IDBDatabase> | null = null;

  private open(): Promise<IDBDatabase> {
    if (this.dbp) return this.dbp;
    this.dbp = new Promise<IDBDatabase>((resolve, reject) => {
      const req = indexedDB.open("sarashina-suite", 1);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains("documents")) {
          db.createObjectStore("documents", { keyPath: "id" });
        }
        if (!db.objectStoreNames.contains("messages")) {
          const store = db.createObjectStore("messages", { keyPath: "id" });
          store.createIndex("sessionId", "sessionId");
        }
        if (!db.objectStoreNames.contains("settings")) {
          db.createObjectStore("settings", { keyPath: "key" });
        }
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
    return this.dbp;
  }

  private async store(name: string, mode: IDBTransactionMode): Promise<IDBObjectStore> {
    const db = await this.open();
    return db.transaction(name, mode).objectStore(name);
  }

  async allDocs(): Promise<Doc[]> {
    return promisify((await this.store("documents", "readonly")).getAll() as IDBRequest<Doc[]>);
  }
  async getDoc(id: string): Promise<Doc | null> {
    const row = await promisify((await this.store("documents", "readonly")).get(id) as IDBRequest<Doc | undefined>);
    return row ?? null;
  }
  async putDoc(doc: Doc): Promise<void> {
    await promisify((await this.store("documents", "readwrite")).put(doc));
  }
  async delDoc(id: string): Promise<void> {
    await promisify((await this.store("documents", "readwrite")).delete(id));
  }
  async messages(sessionId: string): Promise<ChatMessageRow[]> {
    const idx = (await this.store("messages", "readonly")).index("sessionId");
    const rows = await promisify(idx.getAll(sessionId) as IDBRequest<ChatMessageRow[]>);
    return rows.sort((a, b) => a.createdAt - b.createdAt);
  }
  async putMessage(row: ChatMessageRow): Promise<void> {
    await promisify((await this.store("messages", "readwrite")).put(row));
  }
  async getSetting(key: string): Promise<string | null> {
    const row = await promisify((await this.store("settings", "readonly")).get(key) as IDBRequest<{ key: string; value: string } | undefined>);
    return row?.value ?? null;
  }
  async setSetting(key: string, value: string): Promise<void> {
    await promisify((await this.store("settings", "readwrite")).put({ key, value }));
  }
}

class MemoryStorage implements Storage {
  readonly persistent = false;
  private docs = new Map<string, Doc>();
  private msgs: ChatMessageRow[] = [];
  private settings = new Map<string, string>();

  async allDocs() { return [...this.docs.values()]; }
  async getDoc(id: string) { return this.docs.get(id) ?? null; }
  async putDoc(doc: Doc) { this.docs.set(doc.id, doc); }
  async delDoc(id: string) { this.docs.delete(id); }
  async messages(sessionId: string) { return this.msgs.filter((m) => m.sessionId === sessionId); }
  async putMessage(row: ChatMessageRow) { this.msgs.push(row); }
  async getSetting(key: string) { return this.settings.get(key) ?? null; }
  async setSetting(key: string, value: string) { this.settings.set(key, value); }
}

// --- 書き出しユーティリティ（crates/sarashina-core/src/export.rs の簡易版） ------
const escapeHtml = (s: string) =>
  s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

const decodeEntities = (s: string) =>
  s.replace(/&nbsp;/g, " ").replace(/&amp;/g, "&").replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&apos;/g, "'");

function htmlToText(html: string): string {
  return decodeEntities(
    html
      .replace(/<\s*br\s*\/?>/gi, "\n")
      .replace(/<\/t[dh]>/gi, "\t") // 表計算: セルはタブ区切り
      .replace(/<\/(p|div|h[1-6]|li|tr|blockquote)>/gi, "\n")
      .replace(/<[^>]+>/g, ""),
  )
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

function htmlToMarkdown(html: string): string {
  let md = html;
  md = md.replace(/<\s*h1[^>]*>(.*?)<\/\s*h1\s*>/gis, "\n# $1\n");
  md = md.replace(/<\s*h2[^>]*>(.*?)<\/\s*h2\s*>/gis, "\n## $1\n");
  md = md.replace(/<\s*h3[^>]*>(.*?)<\/\s*h3\s*>/gis, "\n### $1\n");
  md = md.replace(/<\s*(strong|b)[^>]*>(.*?)<\/\s*\1\s*>/gis, "**$2**");
  md = md.replace(/<\s*(em|i)[^>]*>(.*?)<\/\s*\1\s*>/gis, "*$2*");
  md = md.replace(/<\s*code[^>]*>(.*?)<\/\s*code\s*>/gis, "`$1`");
  md = md.replace(/<\s*li[^>]*>(.*?)<\/\s*li\s*>/gis, "- $1\n");
  md = md.replace(/<\s*blockquote[^>]*>(.*?)<\/\s*blockquote\s*>/gis, "> $1\n");
  md = md.replace(/<\s*br\s*\/?>/gi, "\n");
  // 表計算: 行頭に | を置き、セル境界を ` |` にする（最低限読める Markdown 表）
  md = md.replace(/<\s*tr[^>]*>/gi, "\n|");
  md = md.replace(/<\/t[dh]>/gi, " |");
  md = md.replace(/<\/(p|div)>/gi, "\n\n");
  md = md.replace(/<[^>]+>/g, "");
  return decodeEntities(md).replace(/\n{3,}/g, "\n\n").trim();
}

function safeName(title: string): string {
  const cleaned = title.replace(/[/\\:*?"<>|]/g, "_").trim() || "document";
  return cleaned.slice(0, 80);
}

function downloadBlob(filename: string, blob: Blob) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.rel = "noopener";
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 0);
}

function download(filename: string, body: string, mime: string) {
  const blob = new Blob([body], { type: `${mime};charset=utf-8` });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.rel = "noopener";
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 0);
}

const NO_AI_MESSAGE =
  "Web 版ではローカル AI 推論を実行できません。AI 機能はデスクトップ版（Windows / macOS / Linux）で、ローカルに保存した GGUF を使って動作します。";

export class WebBackend {
  private storage: Storage;
  private seeded = false;
  private sessions = new Map<string, string>();

  constructor(_emit: Emit) {
    this.storage = typeof indexedDB !== "undefined" ? new IdbStorage() : new MemoryStorage();
  }

  /** 初回起動時にサンプル文書を 2 件入れておく（空の画面を避ける） */
  private async ensureSeed(): Promise<void> {
    if (this.seeded || !this.storage.persistent) return;
    const docs = await this.storage.allDocs();
    if (docs.length > 0) {
      this.seeded = true;
      return;
    }
    const seed: Array<[string, string]> = [
      ["四半期レビュー議事録", "<h1>四半期レビュー</h1><p>売上は前年比 120% で着地した。来期は保守運用の自動化に投資する。</p>"],
      ["新製品の企画メモ", "<h2>コンセプト</h2><p>ブラウザだけで完結する文書作成環境。通信できない現場でも使えることを最優先にする。</p>"],
    ];
    for (const [i, [title, content]] of seed.entries()) {
      const doc: Doc = {
        id: `seed-${i + 1}`,
        title,
        kind: "doc",
        content,
        plainText: htmlToText(content),
        pinned: i === 0,
        createdAt: now() - (i + 1) * 86_400_000,
        updatedAt: now() - i * 3_600_000,
      };
      await this.storage.putDoc(doc);
    }
    this.seeded = true;
  }

  // --- app -----------------------------------------------------------------
  async appInfo(): Promise<AppInfo> {
    const persistent = this.storage.persistent;
    return {
      version: "0.2.0",
      backend: persistent ? "web (IndexedDB)" : MEM_FALLBACK,
      platform: "web",
      dataDir: persistent ? "ブラウザ内 (IndexedDB: sarashina-suite)" : MEM_NOTE,
      dbPath: persistent ? "documents / messages / settings" : "(未使用)",
      modelsDir: "(Web 版では未対応)",
      cacheDir: "(未使用)",
      activeModelId: null,
      recommendedModelId: "sarashina-1b-q4_k_m",
    };
  }

  async dbStats(): Promise<DbStats> {
    await this.ensureSeed();
    const docs = await this.storage.allDocs();
    let chatMessages = 0;
    for (const d of docs) chatMessages += (await this.storage.messages(`web-session-${d.id}`)).length;
    return {
      documents: docs.length,
      characters: docs.reduce((n, d) => n + d.plainText.length, 0),
      chatMessages,
      models: 0,
      schemaVersion: 1,
    };
  }

  async settingGet(key: string): Promise<string | null> {
    return this.storage.getSetting(key);
  }
  async settingSet(key: string, value: string): Promise<void> {
    await this.storage.setSetting(key, value);
  }

  // --- documents -----------------------------------------------------------
  async listDocuments(limit = 500): Promise<DocumentSummary[]> {
    await this.ensureSeed();
    const docs = await this.storage.allDocs();
    return docs
      .sort((a, b) => Number(b.pinned) - Number(a.pinned) || b.updatedAt - a.updatedAt)
      .slice(0, limit)
      .map((d) => ({
        id: d.id,
        title: d.title,
        kind: d.kind,
        preview: d.plainText.slice(0, 140),
        pinned: d.pinned,
        createdAt: d.createdAt,
        updatedAt: d.updatedAt,
      }));
  }

  async getDocument(id: string): Promise<Doc | null> {
    return this.storage.getDoc(id);
  }

  async createDocument(title?: string, kind: DocumentKind = "doc"): Promise<Doc> {
    const doc: Doc = {
      id: crypto.randomUUID(),
      title: title?.trim() || DEFAULT_TITLE[kind],
      kind,
      content: "",
      plainText: "",
      pinned: false,
      createdAt: now(),
      updatedAt: now(),
    };
    await this.storage.putDoc(doc);
    return doc;
  }

  async saveDocument(id: string, title: string, content: string, plainText: string): Promise<number> {
    const doc = await this.storage.getDoc(id);
    if (!doc) return now();
    doc.title = title.trim() || "無題のドキュメント";
    doc.content = content;
    doc.plainText = plainText;
    doc.updatedAt = now();
    await this.storage.putDoc(doc);
    return doc.updatedAt;
  }

  async deleteDocument(id: string): Promise<void> {
    await this.storage.delDoc(id);
  }

  async pinDocument(id: string, pinned: boolean): Promise<void> {
    const doc = await this.storage.getDoc(id);
    if (!doc) return;
    doc.pinned = pinned;
    doc.updatedAt = now();
    await this.storage.putDoc(doc);
  }

  // FTS5 の代わりに部分一致検索（Web 版の制約）
  async searchDocuments(query: string): Promise<SearchHit[]> {
    await this.ensureSeed();
    const q = query.trim();
    if (!q) return [];
    const lower = q.toLowerCase();
    const docs = await this.storage.allDocs();
    return docs
      .filter((d) => d.title.toLowerCase().includes(lower) || d.plainText.toLowerCase().includes(lower))
      .sort((a, b) => b.updatedAt - a.updatedAt)
      .map((d) => {
        const at = d.plainText.toLowerCase().indexOf(lower);
        const from = Math.max(0, at - 40);
        const snippet = at >= 0
          ? `${from > 0 ? "…" : ""}${d.plainText.slice(from, from + 120)}`
          : d.plainText.slice(0, 120);
        return { id: d.id, title: d.title, snippet, updatedAt: d.updatedAt };
      });
  }

  /** 生成済みのバイト列をそのままダウンロードする（Tauri 版の save_export_file 相当） */
  async saveExportFile(name: string, base64: string): Promise<string> {
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i);
    const type = name.endsWith(".poccham") ? "application/json" : "application/octet-stream";
    downloadBlob(name, new Blob([bytes], { type: `${type};charset=utf-8` }));
    return name;
  }

  exportsDir(): string {
    return "ダウンロード";
  }

  async exportDocument(id: string, format: string): Promise<{ path: string; format: string }> {
    const doc = await this.storage.getDoc(id);
    const title = doc?.title ?? "document";
    const content = doc?.content ?? "";
    const plain = doc?.plainText ?? htmlToText(content);
    const fmt = format.toLowerCase();

    let body: string;
    let ext: string;
    let mime = "text/plain";
    if (fmt === "md" || fmt === "markdown") {
      body = htmlToMarkdown(content) || plain;
      ext = "md";
      mime = "text/markdown";
    } else if (fmt === "html" || fmt === "htm") {
      body =
        `<!doctype html>\n<html lang="ja">\n<head>\n<meta charset="utf-8">\n<title>${escapeHtml(title)}</title>\n` +
        `<style>body{font-family:system-ui,-apple-system,'Hiragino Sans',sans-serif;max-width:52rem;` +
        `margin:3rem auto;padding:0 1.25rem;line-height:1.85;color:#1d1d1f}</style>\n</head>\n<body>\n` +
        `<h1>${escapeHtml(title)}</h1>\n${content}\n</body>\n</html>\n`;
      ext = "html";
      mime = "text/html";
    } else {
      body = plain.trim() ? `${title}\n\n${plain}` : htmlToText(content);
      ext = "txt";
    }

    const filename = `${safeName(title)}.${ext}`;
    download(filename, body, mime);
    return { path: filename, format: ext };
  }

  // --- models（Web 版では未対応）------------------------------------------
  async listModels(): Promise<ModelView[]> {
    return [];
  }
  async downloadModel(_modelId: string): Promise<void> {
    throw new Error(NO_AI_MESSAGE);
  }
  async cancelDownload(_modelId: string): Promise<void> {
    /* no-op */
  }
  async deleteModel(_modelId: string): Promise<void> {
    /* no-op */
  }
  async activateModel(_modelId: string): Promise<void> {
    throw new Error(NO_AI_MESSAGE);
  }

  async engineStatus(): Promise<EngineStatus> {
    return {
      state: "error",
      backend: "web",
      modelId: null,
      modelPath: null,
      nCtx: 0,
      message: NO_AI_MESSAGE,
    };
  }

  async engineConfigure(nCtx: number): Promise<EngineStatus> {
    return { ...(await this.engineStatus()), nCtx };
  }

  // --- chat（履歴の保存のみ。生成は不可）----------------------------------
  async ensureSession(documentId: string | null): Promise<string> {
    const key = documentId ?? "global";
    if (!this.sessions.has(key)) this.sessions.set(key, `web-session-${key}`);
    return this.sessions.get(key)!;
  }

  async listMessages(sessionId: string, limit = 100): Promise<ChatMessageRow[]> {
    const rows = await this.storage.messages(sessionId);
    return rows.slice(-limit);
  }

  async appendMessage(
    sessionId: string,
    role: ChatMessageRow["role"],
    content: string,
  ): Promise<ChatMessageRow> {
    const row: ChatMessageRow = { id: crypto.randomUUID(), sessionId, role, content, createdAt: now() };
    await this.storage.putMessage(row);
    return row;
  }

  async chatGenerate(
    _requestId: string,
    _messages: ChatTurn[],
    _options?: Partial<GenOptions>,
  ): Promise<GenStats> {
    throw new Error(NO_AI_MESSAGE);
  }

  async chatCancel(_requestId: string): Promise<void> {
    /* no-op */
  }
}
