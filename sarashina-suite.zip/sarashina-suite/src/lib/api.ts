// Tauri コマンド呼び出しの唯一の窓口。
// コンポーネントから直接 `invoke()` を呼ばないことで、
// ① 型の一元管理 ② ブラウザ実行時のデモ fallback ③ 将来のテスト容易性 を確保する。

import { invoke } from "@tauri-apps/api/core";
import { listen, type UnlistenFn } from "@tauri-apps/api/event";
import { DemoBackend } from "./demo";
import { WebBackend } from "./web";
import type {
  AppInfo, ChatMessageRow, ChatTurn, DbStats, Doc, DocumentKind, DocumentSummary, DownloadEvent,
  EngineStatus, GenOptions, GenStats, ModelView, SearchHit,
} from "./types";

export const isTauri = typeof window !== "undefined" && "__TAURI_INTERNALS__" in window;
/** 静的 Web 版（ブラウザ実行）かどうか。Tauri 実行時は false。 */
export const isWeb = !isTauri;
/** `?demo=1` を付けるとインメモリのモック（UI 確認用）に切り替わる */
const useMock = isWeb && typeof location !== "undefined" && new URLSearchParams(location.search).has("demo");

// --- イベントバス（ブラウザ実行時のみ使用） ---------------------------------
type Listener = (payload: unknown) => void;
const demoListeners = new Map<string, Set<Listener>>();

function demoEmit(event: string, payload: unknown) {
  demoListeners.get(event)?.forEach((fn) => fn(payload));
}

// ブラウザ実行時のバックエンド:
//   既定 = WebBackend（IndexedDB に保存する静的 Web 版の実装）
//   ?demo=1 = DemoBackend（インメモリのモック。UI 確認用に AI 応答もダミーで返す）
// どちらも「同期 or Promise」を返しうるが、call() 側で Promise に正規化する。
const mock = new DemoBackend(demoEmit);
const web = new WebBackend(demoEmit);
const demo = (useMock ? mock : web) as unknown as WebBackend;

export async function subscribe<T>(event: string, handler: (payload: T) => void): Promise<UnlistenFn> {
  if (isTauri) {
    return listen<T>(event, (e) => handler(e.payload));
  }
  const set = demoListeners.get(event) ?? new Set<Listener>();
  const fn: Listener = (payload) => handler(payload as T);
  set.add(fn);
  demoListeners.set(event, set);
  return () => {
    set.delete(fn);
  };
}

const call = <T,>(cmd: string, args?: Record<string, unknown>, fallback?: () => T | Promise<T>): Promise<T> => {
  if (isTauri) return invoke<T>(cmd, args);
  if (!fallback) return Promise.reject(new Error(`ブラウザ実行では ${cmd} をサポートしていません`));
  // fallback は同期・非同期のどちらも返せる（例外は reject として伝播させる）
  return Promise.resolve().then(fallback);
};

export const api = {
  // --- app -----------------------------------------------------------------
  appInfo: () => call<AppInfo>("app_info", undefined, () => demo.appInfo()),
  dbStats: () => call<DbStats>("db_stats", undefined, () => demo.dbStats()),
  settingGet: (key: string) => call<string | null>("setting_get", { key }, () => demo.settingGet(key)),
  settingSet: (key: string, value: string) =>
    call<void>("setting_set", { key, value }, () => demo.settingSet(key, value)),

  // --- documents -----------------------------------------------------------
  listDocuments: (limit = 500) =>
    call<DocumentSummary[]>("list_documents", { limit }, () => demo.listDocuments(limit)),
  getDocument: (id: string) => call<Doc | null>("get_document", { id }, () => demo.getDocument(id)),
  createDocument: (title?: string, kind: DocumentKind = "doc") =>
    call<Doc>("create_document", { title, kind }, () => demo.createDocument(title, kind)),
  saveDocument: (id: string, title: string, content: string, plainText: string) =>
    call<number>("save_document", { id, title, content, plainText }, () =>
      demo.saveDocument(id, title, content, plainText),
    ),
  deleteDocument: (id: string, purge = false) =>
    call<void>("delete_document", { id, purge }, () => demo.deleteDocument(id)),
  pinDocument: (id: string, pinned: boolean) =>
    call<void>("pin_document", { id, pinned }, () => demo.pinDocument(id, pinned)),
  searchDocuments: (query: string) =>
    call<SearchHit[]>("search_documents", { query }, () => demo.searchDocuments(query)),
  exportDocument: (id: string, format: string, dest?: string) =>
    call<{ path: string; format: string }>("export_document", { id, format, dest }, () =>
      demo.exportDocument(id, format),
    ),
  /** 任意のバイト列（docx / xlsx / pptx / poccham など）を保存する */
  saveExportFile: (name: string, base64: string) =>
    call<string>("save_export_file", { name, base64 }, () => demo.saveExportFile(name, base64)),
  exportsDir: () => call<string>("exports_dir", undefined, () => demo.exportsDir()),

  // --- models --------------------------------------------------------------
  listModels: () => call<ModelView[]>("list_models", undefined, () => demo.listModels()),
  downloadModel: (modelId: string) =>
    call<void>("download_model", { modelId }, () => demo.downloadModel(modelId)),
  cancelDownload: (modelId: string) =>
    call<void>("cancel_download", { modelId }, () => demo.cancelDownload(modelId)),
  deleteModel: (modelId: string) => call<void>("delete_model", { modelId }, () => demo.deleteModel(modelId)),
  activateModel: (modelId: string) =>
    call<void>("activate_model", { modelId }, () => demo.activateModel(modelId)),
  engineStatus: () => call<EngineStatus>("engine_status", undefined, () => demo.engineStatus()),
  engineConfigure: (nCtx: number, nThreads: number, nGpuLayers: number) =>
    call<EngineStatus>("engine_configure", { nCtx, nThreads, nGpuLayers }, () =>
      demo.engineConfigure(nCtx),
    ),

  // --- chat ----------------------------------------------------------------
  ensureSession: (documentId: string | null) =>
    call<string>("ensure_session", { documentId }, () => demo.ensureSession(documentId)),
  listMessages: (sessionId: string, limit = 100) =>
    call<ChatMessageRow[]>("list_messages", { sessionId, limit }, () => demo.listMessages(sessionId, limit)),
  appendMessage: (sessionId: string, role: ChatMessageRow["role"], content: string) =>
    call<ChatMessageRow>("append_message", { sessionId, role, content }, () =>
      demo.appendMessage(sessionId, role, content),
    ),
  chatGenerate: (requestId: string, messages: ChatTurn[], options?: GenOptions) =>
    call<GenStats>("chat_generate", { requestId, messages, options }, () =>
      mock.chatGenerate(requestId, messages, options),
    ),
  chatCancel: (requestId: string) =>
    call<void>("chat_cancel", { requestId }, () => demo.chatCancel(requestId)),
};

export type { DownloadEvent };
