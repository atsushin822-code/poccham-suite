// テンプレート（製品版の「すぐ使える文書」）。
// 生成物はふつうの文書 / 表計算 / スライドなので、そのまま編集・書き出しできる。

import { evaluateGrid, modelToHtml, type Grid } from "./sheet";
import { slidesToHtml, type Slide } from "./slides";
import { htmlToPlainText } from "./format";

export interface TemplateDef {
  id: string;
  kind: "doc" | "sheet" | "slide";
  title: string;
  /** i18n キー */
  nameKey: string;
  descKey: string;
  build: () => string;
}

const P = (html: string) => `<p>${html}</p>`;

function sheetHtml(rows: string[][]): string {
  const cols = Math.max(...rows.map((r) => r.length));
  const grid: Grid = rows.map((r) => Array.from({ length: cols }, (_, i) => r[i] ?? ""));
  const model = {
    grid,
    styles: grid.map((row) => row.map(() => null)),
    widths: Array.from({ length: cols }, (_, i) => (i === 0 ? 180 : 110)),
    freeze: true,
  };
  return modelToHtml(model, evaluateGrid(grid));
}

const today = () => {
  const d = new Date();
  return `${d.getFullYear()}年${d.getMonth() + 1}月${d.getDate()}日`;
};

export const TEMPLATES: TemplateDef[] = [
  {
    id: "report",
    kind: "doc",
    title: "週次報告書",
    nameKey: "tpl.report",
    descKey: "tpl.reportDesc",
    build: () =>
      `<p class="ps-title">週次報告書</p>` +
      `<p class="ps-subtitle">${today()} ／ 作成者：（氏名）</p>` +
      `<h2>1. 今週の概要</h2>${P("（今週の成果を 2〜3 行でまとめます）")}` +
      `<h2>2. 進捗</h2>` +
      `<table class="tbl"><tbody><tr><th>項目</th><th>計画</th><th>実績</th><th>状態</th></tr>` +
      `<tr><td>タスク A</td><td>100%</td><td>80%</td><td>順調</td></tr>` +
      `<tr><td>タスク B</td><td>60%</td><td>40%</td><td>遅延</td></tr>` +
      `</tbody></table>` +
      `<h2>3. 課題と対応</h2>${P("・課題：（内容）<br>・対応：（内容と担当）")}` +
      `<h2>4. 来週の予定</h2>${P("・（予定 1）<br>・（予定 2）")}`,
  },
  {
    id: "invoice",
    kind: "doc",
    title: "請求書",
    nameKey: "tpl.invoice",
    descKey: "tpl.invoiceDesc",
    build: () =>
      `<p class="ps-title">請求書</p>` +
      `<p class="ps-subtitle">請求書番号 INV-0001 ／ 発行日 ${today()}</p>` +
      `<h3>宛先</h3>${P("株式会社 ◯◯ 御中<br>〒000-0000 東京都…<br>ご担当：（氏名）様")}` +
      `<h3>ご請求内容</h3>` +
      `<table class="tbl"><tbody>` +
      `<tr><th>品目</th><th>数量</th><th>単価</th><th>金額</th></tr>` +
      `<tr><td>コンサルティング（時間単価）</td><td>10</td><td>12,000</td><td>120,000</td></tr>` +
      `<tr><td>設計・実装費</td><td>1</td><td>300,000</td><td>300,000</td></tr>` +
      `<tr><td>小計</td><td></td><td></td><td>420,000</td></tr>` +
      `<tr><td>消費税（10%）</td><td></td><td></td><td>42,000</td></tr>` +
      `<tr><th>合計</th><td></td><td></td><th>462,000</th></tr>` +
      `</tbody></table>` +
      `<h3>お振込先</h3>${P("◯◯銀行 ◯◯支店 普通 0000000（口座名義：◯◯）<br>お支払い期限：翌月末日")}`,
  },
  {
    id: "minutes",
    kind: "doc",
    title: "議事録",
    nameKey: "tpl.minutes",
    descKey: "tpl.minutesDesc",
    build: () =>
      `<p class="ps-title">議事録</p>` +
      `<p class="ps-subtitle">${today()} 10:00–11:00 ／ 会議室 A ／ 記録：（氏名）</p>` +
      `<h2>出席者</h2>${P("（氏名）、（氏名）、（氏名）")}` +
      `<h2>議題</h2>${P("1. （議題 1）<br>2. （議題 2）")}` +
      `<h2>決定事項</h2>${P("・（決定 1）<br>・（決定 2）")}` +
      `<h2>アクションアイテム</h2>` +
      `<table class="tbl"><tbody><tr><th>内容</th><th>担当</th><th>期限</th></tr>` +
      `<tr><td>（作業内容）</td><td>（氏名）</td><td>（日付）</td></tr>` +
      `</tbody></table>` +
      `<h2>次回</h2>${P("（日時・場所）")}`,
  },
  {
    id: "budget",
    kind: "sheet",
    title: "予算管理表",
    nameKey: "tpl.budget",
    descKey: "tpl.budgetDesc",
    build: () =>
      sheetHtml([
        ["費目", "予算", "実績", "差異", "達成率"],
        ["人件費", "1200000", "1150000", "=B2-C2", "=IF(B2=0,0,C2/B2)"],
        ["外注費", "400000", "460000", "=B3-C3", "=IF(B3=0,0,C3/B3)"],
        ["広告費", "250000", "180000", "=B4-C4", "=IF(B4=0,0,C4/B4)"],
        ["交通費", "80000", "92000", "=B5-C5", "=IF(B5=0,0,C5/B5)"],
        ["合計", "=SUM(B2:B5)", "=SUM(C2:C5)", "=SUM(D2:D5)", "=IF(B6=0,0,C6/B6)"],
        ["", "", "", "", ""],
        ["メモ", "差異 = 予算 − 実績（プラスなら余剰）", "", "", ""],
      ]),
  },
  {
    id: "proposal",
    kind: "slide",
    title: "提案資料",
    nameKey: "tpl.proposal",
    descKey: "tpl.proposalDesc",
    build: () => {
      const slides: Slide[] = [
        {
          title: "（提案タイトル）",
          body: "サブタイトル：〜で、〜を実現する\n提案者：（氏名）／（会社名）",
          layout: "title",
          transition: "fade",
        },
        {
          title: "現状の課題",
          body: "・（課題 1：数字を添えて）\n・（課題 2）\n・（課題 3）",
          layout: "content",
          notes: "課題の裏付けデータを口頭で補足する。",
        },
        {
          title: "ご提案",
          body: "・（提案の要点）\n・（提供する価値）\n・（進め方）",
          layout: "content",
        },
        {
          title: "導入効果",
          body: "・コスト削減：◯% 削減（年間 ◯◯ 万円）\n・作業時間：週 ◯ 時間の短縮\n・品質：◯◯ の向上",
          layout: "content",
        },
        {
          title: "次の一歩",
          body: "・（次に決めていただきたいこと）\n・スケジュール：（日付）開始\n・ご連絡先：（メール / 電話）",
          layout: "section",
        },
      ];
      return slidesToHtml(slides);
    },
  },
];

export function buildTemplate(id: string): { title: string; kind: "doc" | "sheet" | "slide"; content: string; plain: string } | null {
  const tpl = TEMPLATES.find((t) => t.id === id);
  if (!tpl) return null;
  const content = tpl.build();
  return { title: tpl.title, kind: tpl.kind, content, plain: htmlToPlainText(content) };
}
