// ネイティブ形式への書き出し（.docx / .xlsx / .pptx / .poccham）。
//
// 外部ライブラリは使わない。OOXML は ZIP + XML なので zip.ts で組み立てる。
// Markdown / テキスト / HTML も同じモジュールで作る = Web 版とデスクトップ版で
// 書き出し結果が完全に一致する。

import { makeZip, type ZipEntry } from "./zip";
import { formatValue, type Grid, type ValueGrid } from "./sheet";
import { imageSize, parseDataUri } from "./media";
import { slidesToText, type Slide } from "./slides";
import type { Doc } from "./types";

const xml = (s: string) =>
  s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");

/** XML 1.0 で不正な制御文字を落とす（Office が壊れたファイルと判定するのを防ぐ） */
const stripControl = (s: string) => s.replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, "");

const decodeEntities = (s: string) =>
  s
    .replace(/&nbsp;/g, " ")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&amp;/g, "&");

// --- 共通: HTML → プレーンテキスト / Markdown ------------------------------

export function htmlToPlainText(html: string): string {
  if (!html.trim()) return "";
  const withBreaks = html
    .replace(/<\s*br\s*\/?>/gi, "\n")
    .replace(/<\/t[dh]>/gi, "\t")
    .replace(/<(p|div|h[1-6]|li|tr|blockquote|section)\b[^>]*>/gi, "\n")
    .replace(/<\/(p|div|h[1-6]|li|tr|blockquote|section)>/gi, "\n")
    .replace(/<[^>]+>/g, "");
  return decodeEntities(withBreaks)
    .replace(/\n{3,}/g, "\n\n")
    .replace(/[ \t]+\n/g, "\n")
    .trim();
}

export function htmlToMarkdown(html: string): string {
  if (!html.trim()) return "";
  let md = html;
  md = md.replace(/<\s*h1[^>]*>(.*?)<\/\s*h1\s*>/gis, "\n# $1\n");
  md = md.replace(/<\s*h2[^>]*>(.*?)<\/\s*h2\s*>/gis, "\n## $1\n");
  md = md.replace(/<\s*h3[^>]*>(.*?)<\/\s*h3\s*>/gis, "\n### $1\n");
  md = md.replace(/<\s*h4[^>]*>(.*?)<\/\s*h4\s*>/gis, "\n#### $1\n");
  md = md.replace(/<\s*(strong|b)[^>]*>(.*?)<\/\s*\1\s*>/gis, "**$2**");
  md = md.replace(/<\s*(em|i)[^>]*>(.*?)<\/\s*\1\s*>/gis, "*$2*");
  md = md.replace(/<\s*code[^>]*>(.*?)<\/\s*code\s*>/gis, "`$1`");
  md = md.replace(/<\s*li[^>]*>(.*?)<\/\s*li\s*>/gis, "- $1\n");
  md = md.replace(/<\s*blockquote[^>]*>(.*?)<\/\s*blockquote\s*>/gis, "> $1\n");
  md = md.replace(/<\s*br\s*\/?>/gi, "  \n");
  // 表計算: 行頭に |、セル境界を " |"
  md = md.replace(/<\s*tr[^>]*>/gi, "\n|");
  md = md.replace(/<\/t[dh]>/gi, " |");
  md = md.replace(/<(p|div|section)\b[^>]*>/gi, "\n");
  md = md.replace(/<\/(p|div|section)>/gi, "\n\n");
  md = md.replace(/<[^>]+>/g, "");
  return decodeEntities(md)
    .replace(/[ \t]+\n/g, "\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

/** スライド HTML → Markdown（`## 見出し` + 本文） */
export function slidesToMarkdown(slides: Slide[]): string {
  return slides
    .map((s, i) => `## ${i + 1}. ${s.title}\n\n${s.body}`.trim())
    .join("\n\n---\n\n");
}

// --- 共通パーツ ------------------------------------------------------------

function coreProps(title: string): string {
  const now = new Date().toISOString().replace(/\.\d+Z$/, "Z");
  return (
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
    `<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" ` +
    `xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" ` +
    `xmlns:dcmitype="http://purl.org/dc/dcmitype/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">` +
    `<dc:title>${xml(title)}</dc:title><dc:creator>Suite with Poccham AI</dc:creator>` +
    `<cp:lastModifiedBy>Suite with Poccham AI</cp:lastModifiedBy>` +
    `<dcterms:created xsi:type="dcterms:W3CDTF">${now}</dcterms:created>` +
    `<dcterms:modified xsi:type="dcterms:W3CDTF">${now}</dcterms:modified>` +
    `</cp:coreProperties>`
  );
}

function appProps(kind: string): string {
  return (
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
    `<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" ` +
    `xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes">` +
    `<Application>Suite with Poccham AI</Application><AppVersion>1.0</AppVersion>` +
    `<DocSecurity>0</DocSecurity><Category>${xml(kind)}</Category></Properties>`
  );
}

const flatXml = (s: string) => s.replace(/>\s+</g, "><").trim();

/** 埋め込み画像の拡張子から [Content_Types].xml の Default 要素を作る */
const IMAGE_MIME: Record<string, string> = {
  png: "image/png",
  jpeg: "image/jpeg",
  jpg: "image/jpeg",
  gif: "image/gif",
  webp: "image/webp",
  bmp: "image/bmp",
  svg: "image/svg+xml",
};

function mediaContentTypes(exts: string[]): string {
  return [...new Set(exts)]
    .filter((ext) => IMAGE_MIME[ext])
    .map((ext) => `<Default Extension="${ext}" ContentType="${IMAGE_MIME[ext]}"/>`)
    .join("");
}

// --- .docx -----------------------------------------------------------------

interface Run {
  text: string;
  bold?: boolean;
  italic?: boolean;
  mono?: boolean;
  /** 画像（docx の drawing として出力する） */
  image?: { rid: string; cx: number; cy: number };
}

const PICTURE_NS =
  `http://schemas.openxmlformats.org/drawingml/2006/picture`;

/** 画像 1 枚を <w:r><w:drawing> にする */
function docxImageRun(image: { rid: string; cx: number; cy: number }): string {
  return (
    `<w:r><w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0">` +
    `<wp:extent cx="${image.cx}" cy="${image.cy}"/><wp:docPr id="1" name="Picture"/>` +
    `<a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">` +
    `<a:graphicData uri="${PICTURE_NS}">` +
    `<pic:pic xmlns:pic="${PICTURE_NS}">` +
    `<pic:nvPicPr><pic:cNvPr id="1" name="Picture"/><pic:cNvPicPr/></pic:nvPicPr>` +
    `<pic:blipFill><a:blip r:embed="${image.rid}"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>` +
    `<pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="${image.cx}" cy="${image.cy}"/></a:xfrm>` +
    `<a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr>` +
    `</pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>`
  );
}

function inlineRuns(node: Node, style: { bold?: boolean; italic?: boolean; mono?: boolean } = {}): Run[] {
  // テキストノード自体を渡されることもある（contenteditable の地の文）
  if (node.nodeType === Node.TEXT_NODE) {
    const text = stripControl(node.textContent ?? "");
    return text ? [{ text, ...style }] : [];
  }
  const runs: Run[] = [];
  node.childNodes.forEach((child) => {
    if (child.nodeType === Node.TEXT_NODE) {
      const text = stripControl(child.textContent ?? "");
      if (text) runs.push({ text, ...style });
      return;
    }
    if (child.nodeType !== Node.ELEMENT_NODE) return;
    const el = child as HTMLElement;
    const tag = el.tagName.toLowerCase();
    if (tag === "br") {
      runs.push({ text: "\n", ...style });
      return;
    }
    if (tag === "img") {
      const rid = el.getAttribute("data-rid");
      if (rid) {
        runs.push({
          text: "",
          image: { rid, cx: Number(el.getAttribute("data-cx") ?? 0) || 0, cy: Number(el.getAttribute("data-cy") ?? 0) || 0 },
        });
      }
      return;
    }
    const next = {
      bold: style.bold || tag === "strong" || tag === "b",
      italic: style.italic || tag === "em" || tag === "i",
      mono: style.mono || tag === "code",
    };
    runs.push(...inlineRuns(el, next));
  });
  return runs;
}

function docxParagraph(runs: Run[], opts: { style?: string; bullet?: boolean; number?: number } = {}): string {
  const pPr: string[] = [];
  if (opts.style) pPr.push(`<w:pStyle w:val="${opts.style}"/>`);
  if (opts.bullet || opts.number) {
    pPr.push(`<w:ind w:left="420" w:hanging="420"/>`);
  }
  const prefix = opts.bullet ? "• " : opts.number ? `${opts.number}. ` : "";
  const body = runs
    .map((r) => {
      if (r.image) return docxImageRun(r.image);
      const props = [
        r.bold ? "<w:b/>" : "",
        r.italic ? "<w:i/>" : "",
        r.mono ? '<w:rFonts w:ascii="Consolas" w:hAnsi="Consolas" w:cs="Consolas"/>' : "",
      ].join("");
      const parts = String(r.text)
        .split("\n")
        .map((line, i) => (i === 0 ? "" : "<w:br/>") + `<w:t xml:space="preserve">${xml(line)}</w:t>`)
        .join("");
      return `<w:r>${props ? `<w:rPr>${props}</w:rPr>` : ""}${parts}</w:r>`;
    })
    .join("");
  const text = prefix ? `<w:r><w:t xml:space="preserve">${xml(prefix)}</w:t></w:r>` : "";
  return `<w:p>${pPr.length ? `<w:pPr>${pPr.join("")}</w:pPr>` : ""}${text}${body}</w:p>`;
}

const DOCX_STYLES =
  `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
  `<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">` +
  `<w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Calibri" w:hAnsi="Calibri" w:eastAsia="Yu Gothic" w:cs="Calibri"/>` +
  `<w:sz w:val="22"/><w:szCs w:val="22"/></w:rPr></w:rPrDefault><w:pPrDefault><w:pPr><w:spacing w:after="120" w:line="276" w:lineRule="auto"/></w:pPr></w:pPrDefault></w:docDefaults>` +
  `<w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/></w:style>` +
  `<w:style w:type="paragraph" w:styleId="Title"><w:name w:val="Title"/><w:basedOn w:val="Normal"/>` +
  `<w:pPr><w:spacing w:after="240"/></w:pPr><w:rPr><w:b/><w:sz w:val="48"/></w:rPr></w:style>` +
  [1, 2, 3].map((n) =>
    `<w:style w:type="paragraph" w:styleId="Heading${n}"><w:name w:val="heading ${n}"/><w:basedOn w:val="Normal"/>` +
    `<w:pPr><w:outlineLvl w:val="${n - 1}"/><w:spacing w:before="240" w:after="120"/></w:pPr>` +
    `<w:rPr><w:b/><w:sz w:val="${[36, 30, 26][n - 1]}"/></w:rPr></w:style>`,
  ).join("") +
  `<w:style w:type="paragraph" w:styleId="Quote"><w:name w:val="Quote"/><w:basedOn w:val="Normal"/>` +
  `<w:pPr><w:ind w:left="420"/></w:pPr><w:rPr><w:i/><w:color w:val="555555"/></w:rPr></w:style>` +
  `</w:styles>`;

export function makeDocx(title: string, html: string): Uint8Array {
  const blocks: string[] = [docxParagraph([{ text: title }], { style: "Title" })];
  const doc = new DOMParser().parseFromString(html || "<p></p>", "text/html");

  // --- 画像（word/media に埋め込む）------------------------------------
  const media: { rid: string; path: string; ext: string; bytes: Uint8Array }[] = [];
  Array.from(doc.querySelectorAll("img")).forEach((img) => {
    const parsed = parseDataUri(img.getAttribute("src") ?? "");
    if (!parsed || !parsed.mime.startsWith("image/")) {
      img.remove();
      return;
    }
    const index = media.length + 1;
    const size = imageSize(parsed.bytes);
    const pxW = size?.width ?? 480;
    const pxH = size?.height ?? 320;
    const maxW = 5_800_000; // EMU（本文幅に収まる上限）
    const emuW = pxW * 9525;
    const scale = emuW > maxW ? maxW / emuW : 1;
    const cx = Math.round(emuW * scale);
    const cy = Math.round(pxH * 9525 * scale);
    const rid = `rIdImg${index}`;
    media.push({ rid, path: `media/image${index}.${parsed.ext}`, ext: parsed.ext, bytes: parsed.bytes });
    img.setAttribute("data-rid", rid);
    img.setAttribute("data-cx", String(cx));
    img.setAttribute("data-cy", String(cy));
  });

  const pushList = (list: HTMLElement, ordered: boolean) => {
    Array.from(list.children).forEach((li, i) => {
      if (li.tagName.toLowerCase() !== "li") return;
      const runs = inlineRuns(li);
      blocks.push(docxParagraph(runs, ordered ? { number: i + 1 } : { bullet: true }));
    });
  };

  Array.from(doc.body.childNodes).forEach((node) => {
    // contenteditable の内容は「地の文 + div」になることがあるので、テキストノードも段落にする
    if (node.nodeType === Node.TEXT_NODE) {
      const runs = inlineRuns(node);
      if (runs.some((r) => r.text.trim() !== "")) blocks.push(docxParagraph(runs));
      return;
    }
    if (node.nodeType !== Node.ELEMENT_NODE) return;
    const el = node as HTMLElement;
    const tag = el.tagName.toLowerCase();
    if (tag === "ul" || tag === "ol") {
      pushList(el, tag === "ol");
      return;
    }
    if (tag === "table") {
      Array.from(el.querySelectorAll("tr")).forEach((tr) => {
        const cells = Array.from(tr.querySelectorAll("td,th")).map((td) => td.textContent ?? "");
        blocks.push(docxParagraph([{ text: cells.join("\t") }]));
      });
      return;
    }
    if (tag === "img") {
      // 画像そのものがブロックになる場合（contenteditable は <img> を直下に置く）
      const rid = el.getAttribute("data-rid");
      if (rid) {
        blocks.push(
          docxParagraph([
            {
              text: "",
              image: {
                rid,
                cx: Number(el.getAttribute("data-cx") ?? 0) || 0,
                cy: Number(el.getAttribute("data-cy") ?? 0) || 0,
              },
            },
          ]),
        );
      }
      return;
    }
    if (tag === "video") return; // 動画は docx に埋め込めない（Web 用の要素なので落とす）
    if (tag === "hr") {
      blocks.push(`<w:p><w:pPr><w:pBdr><w:bottom w:val="single" w:sz="6" w:space="1" w:color="CCCCCC"/></w:pBdr></w:pPr></w:p>`);
      return;
    }
    const runs = inlineRuns(el);
    if (runs.length === 0) return;
    const heading = /^h([1-6])$/.exec(tag);
    if (heading) {
      const level = Math.min(3, Number(heading[1]));
      blocks.push(docxParagraph(runs, { style: `Heading${level}` }));
    } else if (tag === "blockquote") {
      blocks.push(docxParagraph(runs, { style: "Quote" }));
    } else {
      blocks.push(docxParagraph(runs));
    }
  });

  const documentXml =
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
    `<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" ` +
    `xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" ` +
    `xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing"><w:body>` +
    blocks.join("") +
    `<w:sectPr><w:pgSz w:w="11906" w:h="16838"/>` +
    `<w:pgMar w:top="1134" w:right="1134" w:bottom="1134" w:left="1134" w:header="720" w:footer="720" w:gutter="0"/></w:sectPr>` +
    `</w:body></w:document>`;

  const entries: ZipEntry[] = [
    {
      name: "[Content_Types].xml",
      data:
        `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
        `<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">` +
        `<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>` +
        `<Default Extension="xml" ContentType="application/xml"/>` +
        `<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>` +
        `<Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>` +
        `<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>` +
        `<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>` +
        mediaContentTypes(media.map((m) => m.ext)) +
        `</Types>`,
    },
    {
      name: "_rels/.rels",
      data:
        `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
        `<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">` +
        `<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>` +
        `<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>` +
        `<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>` +
        `</Relationships>`,
    },
    { name: "docProps/core.xml", data: flatXml(coreProps(title)) },
    { name: "docProps/app.xml", data: flatXml(appProps("Document")) },
    {
      name: "word/_rels/document.xml.rels",
      data:
        `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
        `<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">` +
        `<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>` +
        media
          .map(
            (m) =>
              `<Relationship Id="${m.rid}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="${m.path}"/>`,
          )
          .join("") +
        `</Relationships>`,
    },
    { name: "word/document.xml", data: flatXml(documentXml) },
    { name: "word/styles.xml", data: flatXml(DOCX_STYLES) },
    ...media.map((m) => ({ name: `word/${m.path}`, data: m.bytes })),
  ];
  return makeZip(entries);
}

// --- .xlsx -----------------------------------------------------------------

const colName = (index: number): string => {
  let n = index + 1;
  let label = "";
  while (n > 0) {
    const rem = (n - 1) % 26;
    label = String.fromCharCode(65 + rem) + label;
    n = Math.floor((n - 1) / 26);
  }
  return label;
};

export function makeXlsx(title: string, grid: Grid, values: ValueGrid): Uint8Array {
  const rows: string[] = [];
  values.forEach((row, r) => {
    const cells: string[] = [];
    row.forEach((value, c) => {
      const raw = (grid[r]?.[c] ?? "").trim();
      const ref = `${colName(c)}${r + 1}`;
      if (raw.startsWith("=")) {
        const formula = stripControl(raw.slice(1));
        const shown = typeof value === "number" ? `<v>${value}</v>` : `<v></v>`;
        cells.push(`<c r="${ref}"><f>${xml(formula)}</f>${shown}</c>`);
        return;
      }
      if (typeof value === "number") {
        cells.push(`<c r="${ref}"><v>${value}</v></c>`);
        return;
      }
      const text = formatValue(value);
      if (!text) return;
      cells.push(`<c r="${ref}" t="inlineStr"><is><t xml:space="preserve">${xml(stripControl(text))}</t></is></c>`);
    });
    if (cells.length) rows.push(`<row r="${r + 1}">${cells.join("")}</row>`);
  });

  const lastRow = Math.max(1, rows.length);
  const lastCol = colName(Math.max(1, (values[0]?.length ?? 1) - 1));

  const sheetXml =
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
    `<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" ` +
    `xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">` +
    `<dimension ref="A1:${lastCol}${lastRow}"/>` +
    `<sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>` +
    `<sheetFormatPr defaultRowHeight="16"/>` +
    `<sheetData>${rows.join("")}</sheetData>` +
    `</worksheet>`;

  const workbookXml =
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
    `<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" ` +
    `xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">` +
    `<sheets><sheet name="${xml(sheetName(title))}" sheetId="1" r:id="rId1"/></sheets>` +
    `<calcPr calcId="0" fullCalcOnLoad="1"/></workbook>`;

  const stylesXml =
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
    `<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">` +
    `<fonts count="1"><font><sz val="11"/><name val="Calibri"/><family val="2"/></font></fonts>` +
    `<fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills>` +
    `<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>` +
    `<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>` +
    `<cellXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/></cellXfs>` +
    `<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>` +
    `</styleSheet>`;

  return makeZip([
    {
      name: "[Content_Types].xml",
      data:
        `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
        `<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">` +
        `<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>` +
        `<Default Extension="xml" ContentType="application/xml"/>` +
        `<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>` +
        `<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>` +
        `<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>` +
        `<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>` +
        `<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>` +
        `</Types>`,
    },
    {
      name: "_rels/.rels",
      data:
        `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
        `<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">` +
        `<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>` +
        `<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>` +
        `<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>` +
        `</Relationships>`,
    },
    { name: "docProps/core.xml", data: flatXml(coreProps(title)) },
    { name: "docProps/app.xml", data: flatXml(appProps("Spreadsheet")) },
    {
      name: "xl/_rels/workbook.xml.rels",
      data:
        `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
        `<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">` +
        `<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>` +
        `<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>` +
        `</Relationships>`,
    },
    { name: "xl/workbook.xml", data: flatXml(workbookXml) },
    { name: "xl/styles.xml", data: flatXml(stylesXml) },
    { name: "xl/worksheets/sheet1.xml", data: flatXml(sheetXml) },
  ]);
}

/** シート名は 31 文字まで・使用不可文字あり */
function sheetName(title: string): string {
  const cleaned = title.replace(/[[\]:*?/\\]/g, " ").trim() || "Sheet1";
  return cleaned.slice(0, 31);
}

// --- .pptx -----------------------------------------------------------------

const PPTX_THEME =
  `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
  `<a:theme xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" name="Poccham">` +
  `<a:themeElements>` +
  `<a:clrScheme name="Poccham">` +
  `<a:dk1><a:sysClr val="windowText" lastClr="000000"/></a:dk1>` +
  `<a:lt1><a:sysClr val="window" lastClr="FFFFFF"/></a:lt1>` +
  `<a:dk2><a:srgbClr val="1B1D22"/></a:dk2><a:lt2><a:srgbClr val="F6F6F8"/></a:lt2>` +
  `<a:accent1><a:srgbClr val="4F46E5"/></a:accent1><a:accent2><a:srgbClr val="22D3EE"/></a:accent2>` +
  `<a:accent3><a:srgbClr val="0F9D58"/></a:accent3><a:accent4><a:srgbClr val="F59E0B"/></a:accent4>` +
  `<a:accent5><a:srgbClr val="DC2626"/></a:accent5><a:accent6><a:srgbClr val="7C3AED"/></a:accent6>` +
  `<a:hlink><a:srgbClr val="4F46E5"/></a:hlink><a:folHlink><a:srgbClr val="7C3AED"/></a:folHlink>` +
  `</a:clrScheme>` +
  `<a:fontScheme name="Poccham">` +
  `<a:majorFont><a:latin typeface="Calibri"/><a:ea typeface=""/><a:cs typeface=""/></a:majorFont>` +
  `<a:minorFont><a:latin typeface="Calibri"/><a:ea typeface=""/><a:cs typeface=""/></a:minorFont>` +
  `</a:fontScheme>` +
  `<a:fmtScheme name="Poccham">` +
  `<a:fillStyleLst><a:solidFill><a:schemeClr val="phClr"/></a:solidFill>` +
  `<a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:fillStyleLst>` +
  `<a:lnStyleLst>` +
  `<a:ln w="6350" cap="flat" cmpd="sng" algn="ctr"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:prstDash val="solid"/></a:ln>` +
  `<a:ln w="12700" cap="flat" cmpd="sng" algn="ctr"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:prstDash val="solid"/></a:ln>` +
  `<a:ln w="19050" cap="flat" cmpd="sng" algn="ctr"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:prstDash val="solid"/></a:ln>` +
  `</a:lnStyleLst>` +
  `<a:effectStyleLst><a:effectStyle><a:effectLst/></a:effectStyle><a:effectStyle><a:effectLst/></a:effectStyle>` +
  `<a:effectStyle><a:effectLst/></a:effectStyle></a:effectStyleLst>` +
  `<a:bgFillStyleLst><a:solidFill><a:schemeClr val="phClr"/></a:solidFill>` +
  `<a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:bgFillStyleLst>` +
  `</a:fmtScheme></a:themeElements><a:objectDefaults/><a:extraClrSchemeLst/></a:theme>`;

const EMU_W = 12192000;
const EMU_H = 6858000;

/** 画像 1 枚を <p:pic> にする（ボックス内に収まるよう縦横比を保って拡大縮小） */
function pptxPicture(
  id: number,
  rid: string,
  box: { x: number; y: number; w: number; h: number },
  size: { width: number; height: number } | null,
): string {
  const natural = size ?? { width: 1280, height: 720 };
  const ratio = Math.min(box.w / natural.width, box.h / natural.height);
  const cx = Math.round(natural.width * ratio);
  const cy = Math.round(natural.height * ratio);
  const x = Math.round(box.x + (box.w - cx) / 2);
  const y = Math.round(box.y + (box.h - cy) / 2);
  return (
    `<p:pic><p:nvPicPr><p:cNvPr id="${id}" name="Image ${id}"/><p:cNvPicPr><a:picLocks noChangeAspect="1"/></p:cNvPicPr><p:nvPr/></p:nvPicPr>` +
    `<p:blipFill><a:blip r:embed="${rid}"/><a:stretch><a:fillRect/></a:stretch></p:blipFill>` +
    `<p:spPr><a:xfrm><a:off x="${x}" y="${y}"/><a:ext cx="${cx}" cy="${cy}"/></a:xfrm>` +
    `<a:prstGeom prst="rect"><a:avLst/></a:prstGeom></p:spPr></p:pic>`
  );
}

function pptxTextBox(id: number, name: string, x: number, y: number, w: number, h: number, paragraphs: string): string {
  return (
    `<p:sp><p:nvSpPr><p:cNvPr id="${id}" name="${xml(name)}"/><p:cNvSpPr txBox="1"/><p:nvPr/></p:nvSpPr>` +
    `<p:spPr><a:xfrm><a:off x="${x}" y="${y}"/><a:ext cx="${w}" cy="${h}"/></a:xfrm>` +
    `<a:prstGeom prst="rect"><a:avLst/></a:prstGeom><a:noFill/></p:spPr>` +
    `<p:txBody><a:bodyPr wrap="square" lIns="91440" tIns="45720" rIns="91440" bIns="45720"><a:normAutofit/></a:bodyPr>` +
    `<a:lstStyle/>${paragraphs}</p:txBody></p:sp>`
  );
}

function pptxRun(text: string, opts: { size?: number; bold?: boolean; color?: string } = {}): string {
  const attrs = `lang="ja-JP" altLang="en-US"` +
    (opts.size ? ` sz="${opts.size}"` : "") +
    (opts.bold ? ` b="1"` : "");
  const fill = opts.color ? `<a:solidFill><a:srgbClr val="${opts.color}"/></a:solidFill>` : "";
  return `<a:r><a:rPr ${attrs} dirty="0">${fill}</a:rPr><a:t>${xml(stripControl(text))}</a:t></a:r>`;
}

function pptxParagraph(text: string, opts: { size?: number; bold?: boolean; bullet?: boolean; color?: string; level?: number } = {}): string {
  const pPr =
    (opts.bullet ? `<a:buFont typeface="Arial"/><a:buChar char="•"/>` : `<a:buNone/>`) +
    (opts.level ? `<a:lvl>${opts.level}</a:lvl>` : "");
  return `<a:p><a:pPr marL="${opts.bullet ? 285750 : 0}" indent="${opts.bullet ? -285750 : 0}" algn="l">${pPr}</a:pPr>${pptxRun(text, opts)}</a:p>`;
}

function emptySpTree(): string {
  return (
    `<p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr>` +
    `<p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr>` +
    `</p:spTree>`
  );
}

const PPTX_NS =
  `xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" ` +
  `xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" ` +
  `xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"`;

export function makePptx(title: string, slides: Slide[]): Uint8Array {
  const list = slides.length ? slides : [{ title, body: "" }];
  const entries: ZipEntry[] = [];
  const media: { name: string; ext: string; bytes: Uint8Array }[] = [];

  const overrides: string[] = [];
  const presentationRels: string[] = [
    `<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideMaster" Target="slideMasters/slideMaster1.xml"/>`,
  ];
  const sldIds: string[] = [];

  list.forEach((slide, index) => {
    const id = index + 2;
    const lines = (slide.body || "").split(/\r?\n/).filter((line) => line.trim() !== "");
    const bodyParas = lines.length
      ? lines.map((line) => pptxParagraph(line, { size: 2000, bullet: true })).join("")
      : pptxParagraph("", { size: 2000 });

    // スライド画像（あれば ppt/media に埋め込む）
    const picture = parseDataUri(slide.image ?? "");
    const hasImage = Boolean(picture && picture.mime.startsWith("image/"));
    let imageXml = "";
    let imageRel = "";
    if (picture && hasImage) {
      const index = media.length + 1;
      const name = `image${index}.${picture.ext}`;
      media.push({ name, ext: picture.ext, bytes: picture.bytes });
      const rid = "rId2";
      imageRel = `<Relationship Id="${rid}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="../media/${name}"/>`;
      imageXml = pptxPicture(4, rid, { x: 5_400_000, y: 2_000_000, w: 6_100_000, h: 4_000_000 }, imageSize(picture.bytes));
    }

    // 画像があるときは本文を左カラムに寄せて重なりを避ける
    const bodyBox = hasImage
      ? { x: 838200, y: 2200000, w: 4_100_000, h: 3_800_000 }
      : { x: 838200, y: 2200000, w: 10_515_600, h: 3_800_000 };

    const slideXml =
      `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
      `<p:sld ${PPTX_NS}><p:cSld><p:spTree>` +
      `<p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr>` +
      `<p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr>` +
      pptxTextBox(2, "Title", 838200, 609600, 10515600, 1400000,
        `<a:p><a:pPr algn="l"><a:buNone/></a:pPr>${pptxRun(slide.title || title, { size: 3200, bold: true })}</a:p>`) +
      pptxTextBox(3, "Body", bodyBox.x, bodyBox.y, bodyBox.w, bodyBox.h, bodyParas) +
      imageXml +
      `</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sld>`;

    entries.push({ name: `ppt/slides/slide${index + 1}.xml`, data: flatXml(slideXml) });
    entries.push({
      name: `ppt/slides/_rels/slide${index + 1}.xml.rels`,
      data: flatXml(
        `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
          `<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">` +
          `<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideLayout" Target="../slideLayouts/slideLayout1.xml"/>` +
          imageRel +
          `</Relationships>`,
      ),
    });
    overrides.push(
      `<Override PartName="/ppt/slides/slide${index + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slide+xml"/>`,
    );
    presentationRels.push(
      `<Relationship Id="rId${id}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide" Target="slides/slide${index + 1}.xml"/>`,
    );
    sldIds.push(`<p:sldId id="${255 + index + 1}" r:id="rId${id}"/>`);
  });

  const presentationXml =
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
    `<p:presentation ${PPTX_NS} saveSubsetFonts="1">` +
    `<p:sldMasterIdLst><p:sldMasterId id="2147483648" r:id="rId1"/></p:sldMasterIdLst>` +
    `<p:sldIdLst>${sldIds.join("")}</p:sldIdLst>` +
    `<p:sldSz cx="${EMU_W}" cy="${EMU_H}"/><p:notesSz cx="6858000" cy="9144000"/>` +
    `</p:presentation>`;

  presentationRels.push(
    `<Relationship Id="rId${list.length + 2}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/theme" Target="theme/theme1.xml"/>`,
    `<Relationship Id="rId${list.length + 3}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/presProps" Target="presProps.xml"/>`,
    `<Relationship Id="rId${list.length + 4}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/viewProps" Target="viewProps.xml"/>`,
    `<Relationship Id="rId${list.length + 5}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/tableStyles" Target="tableStyles.xml"/>`,
  );

  const slideMasterXml =
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
    `<p:sldMaster ${PPTX_NS}><p:cSld>` +
    `<p:bg><p:bgRef idx="1001"><a:schemeClr val="bg1"/></p:bgRef></p:bg>` +
    emptySpTree() +
    `</p:cSld>` +
    `<p:clrMap bg1="lt1" tx1="dk1" bg2="lt2" tx2="dk2" accent1="accent1" accent2="accent2" accent3="accent3" ` +
    `accent4="accent4" accent5="accent5" accent6="accent6" hlink="hlink" folHlink="folHlink"/>` +
    `<p:sldLayoutIdLst><p:sldLayoutId id="2147483649" r:id="rId1"/></p:sldLayoutIdLst>` +
    `</p:sldMaster>`;

  const slideLayoutXml =
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
    `<p:sldLayout ${PPTX_NS} type="blank" preserve="1">` +
    `<p:cSld name="Blank">${emptySpTree()}</p:cSld>` +
    `<p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sldLayout>`;

  const presPropsXml =
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
    `<p:presentationPr ${PPTX_NS}/>`;
  const viewPropsXml =
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
    `<p:viewPr ${PPTX_NS}><p:normalViewPr/><p:slideViewPr><p:cSldViewPr><p:cViewPr varScale="1">` +
    `<p:scale><a:sx n="100" d="100"/><a:sy n="100" d="100"/></p:scale><p:origin x="0" y="0"/></p:cViewPr>` +
    `<p:guideLst/></p:cSldViewPr></p:slideViewPr><p:notesTextViewPr><p:cViewPr><p:scale><a:sx n="100" d="100"/><a:sy n="100" d="100"/></p:scale>` +
    `<p:origin x="0" y="0"/></p:cViewPr></p:notesTextViewPr><p:gridSpacing cx="72008" cy="72008"/></p:viewPr>`;
  const tableStylesXml =
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
    `<a:tblStyleLst xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" def="{5C22544A-7EE6-4342-B048-85BDC9FD1C3A}"/>`;

  entries.push(
    {
      name: "[Content_Types].xml",
      data:
        `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
        `<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">` +
        `<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>` +
        `<Default Extension="xml" ContentType="application/xml"/>` +
        `<Override PartName="/ppt/presentation.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml"/>` +
        `<Override PartName="/ppt/slideMasters/slideMaster1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideMaster+xml"/>` +
        `<Override PartName="/ppt/slideLayouts/slideLayout1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideLayout+xml"/>` +
        `<Override PartName="/ppt/theme/theme1.xml" ContentType="application/vnd.openxmlformats-officedocument.theme+xml"/>` +
        `<Override PartName="/ppt/presProps.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.presProps+xml"/>` +
        `<Override PartName="/ppt/viewProps.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.viewProps+xml"/>` +
        `<Override PartName="/ppt/tableStyles.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.tableStyles+xml"/>` +
        mediaContentTypes(media.map((m) => m.ext)) +
        overrides.join("") +
        `<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>` +
        `<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>` +
        `</Types>`,
    },
    {
      name: "_rels/.rels",
      data:
        `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
        `<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">` +
        `<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="ppt/presentation.xml"/>` +
        `<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>` +
        `<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>` +
        `</Relationships>`,
    },
    { name: "docProps/core.xml", data: flatXml(coreProps(title)) },
    { name: "docProps/app.xml", data: flatXml(appProps("Presentation")) },
    { name: "ppt/presentation.xml", data: flatXml(presentationXml) },
    {
      name: "ppt/_rels/presentation.xml.rels",
      data: flatXml(
        `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
          `<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${presentationRels.join("")}</Relationships>`,
      ),
    },
    { name: "ppt/slideMasters/slideMaster1.xml", data: flatXml(slideMasterXml) },
    {
      name: "ppt/slideMasters/_rels/slideMaster1.xml.rels",
      data: flatXml(
        `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
          `<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">` +
          `<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideLayout" Target="../slideLayouts/slideLayout1.xml"/>` +
          `<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/theme" Target="../theme/theme1.xml"/>` +
          `</Relationships>`,
      ),
    },
    { name: "ppt/slideLayouts/slideLayout1.xml", data: flatXml(slideLayoutXml) },
    {
      name: "ppt/slideLayouts/_rels/slideLayout1.xml.rels",
      data: flatXml(
        `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
          `<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">` +
          `<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideMaster" Target="../slideMasters/slideMaster1.xml"/>` +
          `</Relationships>`,
      ),
    },
    { name: "ppt/theme/theme1.xml", data: flatXml(PPTX_THEME) },
    { name: "ppt/presProps.xml", data: flatXml(presPropsXml) },
    { name: "ppt/viewProps.xml", data: flatXml(viewPropsXml) },
    { name: "ppt/tableStyles.xml", data: flatXml(tableStylesXml) },
    ...media.map((m) => ({ name: `ppt/media/${m.name}`, data: m.bytes })),
  );

  return makeZip(entries);
}

// --- .poccham（統合ネイティブ形式） ----------------------------------------

export const POCCHAM_VERSION = 1;

export interface PocchamFile {
  format: "poccham";
  version: number;
  app: string;
  exportedAt: string;
  documents: Array<{
    id: string;
    title: string;
    kind: Doc["kind"];
    content: string;
    plainText: string;
    pinned: boolean;
    createdAt: number;
    updatedAt: number;
  }>;
}

/** すべてのドキュメントを 1 つのネイティブファイルにまとめる */
export function makePoccham(docs: Doc[]): string {
  const payload: PocchamFile = {
    format: "poccham",
    version: POCCHAM_VERSION,
    app: "Suite with Poccham AI",
    exportedAt: new Date().toISOString(),
    documents: docs.map((d) => ({
      id: d.id,
      title: d.title,
      kind: d.kind,
      content: d.content,
      plainText: d.plainText,
      pinned: d.pinned,
      createdAt: d.createdAt,
      updatedAt: d.updatedAt,
    })),
  };
  return JSON.stringify(payload, null, 2);
}

/** .poccham を読み戻す（将来のインポート用） */
export function parsePoccham(text: string): PocchamFile {
  const data = JSON.parse(text) as PocchamFile;
  if (data?.format !== "poccham") throw new Error("poccham 形式ではありません");
  return data;
}

// --- まとめ ---------------------------------------------------------------

export type ExportFormat = "docx" | "xlsx" | "pptx" | "poccham" | "md" | "txt" | "html";

export const FORMAT_EXT: Record<ExportFormat, string> = {
  docx: "docx",
  xlsx: "xlsx",
  pptx: "pptx",
  poccham: "poccham",
  md: "md",
  txt: "txt",
  html: "html",
};

export const FORMAT_MIME: Record<ExportFormat, string> = {
  docx: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  xlsx: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  pptx: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
  poccham: "application/json",
  md: "text/markdown",
  txt: "text/plain",
  html: "text/html",
};

/** 種別ごとに出せる形式（先頭が既定） */
export function formatsFor(kind: Doc["kind"]): ExportFormat[] {
  if (kind === "sheet") return ["xlsx", "md", "txt", "poccham"];
  if (kind === "slide") return ["pptx", "md", "txt", "poccham"];
  return ["docx", "md", "txt", "html", "poccham"];
}

export function safeFileName(title: string): string {
  const cleaned = title.replace(/[/\\:*?"<>|]/g, "_").replace(/\s+/g, " ").trim();
  return (cleaned || "untitled").slice(0, 80);
}

export interface ExportedFile {
  name: string;
  mime: string;
  /** テキスト形式なら文字列、バイナリなら Uint8Array */
  data: string | Uint8Array;
}

/**
 * 1 つのドキュメントを指定形式へ変換する。
 * `grid` / `values` / `slides` はスプレッドシート・スライドのときだけ渡す。
 */
export function exportDocument(
  doc: Doc,
  format: ExportFormat,
  extra: {
    grid?: Grid;
    values?: ValueGrid;
    slides?: Slide[];
    allDocs?: Doc[];
  } = {},
): ExportedFile {
  const base = safeFileName(doc.title);
  const html = doc.content ?? "";

  switch (format) {
    case "docx":
      return { name: `${base}.docx`, mime: FORMAT_MIME.docx, data: makeDocx(doc.title, html) };
    case "xlsx":
      return {
        name: `${base}.xlsx`,
        mime: FORMAT_MIME.xlsx,
        data: makeXlsx(doc.title, extra.grid ?? [], extra.values ?? []),
      };
    case "pptx":
      return {
        name: `${base}.pptx`,
        mime: FORMAT_MIME.pptx,
        data: makePptx(doc.title, extra.slides ?? []),
      };
    case "poccham":
      return {
        name: `${base}.poccham`,
        mime: FORMAT_MIME.poccham,
        data: makePoccham(extra.allDocs ?? [doc]),
      };
    case "md": {
      const body = extra.slides
        ? slidesToMarkdown(extra.slides)
        : htmlToMarkdown(html) || doc.plainText;
      const text = doc.kind === "doc" ? `# ${doc.title}\n\n${body}`.trim() : `${doc.title}\n\n${body}`.trim();
      return { name: `${base}.md`, mime: FORMAT_MIME.md, data: `${text}\n` };
    }
    case "txt": {
      const body = extra.slides ? slidesToText(extra.slides) : htmlToPlainText(html) || doc.plainText;
      return { name: `${base}.txt`, mime: FORMAT_MIME.txt, data: `${doc.title}\n\n${body}`.trim() + "\n" };
    }
    case "html":
    default: {
      const body =
        `<!doctype html>\n<html lang="ja">\n<head>\n<meta charset="utf-8">\n<title>${xml(doc.title)}</title>\n` +
        `<style>body{font-family:system-ui,-apple-system,'Hiragino Sans',sans-serif;max-width:52rem;` +
        `margin:3rem auto;padding:0 1.25rem;line-height:1.85;color:#1d1d1f}` +
        `table{border-collapse:collapse}td,th{border:1px solid #ddd;padding:4px 8px}</style>\n</head>\n<body>\n` +
        `<h1>${xml(doc.title)}</h1>\n${html}\n</body>\n</html>\n`;
      return { name: `${base}.html`, mime: FORMAT_MIME.html, data: body };
    }
  }
}
