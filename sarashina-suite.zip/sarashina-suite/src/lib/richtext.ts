// 文章エディタの書式まわり（DOM 操作の寄せ集め。Svelte 非依存）
//
// contenteditable + execCommand だけでは「見出し」「表」「検索」などが弱いので、
// ブロック単位のスタイル適用・表の編集・検索置換をここにまとめて実装する。

export type ParaStyle =
  | "title"
  | "subtitle"
  | "h1"
  | "h2"
  | "h3"
  | "body"
  | "quote"
  | "code"
  | "caption";

export const PARA_STYLES: ParaStyle[] = ["title", "subtitle", "h1", "h2", "h3", "body", "quote", "code", "caption"];

const STYLE_TAG: Record<ParaStyle, string> = {
  title: "p",
  subtitle: "p",
  h1: "h1",
  h2: "h2",
  h3: "h3",
  body: "p",
  quote: "blockquote",
  code: "pre",
  caption: "p",
};

const STYLE_CLASS: Partial<Record<ParaStyle, string>> = {
  title: "ps-title",
  subtitle: "ps-subtitle",
  caption: "ps-caption",
};

const CLASS_TO_STYLE: Record<string, ParaStyle> = {
  "ps-title": "title",
  "ps-subtitle": "subtitle",
  "ps-caption": "caption",
};

const BLOCK_TAGS = new Set(["P", "DIV", "H1", "H2", "H3", "H4", "H5", "H6", "BLOCKQUOTE", "PRE", "LI", "TD", "TH", "SECTION", "FIGURE", "FIGCAPTION"]);

/** 選択範囲にかかわるブロック要素を集める（無ければキャレット位置のブロック） */
export function selectedBlocks(editor: HTMLElement): HTMLElement[] {
  const sel = window.getSelection();
  if (!sel || sel.rangeCount === 0) {
    if (document.activeElement instanceof HTMLElement && editor.contains(document.activeElement)) {
      const block = closestBlock(document.activeElement);
      return block ? [block] : [];
    }
    return [];
  }
  const range = sel.getRangeAt(0);
  const out: HTMLElement[] = [];
  const push = (el: HTMLElement | null) => {
    if (el && !out.includes(el) && editor.contains(el)) out.push(el);
  };

  if (range.collapsed) {
    push(closestBlock(range.startContainer));
    return out;
  }

  // 選択範囲に含まれるブロック（祖先をたどって editor の直下に近いブロックを拾う）
  const walker = document.createTreeWalker(editor, NodeFilter.SHOW_ELEMENT, {
    acceptNode: (node) => {
      const el = node as HTMLElement;
      if (!BLOCK_TAGS.has(el.tagName)) return NodeFilter.FILTER_SKIP;
      return range.intersectsNode(el) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
    },
  });
  let node = walker.nextNode();
  while (node) {
    push(node as HTMLElement);
    node = walker.nextNode();
  }
  if (!out.length) push(closestBlock(range.startContainer));
  // 入れ子（li > p など）は内側だけ残す
  return out.filter((el) => !out.some((other) => other !== el && el.contains(other)));
}

function closestBlock(node: Node | null): HTMLElement | null {
  let cur: Node | null = node;
  while (cur && cur.nodeType !== Node.ELEMENT_NODE) cur = cur.parentNode;
  while (cur && cur.nodeType === Node.ELEMENT_NODE) {
    const el = cur as HTMLElement;
    if (BLOCK_TAGS.has(el.tagName)) return el;
    cur = el.parentNode;
  }
  return null;
}

/** ブロックのスタイル（タイトル / 見出し / 本文 / 引用 / コード …）を適用する */
export function applyParagraphStyle(editor: HTMLElement, style: ParaStyle): void {
  const blocks = selectedBlocks(editor);
  for (const block of blocks) {
    if (block.tagName === "LI") continue; // 箇条書きの項目は崩さない
    const tag = STYLE_TAG[style];
    const next = document.createElement(tag);
    const cls = STYLE_CLASS[style];
    if (cls) next.className = cls;
    // 既存のスタイル用クラスは落とす
    next.innerHTML = block.innerHTML;
    next.removeAttribute("style");
    block.replaceWith(next);
  }
}

export function currentParagraphStyle(editor: HTMLElement | undefined): ParaStyle {
  if (!editor) return "body";
  const sel = window.getSelection();
  const node = sel && sel.rangeCount > 0 ? sel.getRangeAt(0).startContainer : null;
  const block = closestBlock(node) ?? closestBlock(document.activeElement);
  if (!block || !editor.contains(block)) return "body";
  for (const [cls, style] of Object.entries(CLASS_TO_STYLE)) {
    if (block.classList.contains(cls)) return style;
  }
  switch (block.tagName) {
    case "H1": return "h1";
    case "H2": return "h2";
    case "H3": return "h3";
    case "BLOCKQUOTE": return "quote";
    case "PRE": return "code";
    default: return "body";
  }
}

/** 選択部分を span で包んでスタイルを当てる（execCommand の <font> より後始末が楽） */
function wrapSelection(apply: (span: HTMLSpanElement) => void): boolean {
  const sel = window.getSelection();
  if (!sel || sel.rangeCount === 0) return false;
  const range = sel.getRangeAt(0);
  if (range.collapsed) return false;
  const span = document.createElement("span");
  apply(span);
  span.appendChild(range.extractContents());
  range.insertNode(span);
  const next = document.createRange();
  next.selectNodeContents(span);
  sel.removeAllRanges();
  sel.addRange(next);
  return true;
}

export function setFontSize(px: number): void {
  wrapSelection((span) => {
    span.style.fontSize = `${px}px`;
  });
}

export function setFontFamily(family: string): void {
  wrapSelection((span) => {
    span.style.fontFamily = family;
  });
}

export function setTextColor(color: string): void {
  document.execCommand("styleWithCSS", false, "true");
  document.execCommand("foreColor", false, color);
}

export function setHighlight(color: string): void {
  document.execCommand("styleWithCSS", false, "true");
  document.execCommand("hiliteColor", false, color);
}

export function clearFormatting(): void {
  document.execCommand("removeFormal");
  document.execCommand("removeFormat");
}

// ── 表 ──────────────────────────────────────────────────────────────────────
export function tableHtml(rows = 3, cols = 3, header = true): string {
  const head = header
    ? `<tr>${Array.from({ length: cols }, (_, c) => `<th>${c === 0 ? " " : " "}</th>`).join("")}</tr>`
    : "";
  const body = Array.from({ length: header ? rows - 1 : rows }, () =>
    `<tr>${Array.from({ length: cols }, () => "<td><br></td>").join("")}</tr>`,
  ).join("");
  return `<table class="tbl"><tbody>${head}${body}</tbody></table><p><br></p>`;
}

function cellAtSelection(): HTMLTableCellElement | null {
  const sel = window.getSelection();
  const node = sel && sel.rangeCount > 0 ? sel.getRangeAt(0).startContainer : document.activeElement;
  let cur: Node | null = node;
  while (cur && cur.nodeType !== Node.ELEMENT_NODE) cur = cur.parentNode;
  while (cur && cur.nodeType === Node.ELEMENT_NODE) {
    const el = cur as HTMLElement;
    if (el.tagName === "TD" || el.tagName === "TH") return el as HTMLTableCellElement;
    cur = el.parentNode;
  }
  return null;
}

export type TableAction = "rowAfter" | "rowBefore" | "colAfter" | "colBefore" | "delRow" | "delCol" | "toggleHeader" | "deleteTable";

export function tableAction(action: TableAction): boolean {
  const cell = cellAtSelection();
  if (!cell) return false;
  const row = cell.parentElement as HTMLTableRowElement;
  const table = cell.closest("table");
  if (!row || !table) return false;

  const rows = Array.from(table.querySelectorAll("tr"));
  const colCount = Math.max(...rows.map((r) => r.children.length));

  if (action === "rowAfter" || action === "rowBefore") {
    const tr = document.createElement("tr");
    for (let i = 0; i < colCount; i += 1) {
      const td = document.createElement("td");
      td.innerHTML = "<br>";
      tr.appendChild(td);
    }
    row[action === "rowAfter" ? "after" : "before"](tr);
    return true;
  }
  if (action === "colAfter" || action === "colBefore") {
    const index = Array.from(row.children).indexOf(cell);
    for (const tr of rows) {
      const target = tr.children[action === "colAfter" ? index + 1 : index] ?? null;
      const isHeader = tr.parentElement?.tagName === "THEAD" || (tr.children[0] as HTMLElement)?.tagName === "TH";
      const td = document.createElement(isHeader ? "th" : "td");
      td.innerHTML = "<br>";
      if (target) tr.insertBefore(td, target);
      else tr.appendChild(td);
    }
    return true;
  }
  if (action === "delRow") {
    if (rows.length <= 1) table.remove();
    else row.remove();
    return true;
  }
  if (action === "delCol") {
    const index = Array.from(row.children).indexOf(cell);
    for (const tr of rows) tr.children[index]?.remove();
    if (colCount <= 1) table.remove();
    return true;
  }
  if (action === "toggleHeader") {
    const firstRow = rows[0];
    if (!firstRow) return false;
    const isHeader = Array.from(firstRow.children).every((c) => c.tagName === "TH");
    for (const c of Array.from(firstRow.children)) {
      const el = document.createElement(isHeader ? "td" : "th");
      el.innerHTML = c.innerHTML;
      c.replaceWith(el);
    }
    return true;
  }
  table.remove();
  return true;
}

export function insertPageBreakHtml(): string {
  return `<div class="page-break" contenteditable="false"><span>改ページ</span></div><p><br></p>`;
}

export function insertRuleHtml(): string {
  return `<hr><p><br></p>`;
}

/** インラインの脚注風注記（脚注記号つき） */
export function insertFootnoteHtml(note: string): string {
  const safe = note.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  return `<sup class="fn" data-note="${safe}">[注]</sup>`;
}

// ── 検索・置換 ──────────────────────────────────────────────────────────────
export interface TextHit {
  range: Range;
  index: number;
}

function textNodes(root: HTMLElement): Text[] {
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
  const out: Text[] = [];
  let node = walker.nextNode();
  while (node) {
    const parent = (node as Text).parentElement;
    const tag = parent?.tagName ?? "";
    if (tag !== "SCRIPT" && tag !== "STYLE" && (node as Text).data.trim() !== "") out.push(node as Text);
    node = walker.nextNode();
  }
  return out;
}

export function findMatches(root: HTMLElement, query: string, caseSensitive = false): TextHit[] {
  const q = query;
  if (!q) return [];
  const hits: TextHit[] = [];
  const needle = caseSensitive ? q : q.toLowerCase();
  for (const node of textNodes(root)) {
    const haystack = caseSensitive ? node.data : node.data.toLowerCase();
    let from = 0;
    for (;;) {
      const at = haystack.indexOf(needle, from);
      if (at < 0) break;
      const range = document.createRange();
      range.setStart(node, at);
      range.setEnd(node, at + q.length);
      hits.push({ range, index: hits.length });
      from = at + Math.max(1, q.length);
    }
  }
  return hits;
}

export function paintHits(hits: TextHit[]): void {
  for (const hit of hits) {
    try {
      const mark = document.createElement("mark");
      mark.className = "find-hit";
      hit.range.surroundContents(mark);
    } catch {
      /* 要素をまたぐ一致はハイライトしない（置換は行える） */
    }
  }
}

export function clearPaintedHits(root: HTMLElement): void {
  for (const mark of Array.from(root.querySelectorAll("mark.find-hit"))) {
    const parent = mark.parentNode;
    if (!parent) continue;
    while (mark.firstChild) parent.insertBefore(mark.firstChild, mark);
    parent.removeChild(mark);
    parent.normalize();
  }
}

export function replaceHit(hit: TextHit, replacement: string): void {
  hit.range.deleteContents();
  const node = document.createTextNode(replacement);
  hit.range.insertNode(node);
}

export function replaceAll(root: HTMLElement, query: string, replacement: string, caseSensitive = false): number {
  const hits = findMatches(root, query, caseSensitive);
  for (let i = hits.length - 1; i >= 0; i -= 1) replaceHit(hits[i], replacement);
  return hits.length;
}

// ── アウトライン / 文字数 ───────────────────────────────────────────────────
export interface OutlineItem {
  level: number;
  text: string;
  el: HTMLElement;
}

export function documentOutline(root: HTMLElement): OutlineItem[] {
  const out: OutlineItem[] = [];
  for (const el of Array.from(root.querySelectorAll<HTMLElement>("h1,h2,h3,p.ps-title,p.ps-subtitle"))) {
    const text = (el.textContent ?? "").trim();
    if (!text) continue;
    const level = el.classList.contains("ps-title") ? 0
      : el.classList.contains("ps-subtitle") ? 1
      : Number(el.tagName.slice(1));
    out.push({ level, text, el });
  }
  return out;
}

export interface TextStats {
  chars: number;
  charsNoSpace: number;
  words: number;
  paragraphs: number;
  minutes: number;
}

/** 文字数・単語数・読了時間の目安（日本語は 500 字/分、英語は 200 語/分） */
export function textStats(text: string): TextStats {
  const chars = text.length;
  const charsNoSpace = text.replace(/\s/g, "").length;
  const cjk = (text.match(/[\u3040-\u30ff\u4e00-\u9fff\uac00-\ud7af]/g) ?? []).length;
  const latinWords = (text.replace(/[\u3040-\u30ff\u4e00-\u9fff\uac00-\ud7af]/g, " ").match(/[A-Za-z0-9][A-Za-z0-9'’.-]*/g) ?? []).length;
  const words = cjk + latinWords;
  const paragraphs = text.split(/\n{2,}/).filter((p) => p.trim() !== "").length;
  const minutes = Math.max(1, Math.round((charsNoSpace / 500 + latinWords / 200) * 10) / 10);
  return { chars, charsNoSpace, words, paragraphs, minutes };
}
