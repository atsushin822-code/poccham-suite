<script lang="ts">
  // 表計算エディタ。保存形式は HTML の table（sheet.ts 参照）なので
  // 検索・書き出しは既存の仕組みがそのまま使える。
  import { api } from "../api";
  import { t } from "../i18n.svelte";
  import {
    SHEET_COLS, SHEET_ROWS, colLabel, evaluateGrid, formatValue, gridToHtml,
    gridToText, htmlToGrid, type Grid,
  } from "../sheet";
  import type { Doc } from "../types";

  let {
    doc,
    onSaved,
  }: { doc: Doc | null; onSaved?: (updatedAt: number, title: string) => void } = $props();

  const AUTOSAVE_MS = 800;

  const emptyGrid = (): Grid =>
    Array.from({ length: SHEET_ROWS }, () => Array.from({ length: SHEET_COLS }, () => ""));

  let grid = $state<Grid>(emptyGrid());
  let values = $derived(evaluateGrid(grid));
  let titleInput = $state("");
  let loadedId = $state<string | null>(null);

  let selR = $state(0);
  let selC = $state(0);
  let editing = $state(false);
  let draft = $state("");

  let status = $state<"idle" | "dirty" | "saving" | "saved">("idle");
  let savedAt = $state(0);
  let pending = $state<{ id: string; title: string; content: string; plain: string } | null>(null);
  let saveTimer: ReturnType<typeof setTimeout> | undefined;

  $effect(() => {
    const current = doc;
    if (!current || current.id === loadedId) return;
    if (pending) void flush();
    loadedId = current.id;
    titleInput = current.title;
    grid = htmlToGrid(current.content);
    selR = 0;
    selC = 0;
    editing = false;
    status = "idle";
  });

  const cellName = (r: number, c: number) => `${colLabel(c)}${r + 1}`;
  const rawAt = (r: number, c: number) => grid[r]?.[c] ?? "";

  function setCell(r: number, c: number, text: string) {
    const next = grid.map((row) => [...row]);
    next[r][c] = text;
    grid = next;
  }

  function scheduleSave() {
    if (!loadedId) return;
    pending = {
      id: loadedId,
      title: titleInput,
      content: gridToHtml(grid, values),
      plain: gridToText(values),
    };
    status = "dirty";
    clearTimeout(saveTimer);
    saveTimer = setTimeout(() => void flush(), AUTOSAVE_MS);
  }

  async function flush() {
    const payload = pending;
    if (!payload) return;
    pending = null;
    status = "saving";
    try {
      const ts = await api.saveDocument(payload.id, payload.title, payload.content, payload.plain);
      savedAt = ts;
      status = "saved";
      onSaved?.(ts, payload.title);
    } catch (e) {
      console.error("保存に失敗しました", e);
      pending = payload;
      status = "dirty";
    }
  }

  function select(r: number, c: number) {
    if (editing) commitEdit("none");
    selR = Math.max(0, Math.min(SHEET_ROWS - 1, r));
    selC = Math.max(0, Math.min(SHEET_COLS - 1, c));
  }

  function startEdit(initial?: string) {
    draft = initial ?? rawAt(selR, selC);
    editing = true;
  }

  function commitEdit(move: "down" | "right" | "none" = "down") {
    if (!editing) return;
    setCell(selR, selC, draft);
    editing = false;
    scheduleSave();
    if (move === "down") select(selR + 1, selC);
    if (move === "right") select(selR, selC + 1);
  }

  function cancelEdit() {
    editing = false;
    draft = "";
  }

  function clearCell() {
    setCell(selR, selC, "");
    scheduleSave();
  }

  function onGridKeydown(event: KeyboardEvent) {
    if (editing) return;
    const k = event.key;
    if (k === "ArrowUp") {
      event.preventDefault();
      select(selR - 1, selC);
    } else if (k === "ArrowDown" || k === "Enter") {
      event.preventDefault();
      select(selR + 1, selC);
    } else if (k === "ArrowLeft") {
      if (event.shiftKey) return;
      event.preventDefault();
      select(selR, selC - 1);
    } else if (k === "ArrowRight") {
      event.preventDefault();
      select(selR, selC + 1);
    } else if (k === "Tab") {
      event.preventDefault();
      select(selR, selC + 1);
    } else if (k === "Delete" || k === "Backspace") {
      event.preventDefault();
      clearCell();
    } else if (k === "F2") {
      event.preventDefault();
      startEdit();
    } else if (k.length === 1 && !event.ctrlKey && !event.metaKey && !event.altKey) {
      event.preventDefault();
      startEdit(k);
    }
  }

  /** セル編集中の入力欄に確実にフォーカスを移す（autofocus は動的挿入で効かないことがある） */
  function focusOnMount(node: HTMLInputElement) {
    node.focus();
    node.setSelectionRange(node.value.length, node.value.length);
  }

  function onEditKeydown(event: KeyboardEvent) {
    if (event.key === "Enter") {
      event.preventDefault();
      commitEdit("down");
    } else if (event.key === "Tab") {
      event.preventDefault();
      commitEdit("right");
    } else if (event.key === "Escape") {
      event.preventDefault();
      cancelEdit();
    }
  }

  function onTitleInput() {
    scheduleSave();
  }

  function onFormulaInput(event: Event) {
    const value = (event.currentTarget as HTMLInputElement).value;
    setCell(selR, selC, value);
    scheduleSave();
  }

  function onWindowKeydown(event: KeyboardEvent) {
    if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "s") {
      event.preventDefault();
      void flush();
    }
  }

  const statusLabel = $derived(
    status === "saving"
      ? "保存中…"
      : status === "dirty"
        ? t("editor.dirty")
        : savedAt
          ? t("editor.saved", { time: new Date(savedAt).toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" }) })
          : "",
  );
</script>

<svelte:window onkeydown={onWindowKeydown} />

{#if !doc}
  <div class="placeholder center">
    <p class="faint">{t("editor.noDoc")}</p>
  </div>
{:else}
  <div class="sheet-shell">
    <div class="head">
      <input class="title" bind:value={titleInput} oninput={onTitleInput} aria-label={t("kind.sheet")} />
      <span class="spacer"></span>
      <span class="status mono">{statusLabel}</span>
    </div>

    <div class="formulabar">
      <span class="addr mono">{cellName(selR, selC)}</span>
      <input
        class="fx mono"
        value={rawAt(selR, selC)}
        oninput={onFormulaInput}
        aria-label={t("sheet.formula")}
        title={t("sheet.formula")}
      />
    </div>

    <div
      class="grid-wrap"
      role="grid"
      tabindex="0"
      onkeydown={onGridKeydown}
      aria-label={t("sheet.aria")}
    >
      <table class="sheet">
        <thead>
          <tr>
            <th class="corner"></th>
            {#each Array.from({ length: SHEET_COLS }, (_, c) => c) as c (c)}
              <th class:sel={selC === c}>{colLabel(c)}</th>
            {/each}
          </tr>
        </thead>
        <tbody>
          {#each Array.from({ length: SHEET_ROWS }, (_, r) => r) as r (r)}
            <tr>
              <th class="rowhead" class:sel={selR === r}>{r + 1}</th>
              {#each Array.from({ length: SHEET_COLS }, (_, c) => c) as c (c)}
                <td
                  class:sel={selR === r && selC === c}
                  class:num={typeof values[r][c] === "number"}
                  data-cell={cellName(r, c)}
                  onclick={() => select(r, c)}
                  ondblclick={() => {
                    select(r, c);
                    startEdit();
                  }}
                >
                  {#if editing && selR === r && selC === c}
                    <input
                      class="cell-input"
                      bind:value={draft}
                      onkeydown={onEditKeydown}
                      onblur={() => commitEdit("none")}
                      use:focusOnMount
                      aria-label={cellName(r, c)}
                    />
                  {:else}
                    {formatValue(values[r][c])}
                  {/if}
                </td>
              {/each}
            </tr>
          {/each}
        </tbody>
      </table>
    </div>

    <div class="foot">
      <span class="faint">{t("sheet.funcs")}</span>
    </div>
  </div>
{/if}

<style>
  .sheet-shell { display: flex; flex-direction: column; height: 100%; min-height: 0; background: var(--bg); }
  .grid-wrap { overscroll-behavior: contain; }
  .head {
    display: flex; align-items: center; gap: 10px;
    padding: 10px 18px; border-bottom: 1px solid var(--border);
  }
  .title {
    font-size: 20px; font-weight: 650; border: none; background: transparent;
    color: var(--text); outline: none; min-width: 240px; flex: 0 1 420px;
  }
  .spacer { flex: 1; }
  .status { font-size: 11px; color: var(--text-faint); }
  .formulabar {
    display: flex; align-items: center; gap: 8px;
    padding: 6px 14px; border-bottom: 1px solid var(--border); background: var(--bg-elev);
  }
  .addr { font-size: 12px; width: 54px; color: var(--text-faint); }
  .fx {
    flex: 1; font-size: 13px; padding: 5px 8px; border-radius: 8px;
    border: 1px solid var(--border); background: var(--bg); color: var(--text);
  }
  .grid-wrap { flex: 1; overflow: auto; min-height: 0; outline: none; }
  table.sheet { border-collapse: separate; border-spacing: 0; font-size: 13px; }
  th, td {
    border-right: 1px solid var(--border); border-bottom: 1px solid var(--border);
    padding: 0; height: 28px; min-width: 92px; max-width: 92px;
    white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
  }
  thead th {
    position: sticky; top: 0; z-index: 2;
    background: var(--bg-elev); color: var(--text-faint);
    font-weight: 600; font-size: 11px; text-align: center;
  }
  .rowhead {
    position: sticky; left: 0; z-index: 1;
    background: var(--bg-elev); color: var(--text-faint);
    font-weight: 500; font-size: 11px; text-align: center;
    min-width: 44px; max-width: 44px;
  }
  th.corner { position: sticky; left: 0; top: 0; z-index: 3; background: var(--bg-elev); min-width: 44px; }
  th.sel { background: color-mix(in srgb, var(--accent) 16%, var(--bg-elev)); color: var(--text); }
  td { padding: 0 6px; color: var(--text); }
  td.num { text-align: right; font-variant-numeric: tabular-nums; }
  td.sel {
    outline: 2px solid var(--accent); outline-offset: -2px;
    background: color-mix(in srgb, var(--accent) 8%, transparent);
  }
  .cell-input {
    width: 100%; height: 100%; box-sizing: border-box;
    border: none; outline: none; background: transparent;
    font: inherit; color: var(--text); padding: 0 5px;
  }
  .foot { padding: 6px 16px; border-top: 1px solid var(--border); font-size: 11px; }
  .placeholder { height: 100%; }
</style>
