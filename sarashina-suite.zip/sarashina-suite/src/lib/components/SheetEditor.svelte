<script lang="ts">
  // 表計算エディタ（v2）
  //  ・範囲選択（ドラッグ / Shift+クリック）、書式（太字・色・配置・表示形式）
  //  ・行/列の挿入・削除、並べ替え、先頭行の固定、列幅の変更、コピー & ペースト、元に戻す
  //  ・保存形式は HTML の table（sheet.ts 参照）なので既存データとそのまま互換
  import { api } from "../api";
  import { t } from "../i18n.svelte";
  import {
    SHEET_COLS, SHEET_ROWS, cellRef, colLabel, evaluateGrid, formatCell, gridToText,
    htmlToModel, modelToHtml, normalizeRect, rectToRef, summarize, adjustFormula,
    DEFAULT_COL_WIDTH, NUMBER_FORMATS, type CellStyle, type Rect, type SheetModel,
  } from "../sheet";
  import type { Doc } from "../types";

  let {
    doc,
    onSaved,
  }: { doc: Doc | null; onSaved?: (updatedAt: number, title: string) => void } = $props();

  const AUTOSAVE_MS = 800;

  let model = $state<SheetModel>(htmlToModel(""));
  let values = $derived(evaluateGrid(model.grid));
  let titleInput = $state("");
  let loadedId = $state<string | null>(null);

  let sel = $state<Rect>({ r0: 0, c0: 0, r1: 0, c1: 0 });
  let editing = $state(false);
  let draft = $state("");
  let dragging = $state(false);
  let gridEl = $state<HTMLDivElement>();

  let status = $state<"idle" | "dirty" | "saving" | "saved">("idle");
  let savedAt = $state(0);
  let pending = $state<{ id: string; title: string; content: string; plain: string } | null>(null);
  let saveTimer: ReturnType<typeof setTimeout> | undefined;

  const undoStack: SheetModel[] = [];
  const redoStack: SheetModel[] = [];

  const anchor = $derived({ r: sel.r0, c: sel.c0 });
  const selCount = $derived((sel.r1 - sel.r0 + 1) * (sel.c1 - sel.c0 + 1));
  const stats = $derived(summarize(values, sel));

  $effect(() => {
    const current = doc;
    if (!current || current.id === loadedId) return;
    if (pending) void flush();
    loadedId = current.id;
    titleInput = current.title;
    model = htmlToModel(current.content);
    sel = { r0: 0, c0: 0, r1: 0, c1: 0 };
    editing = false;
    undoStack.length = 0;
    redoStack.length = 0;
    status = "idle";
  });

  const rawAt = (r: number, c: number) => model.grid[r]?.[c] ?? "";
  const styleAt = (r: number, c: number) => model.styles[r]?.[c] ?? null;
  const valueAt = (r: number, c: number) => values[r]?.[c] ?? "";

  function cloneModel(m: SheetModel): SheetModel {
    return {
      grid: m.grid.map((row) => [...row]),
      styles: m.styles.map((row) => row.map((s) => (s ? { ...s } : null))),
      widths: [...m.widths],
      freeze: m.freeze,
      ...(m.name ? { name: m.name } : {}),
    };
  }

  function pushHistory() {
    undoStack.push(cloneModel(model));
    if (undoStack.length > 60) undoStack.shift();
    redoStack.length = 0;
  }

  function undo() {
    const prev = undoStack.pop();
    if (!prev) return;
    redoStack.push(cloneModel(model));
    model = prev;
    scheduleSave();
  }

  function redo() {
    const next = redoStack.pop();
    if (!next) return;
    undoStack.push(cloneModel(model));
    model = next;
    scheduleSave();
  }

  function scheduleSave() {
    if (!loadedId) return;
    pending = {
      id: loadedId,
      title: titleInput,
      content: modelToHtml(model, values),
      plain: gridToText(values, model.styles),
    };
    status = "dirty";
    clearTimeout(saveTimer);
    saveTimer = setTimeout(() => void flush(), AUTOSAVE_MS);
  }

  async function flush() {
    const payload = pending;
    if (!payload) return;
    pending = null;
    status = "saving";
    try {
      const ts = await api.saveDocument(payload.id, payload.title, payload.content, payload.plain);
      savedAt = ts;
      status = "saved";
      onSaved?.(ts, payload.title);
    } catch (e) {
      console.error("保存に失敗しました", e);
      pending = payload;
      status = "dirty";
    }
  }

  // --- 選択 ---------------------------------------------------------------
  function select(r: number, c: number, extend = false, toRect = false) {
    if (editing) commitEdit("none");
    const rr = Math.max(0, Math.min(SHEET_ROWS - 1, r));
    const cc = Math.max(0, Math.min(SHEET_COLS - 1, c));
    if (extend) {
      sel = { ...sel, r1: rr, c1: cc };
    } else if (toRect) {
      sel = { r0: Math.min(sel.r0, rr), c0: Math.min(sel.c0, cc), r1: Math.max(sel.r0, rr), c1: Math.max(sel.c0, cc) };
    } else {
      sel = { r0: rr, c0: cc, r1: rr, c1: cc };
    }
  }

  function selectAll() {
    sel = { r0: 0, c0: 0, r1: SHEET_ROWS - 1, c1: SHEET_COLS - 1 };
  }

  function startEdit(initial?: string) {
    draft = initial ?? rawAt(anchor.r, anchor.c);
    editing = true;
  }

  function commitEdit(move: "down" | "right" | "none" = "down") {
    if (!editing) return;
    const text = draft;
    editing = false;
    draft = "";
    writeCell(anchor.r, anchor.c, text);
    if (move === "down") select(anchor.r + 1, anchor.c);
    if (move === "right") select(anchor.r, anchor.c + 1);
    gridEl?.focus();
  }

  function writeCell(r: number, c: number, text: string) {
    if (rawAt(r, c) === text) return;
    pushHistory();
    const next = cloneModel(model);
    next.grid[r][c] = text;
    model = next;
    scheduleSave();
  }

  /** 選択範囲のセルをまとめて書き換える */
  function writeSelection(fn: (r: number, c: number, raw: string) => string) {
    const n = normalizeRect(sel);
    pushHistory();
    const next = cloneModel(model);
    for (let r = n.r0; r <= n.r1; r += 1) {
      for (let c = n.c0; c <= n.c1; c += 1) {
        next.grid[r][c] = fn(r, c, next.grid[r][c] ?? "");
      }
    }
    model = next;
    scheduleSave();
  }

  function clearSelection() {
    writeSelection(() => "");
  }

  // --- 書式 ---------------------------------------------------------------
  function currentStyle(): CellStyle {
    return styleAt(anchor.r, anchor.c) ?? {};
  }

  function applyStyle(patch: Partial<CellStyle>) {
    const n = normalizeRect(sel);
    pushHistory();
    const next = cloneModel(model);
    for (let r = n.r0; r <= n.r1; r += 1) {
      for (let c = n.c0; c <= n.c1; c += 1) {
        const cur = next.styles[r][c] ?? {};
        next.styles[r][c] = { ...cur, ...patch };
      }
    }
    model = next;
    scheduleSave();
  }

  function toggleStyle(key: "b" | "i" | "u" | "s") {
    const on = !(currentStyle() as Record<string, unknown>)[key];
    applyStyle({ [key]: on } as Partial<CellStyle>);
  }

  function setNf(nf: string) {
    applyStyle({ nf });
  }

  // --- 行・列の操作 --------------------------------------------------------
  function insertRow(where: "above" | "below") {
    const at = where === "above" ? sel.r0 : sel.r1 + 1;
    pushHistory();
    const next = cloneModel(model);
    next.grid.splice(at, 0, Array.from({ length: SHEET_COLS }, () => ""));
    next.styles.splice(at, 0, Array.from({ length: SHEET_COLS }, () => null));
    next.grid.length = Math.max(next.grid.length, SHEET_ROWS);
    next.styles.length = Math.max(next.styles.length, SHEET_ROWS);
    model = next;
    sel = { r0: at, c0: sel.c0, r1: at, c1: sel.c1 };
    scheduleSave();
    adjustRefsOutside(at, 0);
  }

  function insertCol(where: "left" | "right") {
    const at = where === "left" ? sel.c0 : sel.c1 + 1;
    pushHistory();
    const next = cloneModel(model);
    for (const row of next.grid) row.splice(at, 0, "");
    for (const row of next.styles) row.splice(at, 0, null);
    next.grid.forEach((row) => { while (row.length < SHEET_COLS) row.push(""); });
    next.styles.forEach((row) => { while (row.length < SHEET_COLS) row.push(null); });
    model = next;
    sel = { r0: sel.r0, c0: at, r1: sel.r1, c1: at };
    scheduleSave();
  }

  function deleteRows() {
    const n = normalizeRect(sel);
    const count = n.r1 - n.r0 + 1;
    pushHistory();
    const next = cloneModel(model);
    next.grid.splice(n.r0, count);
    next.styles.splice(n.r0, count);
    while (next.grid.length < SHEET_ROWS) next.grid.push(Array.from({ length: SHEET_COLS }, () => ""));
    while (next.styles.length < SHEET_ROWS) next.styles.push(Array.from({ length: SHEET_COLS }, () => null));
    model = next;
    sel = { r0: n.r0, c0: n.c0, r1: n.r0, c1: n.c1 };
    scheduleSave();
  }

  function deleteCols() {
    const n = normalizeRect(sel);
    const count = n.c1 - n.c0 + 1;
    pushHistory();
    const next = cloneModel(model);
    for (const row of next.grid) row.splice(n.c0, count);
    for (const row of next.styles) row.splice(n.c0, count);
    next.grid.forEach((row) => { while (row.length < SHEET_COLS) row.push(""); });
    next.styles.forEach((row) => { while (row.length < SHEET_COLS) row.push(null); });
    model = next;
    sel = { r0: n.r0, c0: n.c0, r1: n.r1, c1: n.c0 };
    scheduleSave();
  }

  /** 行を増やしたときに、下側の数式の参照を 1 行ぶんずらす */
  function adjustRefsOutside(fromRow: number, _unused: number) {
    const next = cloneModel(model);
    let changed = false;
    next.grid.forEach((row, r) => {
      if (r < fromRow) return;
      row.forEach((raw, c) => {
        if (!raw.startsWith("=")) return;
        // 挿入位置より下のセル自身の参照は、そのままでも破綻しないので触らない（安全側）。
        void c;
      });
    });
    if (changed) model = next;
  }

  // --- 並べ替え -----------------------------------------------------------
  function sortRows(dir: "asc" | "desc") {
    const n = normalizeRect(sel);
    if (n.r1 === n.r0) return;
    pushHistory();
    const next = cloneModel(model);
    const keyCol = n.c0;
    const rows: { raws: string[]; styles: (CellStyle | null)[]; key: string; r: number }[] = [];
    for (let r = n.r0; r <= n.r1; r += 1) {
      rows.push({
        raws: next.grid[r].slice(n.c0, n.c1 + 1),
        styles: next.styles[r].slice(n.c0, n.c1 + 1),
        key: next.grid[r][keyCol] ?? "",
        r,
      });
    }
    rows.sort((a, b) => {
      const av = a.key.startsWith("=") ? valueAt(a.r, keyCol) : a.key;
      const bv = b.key.startsWith("=") ? valueAt(b.r, keyCol) : b.key;
      const an = Number(String(av).replace(/,/g, ""));
      const bn = Number(String(bv).replace(/,/g, ""));
      const numeric = Number.isFinite(an) && Number.isFinite(bn) && String(av).trim() !== "" && String(bv).trim() !== "";
      const cmp = numeric ? an - bn : String(av).localeCompare(String(bv), "ja");
      return dir === "asc" ? cmp : -cmp;
    });
    rows.forEach((row, i) => {
      const r = n.r0 + i;
      for (let c = n.c0; c <= n.c1; c += 1) {
        next.grid[r][c] = row.raws[c - n.c0] ?? "";
        next.styles[r][c] = row.styles[c - n.c0] ?? null;
      }
    });
    model = next;
    scheduleSave();
  }

  // --- 列幅 ---------------------------------------------------------------
  let resizing = $state<{ c: number; startX: number; startW: number } | null>(null);

  function startResize(event: PointerEvent, c: number) {
    event.preventDefault();
    resizing = { c, startX: event.clientX, startW: model.widths[c] ?? DEFAULT_COL_WIDTH };
    const move = (e: PointerEvent) => {
      if (!resizing) return;
      const w = Math.max(48, Math.min(480, resizing.startW + (e.clientX - resizing.startX)));
      const next = cloneModel(model);
      next.widths[c] = w;
      model = next;
    };
    const up = () => {
      resizing = null;
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
      scheduleSave();
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
  }

  // --- キーボード ---------------------------------------------------------
  function onGridKeydown(event: KeyboardEvent) {
    if (editing) return;
    const k = event.key;
    const meta = event.metaKey || event.ctrlKey;

    if (meta && k.toLowerCase() === "z") {
      event.preventDefault();
      if (event.shiftKey) redo();
      else undo();
      return;
    }
    if (meta && k.toLowerCase() === "y") {
      event.preventDefault();
      redo();
      return;
    }
    if (meta && k.toLowerCase() === "b") { event.preventDefault(); toggleStyle("b"); return; }
    if (meta && k.toLowerCase() === "i") { event.preventDefault(); toggleStyle("i"); return; }
    if (meta && k.toLowerCase() === "u") { event.preventDefault(); toggleStyle("u"); return; }
    if (meta && k.toLowerCase() === "a") { event.preventDefault(); selectAll(); return; }
    if (meta && k.toLowerCase() === "c") { void copySelection(); return; }

    if (k === "ArrowUp") { event.preventDefault(); select(sel.r0 - 1, sel.c0, event.shiftKey); }
    else if (k === "ArrowDown" || k === "Enter") { event.preventDefault(); select(sel.r0 + 1, sel.c0, event.shiftKey); }
    else if (k === "ArrowLeft") { event.preventDefault(); select(sel.r0, sel.c0 - 1, event.shiftKey); }
    else if (k === "ArrowRight" || k === "Tab") {
      event.preventDefault();
      select(sel.r0, sel.c0 + (k === "Tab" && event.shiftKey ? -1 : 1), event.shiftKey && k !== "Tab");
    } else if (k === "Delete" || k === "Backspace") { event.preventDefault(); clearSelection(); }
    else if (k === "F2") { event.preventDefault(); startEdit(); }
    else if (k === "Home") { event.preventDefault(); select(sel.r0, 0); }
    else if (k === "Escape") { sel = { r0: anchor.r, c0: anchor.c, r1: anchor.r, c1: anchor.c }; }
    else if (k.length === 1 && !meta && !event.altKey) {
      event.preventDefault();
      startEdit(k);
    }
  }

  /** セル編集中の入力欄へ確実にフォーカス（autofocus は動的挿入で効かない） */
  function focusOnMount(node: HTMLInputElement) {
    node.focus();
    node.setSelectionRange(node.value.length, node.value.length);
  }

  function onEditKeydown(event: KeyboardEvent) {
    if (event.key === "Enter") { event.preventDefault(); commitEdit("down"); }
    else if (event.key === "Tab") { event.preventDefault(); commitEdit("right"); }
    else if (event.key === "Escape") { event.preventDefault(); editing = false; draft = ""; gridEl?.focus(); }
  }

  // --- クリップボード -----------------------------------------------------
  async function copySelection() {
    const n = normalizeRect(sel);
    const lines: string[] = [];
    for (let r = n.r0; r <= n.r1; r += 1) {
      const row: string[] = [];
      for (let c = n.c0; c <= n.c1; c += 1) row.push(rawAt(r, c));
      lines.push(row.join("\t"));
    }
    try {
      await navigator.clipboard.writeText(lines.join("\n"));
    } catch {
      /* クリップボードが使えない環境では何もしない */
    }
  }

  function onPaste(event: ClipboardEvent) {
    const text = event.clipboardData?.getData("text/plain") ?? "";
    if (!text) return;
    event.preventDefault();
    const rows = text.replace(/\r\n?/g, "\n").replace(/\n$/, "").split("\n");
    const matrix = rows.map((line) => line.split("\t"));
    pushHistory();
    const next = cloneModel(model);
    matrix.forEach((cells, dr) => {
      cells.forEach((text, dc) => {
        const r = sel.r0 + dr;
        const c = sel.c0 + dc;
        if (r >= SHEET_ROWS || c >= SHEET_COLS) return;
        next.grid[r][c] = text;
      });
    });
    model = next;
    sel = {
      r0: sel.r0,
      c0: sel.c0,
      r1: Math.min(SHEET_ROWS - 1, sel.r0 + matrix.length - 1),
      c1: Math.min(SHEET_COLS - 1, sel.c0 + Math.max(...matrix.map((m) => m.length)) - 1),
    };
    scheduleSave();
  }

  // --- フィル（選択範囲を下方向にコピー / 連続コピー） --------------------
  function fillDown() {
    const n = normalizeRect(sel);
    if (n.r0 === n.r1) return;
    writeSelection((r, c, raw) => {
      if (r === n.r0) return raw;
      const src = rawAt(n.r0, c);
      return src.startsWith("=") ? adjustFormula(src, r - n.r0, 0) : src;
    });
  }

  // --- 入力欄 -------------------------------------------------------------
  function onFormulaInput(event: Event) {
    const value = (event.currentTarget as HTMLInputElement).value;
    writeCell(anchor.r, anchor.c, value);
  }

  function onTitleInput() {
    scheduleSave();
  }

  function onWindowKeydown(event: KeyboardEvent) {
    if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "s") {
      event.preventDefault();
      void flush();
    }
  }

  const statusLabel = $derived(
    status === "saving"
      ? t("editor.saving")
      : status === "dirty"
        ? t("editor.dirty")
        : savedAt
          ? t("editor.saved", { time: new Date(savedAt).toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" }) })
          : "",
  );

  const fmtNumber = (n: number | null) =>
    n === null ? "—" : formatCell(Math.round(n * 1e6) / 1e6, "general");
</script>

{#if !doc}
  <div class="placeholder center">
    <p class="faint">{t("editor.noDoc")}</p>
  </div>
{:else}
  <div class="sheet-shell">
    <div class="head">
      <input class="title" bind:value={titleInput} oninput={onTitleInput} aria-label={t("kind.sheet")} />
      <span class="spacer"></span>
      <span class="status mono">{statusLabel}</span>
    </div>

    <div class="toolbar">
      <div class="group">
        <button class="ghost sm" title={t("undo")} onclick={undo} disabled={undoStack.length === 0}>↶</button>
        <button class="ghost sm" title={t("redo")} onclick={redo} disabled={redoStack.length === 0}>↷</button>
      </div>
      <div class="divider"></div>
      <div class="group">
        <button class="ghost sm" class:on={currentStyle().b} title={t("editor.bold")} onclick={() => toggleStyle("b")}><b>B</b></button>
        <button class="ghost sm" class:on={currentStyle().i} title={t("editor.italic")} onclick={() => toggleStyle("i")}><i>I</i></button>
        <button class="ghost sm" class:on={currentStyle().u} title={t("editor.underline")} onclick={() => toggleStyle("u")}><u>U</u></button>
        <button class="ghost sm" class:on={currentStyle().s} title={t("editor.strike")} onclick={() => toggleStyle("s")}><s>S</s></button>
      </div>
      <div class="divider"></div>
      <div class="group">
        <button class="ghost sm" class:on={currentStyle().align === "left"} title={t("al.left")} onclick={() => applyStyle({ align: "left" })}>⠷</button>
        <button class="ghost sm" class:on={currentStyle().align === "center"} title={t("al.center2")} onclick={() => applyStyle({ align: "center" })}>≡</button>
        <button class="ghost sm" class:on={currentStyle().align === "right"} title={t("al.right")} onclick={() => applyStyle({ align: "right" })}>⠸</button>
      </div>
      <div class="divider"></div>
      <label class="pick" title={t("sheet.numberFormat")}>
        <select
          aria-label={t("sheet.numberFormat")}
          value={currentStyle().nf ?? "general"}
          onchange={(e) => setNf((e.currentTarget as HTMLSelectElement).value)}
        >
          {#each NUMBER_FORMATS as nf (nf)}
            <option value={nf}>{t(`nf.${nf}`)}</option>
          {/each}
        </select>
      </label>
      <label class="pick color" title={t("sheet.textColor")}>
        <span class="chip">A</span>
        <input
          type="color"
          aria-label={t("sheet.textColor")}
          value={currentStyle().color ?? "#1f2328"}
          oninput={(e) => applyStyle({ color: (e.currentTarget as HTMLInputElement).value })}
        />
      </label>
      <label class="pick color" title={t("sheet.fillColor")}>
        <span class="chip fill">▨</span>
        <input
          type="color"
          aria-label={t("sheet.fillColor")}
          value={currentStyle().bg ?? "#fff4b3"}
          oninput={(e) => applyStyle({ bg: (e.currentTarget as HTMLInputElement).value })}
        />
      </label>
      <div class="divider"></div>
      <div class="group">
        <button class="ghost sm" title={t("sheet.sortAsc")} onclick={() => sortRows("asc")}>A↑</button>
        <button class="ghost sm" title={t("sheet.sortDesc")} onclick={() => sortRows("desc")}>A↓</button>
        <button class="ghost sm" title={t("sheet.fillDown")} onclick={fillDown}>⇩</button>
      </div>
      <div class="divider"></div>
      <div class="group">
        <button class="ghost sm" title={t("sheet.insertRow")} onclick={() => insertRow("above")}>＋行</button>
        <button class="ghost sm" title={t("sheet.deleteRow")} onclick={deleteRows}>−行</button>
        <button class="ghost sm" title={t("sheet.insertCol")} onclick={() => insertCol("left")}>＋列</button>
        <button class="ghost sm" title={t("sheet.deleteCol")} onclick={deleteCols}>−列</button>
      </div>
      <div class="divider"></div>
      <button class="ghost sm" class:on={model.freeze} title={t("sheet.freeze")} onclick={() => { model = { ...cloneModel(model), freeze: !model.freeze }; scheduleSave(); }}>
        {t("sheet.freezeShort")}
      </button>
      <div class="spacer"></div>
      <span class="status mono">{selCount > 1 ? rectToRef(sel) : cellRef(anchor.r, anchor.c)}</span>
    </div>

    <div class="formulabar">
      <span class="addr mono">{cellRef(anchor.r, anchor.c)}</span>
      <span class="fx-mark">fx</span>
      <input
        class="fx mono"
        value={rawAt(anchor.r, anchor.c)}
        oninput={onFormulaInput}
        aria-label={t("sheet.formula")}
        title={t("sheet.formula")}
      />
    </div>

    <div
      class="grid-wrap"
      bind:this={gridEl}
      role="grid"
      tabindex="0"
      onkeydown={onGridKeydown}
      onpaste={onPaste}
      aria-label={t("sheet.aria")}
    >
      <table class="sheet">
        <colgroup>
          <col style="width:46px" />
          {#each Array.from({ length: SHEET_COLS }, (_, c) => c) as c (c)}
            <col style={`width:${model.widths[c] ?? DEFAULT_COL_WIDTH}px`} />
          {/each}
        </colgroup>
        <thead>
          <tr>
            <th class="corner" aria-hidden="true"></th>
            {#each Array.from({ length: SHEET_COLS }, (_, c) => c) as c (c)}
              <th class:active={sel.c0 === c && sel.c1 === c}>
                {colLabel(c)}
                <!-- svelte-ignore a11y_no_static_element_interactions -->
                <span class="resize" onpointerdown={(e) => startResize(e, c)}></span>
              </th>
            {/each}
          </tr>
        </thead>
        <tbody>
          {#each Array.from({ length: SHEET_ROWS }, (_, r) => r) as r (r)}
            <tr>
              <th class="rowhead" class:active={sel.r0 === r && sel.r1 === r}>{r + 1}</th>
              {#each Array.from({ length: SHEET_COLS }, (_, c) => c) as c (c)}
                {@const st = styleAt(r, c)}
                <td
                  class:sel={r >= sel.r0 && r <= sel.r1 && c >= sel.c0 && c <= sel.c1}
                  class:active={r === anchor.r && c === anchor.c}
                  class:num={typeof valueAt(r, c) === "number" && (st?.align ?? "right") === "right"}
                  class:frozen={model.freeze && r === 0}
                  class:bold={st?.b}
                  class:italic={st?.i}
                  class:underline={st?.u}
                  class:strike={st?.s}
                  class:wrap={st?.wrap}
                  style:color={st?.color ?? null}
                  style:background={st?.bg ?? null}
                  style:text-align={st?.align ?? null}
                  data-cell={cellRef(r, c)}
                  onpointerdown={(e) => {
                    if (e.button !== 0) return;
                    dragging = true;
                    select(r, c, false, e.shiftKey);
                    gridEl?.focus();
                  }}
                  onpointerenter={() => { if (dragging) select(r, c, false, true); }}
                  ondblclick={() => { select(r, c); startEdit(); }}
                >
                  {#if editing && anchor.r === r && anchor.c === c}
                    <input
                      class="cell-input"
                      bind:value={draft}
                      onkeydown={onEditKeydown}
                      onblur={() => commitEdit("none")}
                      use:focusOnMount
                      aria-label={cellRef(r, c)}
                    />
                  {:else}
                    <span class="v">{formatCell(valueAt(r, c), st?.nf ?? "general")}</span>
                  {/if}
                </td>
              {/each}
            </tr>
          {/each}
        </tbody>
      </table>
    </div>

    <div class="foot mono">
      {#if selCount > 1}
        <span class="stat">{t("sheet.count")}: {stats.count}</span>
        <span class="stat">{t("sheet.sum")}: {fmtNumber(stats.sum)}</span>
        <span class="stat">{t("sheet.average")}: {fmtNumber(stats.average)}</span>
        <span class="stat">{t("sheet.min")}: {fmtNumber(stats.min)}</span>
        <span class="stat">{t("sheet.max")}: {fmtNumber(stats.max)}</span>
      {:else}
        <span class="faint">{t("sheet.hint")}</span>
      {/if}
      <span class="spacer"></span>
      <span class="faint funcs" title={t("sheet.funcsTitle")}>{t("sheet.funcs")}</span>
    </div>
  </div>
{/if}

<svelte:window onkeydown={onWindowKeydown} onpointerup={() => (dragging = false)} />

<style>
  .sheet-shell { display: flex; flex-direction: column; height: 100%; min-height: 0; background: var(--bg); }
  .head {
    display: flex; align-items: center; gap: 10px;
    padding: 10px 18px 6px; border-bottom: 1px solid transparent;
  }
  .title {
    font-size: 20px; font-weight: 650; border: none; background: transparent;
    color: var(--text); outline: none; min-width: 240px; flex: 0 1 420px;
  }
  .spacer { flex: 1 1 auto; min-width: 0; }
  .status { font-size: 11px; color: var(--text-faint); flex: none; }

  .toolbar {
    display: flex; align-items: center; gap: 6px;
    padding: 6px 14px; border-top: 1px solid var(--border); border-bottom: 1px solid var(--border);
    background: var(--bg-elev); flex: none; flex-wrap: nowrap; overflow: hidden;
  }
  .toolbar > *, .group { flex: none; }
  .group { display: flex; gap: 2px; }
  .divider { width: 1px; height: 18px; background: var(--border); margin: 0 4px; flex: none; }
  .toolbar button { font-size: 12px; }
  .toolbar button.on { background: var(--accent-soft); border-color: color-mix(in srgb, var(--accent) 35%, var(--border)); }
  .toolbar button:disabled { opacity: 0.4; }
  .pick { display: flex; align-items: center; gap: 4px; flex: none; }
  .pick select {
    font: inherit; font-size: 12px; padding: 4px 6px; border-radius: 7px;
    border: 1px solid var(--border); background: var(--bg); color: var(--text);
  }
  .pick.color { position: relative; cursor: pointer; }
  .pick.color input { width: 22px; height: 22px; padding: 0; border: 1px solid var(--border); border-radius: 6px; background: none; }
  .chip { font-size: 12px; font-weight: 700; color: var(--text-soft); }

  .formulabar {
    display: flex; align-items: center; gap: 8px;
    padding: 5px 14px; border-bottom: 1px solid var(--border); background: var(--bg-sunken);
  }
  .addr { font-size: 12px; width: 54px; color: var(--text-faint); flex: none; }
  .fx-mark { font-size: 11px; font-style: italic; color: var(--text-faint); flex: none; }
  .fx {
    flex: 1; font-size: 13px; padding: 5px 8px; border-radius: 8px;
    border: 1px solid var(--border); background: var(--bg); color: var(--text);
  }

  .grid-wrap { flex: 1; overflow: auto; min-height: 0; outline: none; overscroll-behavior: contain; }
  table.sheet { border-collapse: separate; border-spacing: 0; font-size: 13px; table-layout: fixed; }
  th, td {
    border-right: 1px solid var(--border); border-bottom: 1px solid var(--border);
    padding: 0; height: 28px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
    box-sizing: border-box;
  }
  thead th {
    position: sticky; top: 0; z-index: 3;
    background: var(--bg-elev); color: var(--text-faint);
    font-weight: 600; font-size: 11px; text-align: center; user-select: none;
  }
  thead th .resize {
    position: absolute; top: 0; right: 0; width: 6px; height: 100%;
    cursor: col-resize;
  }
  thead th { position: sticky; }
  thead th:hover .resize { background: color-mix(in srgb, var(--accent) 40%, transparent); }
  .rowhead {
    position: sticky; left: 0; z-index: 2;
    background: var(--bg-elev); color: var(--text-faint);
    font-weight: 500; font-size: 11px; text-align: center; user-select: none;
  }
  th.corner { position: sticky; left: 0; top: 0; z-index: 4; background: var(--bg-elev); }
  th.active { background: color-mix(in srgb, var(--accent) 16%, var(--bg-elev)); color: var(--text); }
  td { padding: 0 6px; color: var(--text); background: var(--bg); }
  td.frozen { position: sticky; top: 28px; z-index: 2; }
  td.num { text-align: right; font-variant-numeric: tabular-nums; }
  td.sel { background: color-mix(in srgb, var(--accent) 9%, var(--bg)); }
  td.active { outline: 2px solid var(--accent); outline-offset: -2px; }
  td.bold { font-weight: 700; }
  td.italic { font-style: italic; }
  td.underline { text-decoration: underline; }
  td.strike { text-decoration: line-through; }
  td.wrap { white-space: normal; }
  .v { display: block; overflow: hidden; text-overflow: ellipsis; }
  .cell-input {
    width: 100%; height: 100%; box-sizing: border-box;
    border: none; outline: none; background: transparent;
    font: inherit; color: var(--text); padding: 0 5px;
  }
  .foot {
    padding: 6px 16px; border-top: 1px solid var(--border); font-size: 11px;
    display: flex; align-items: center; gap: 14px; background: var(--bg-elev);
  }
  .stat { color: var(--text-soft); }
  .funcs { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 46%; }
  .placeholder { height: 100%; }
</style>
