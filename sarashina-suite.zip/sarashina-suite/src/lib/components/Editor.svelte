<script lang="ts">
  import { api } from "../api";
  import { t } from "../i18n.svelte";
  import { htmlToPlainText, sanitizeHtml } from "../format";
  import {
    escapeAttr,
    fileToDataUri,
    IMAGE_ACCEPT,
    MAX_IMAGE_BYTES,
    MAX_VIDEO_BYTES,
    normalizeUrl,
    openExternal,
    VIDEO_ACCEPT,
  } from "../media";
  import type { Doc } from "../types";

  let {
    doc,
    onSaved,
  }: { doc: Doc | null; onSaved?: (updatedAt: number, title: string) => void } = $props();

  let editorEl = $state<HTMLDivElement>();
  let loadedId = $state<string | null>(null);
  let titleInput = $state("");
  let charCount = $state(0);
  let status = $state<"idle" | "dirty" | "saving" | "saved">("idle");
  let savedAt = $state(0);
  let pending = $state<{ id: string; title: string; content: string; plain: string } | null>(null);
  let saveTimer: ReturnType<typeof setTimeout> | undefined;

  // --- 挿入（画像 / 動画 / リンク） -----------------------------------------
  let imageInput = $state<HTMLInputElement>();
  let videoInput = $state<HTMLInputElement>();
  let linkOpen = $state(false);
  let linkText = $state("");
  let linkUrl = $state("");
  let note = $state<string | null>(null);
  let noteTimer: ReturnType<typeof setTimeout> | undefined;

  const AUTOSAVE_MS = 800;

  // ドキュメントが切り替わったら、未保存分をフラッシュしてから DOM を差し替える
  $effect(() => {
    const current = doc;
    if (!current) return;
    if (current.id === loadedId) return;

    if (pending) void flush();

    loadedId = current.id;
    titleInput = current.title;
    charCount = current.plainText.length;
    status = "idle";
    if (editorEl) {
      editorEl.innerHTML = current.content;
    }
  });

  function handleInput() {
    if (!editorEl || !loadedId) return;
    const html = sanitizeHtml(editorEl.innerHTML);
    const plain = htmlToPlainText(html);
    charCount = plain.length;
    pending = { id: loadedId, title: titleInput, content: html, plain };
    status = "dirty";
    clearTimeout(saveTimer);
    saveTimer = setTimeout(() => void flush(), AUTOSAVE_MS);
  }

  function handleTitleInput() {
    handleInput();
  }

  async function flush() {
    const payload = pending;
    if (!payload) return;
    pending = null;
    status = "saving";
    try {
      const ts = await api.saveDocument(payload.id, payload.title, payload.content, payload.plain);
      savedAt = ts;
      status = "saved";
      onSaved?.(ts, payload.title);
    } catch (e) {
      console.error("保存に失敗しました", e);
      pending = payload;
      status = "dirty";
    }
  }

  function exec(command: string, value?: string) {
    editorEl?.focus();
    document.execCommand(command, false, value);
    handleInput();
  }

  /** HTML をキャレット位置に差し込む（execCommand なので Ctrl+Z で戻せる） */
  function insertHtml(html: string) {
    if (!editorEl) return;
    editorEl.focus();
    const ok = document.execCommand("insertHTML", false, html);
    if (!ok) editorEl.insertAdjacentHTML("beforeend", html);
    handleInput();
  }

  function showNote(message: string) {
    note = message;
    clearTimeout(noteTimer);
    noteTimer = setTimeout(() => (note = null), 5000);
  }

  async function onImagePicked(event: Event) {
    const input = event.currentTarget as HTMLInputElement;
    const file = input.files?.[0];
    input.value = "";
    if (!file) return;
    if (file.size > MAX_IMAGE_BYTES) {
      showNote(t("ins.tooLarge", { size: Math.round(MAX_IMAGE_BYTES / 1024 / 1024) }));
      return;
    }
    try {
      const uri = await fileToDataUri(file);
      insertHtml(
        `<img src="${uri}" alt="${escapeAttr(file.name)}" style="max-width:100%;height:auto">` +
          `<p><br></p>`,
      );
    } catch (e) {
      console.error(e);
      showNote(t("ins.failed"));
    }
  }

  async function onVideoPicked(event: Event) {
    const input = event.currentTarget as HTMLInputElement;
    const file = input.files?.[0];
    input.value = "";
    if (!file) return;
    if (file.size > MAX_VIDEO_BYTES) {
      showNote(t("ins.tooLarge", { size: Math.round(MAX_VIDEO_BYTES / 1024 / 1024) }));
      return;
    }
    try {
      const uri = await fileToDataUri(file);
      insertHtml(
        `<video controls src="${uri}" style="max-width:100%" aria-label="${escapeAttr(file.name)}"></video>` +
          `<p><br></p>`,
      );
    } catch (e) {
      console.error(e);
      showNote(t("ins.failed"));
    }
  }

  function openLinkPanel() {
    const selected = (window.getSelection()?.toString() ?? "").trim();
    linkText = selected;
    linkUrl = "";
    linkOpen = true;
  }

  function insertLink() {
    const url = normalizeUrl(linkUrl);
    if (!url) {
      showNote(t("ins.badUrl"));
      return;
    }
    const label = linkText.trim() || url;
    insertHtml(
      `<a href="${escapeAttr(url)}" target="_blank" rel="noopener">${escapeAttr(label)}</a>`,
    );
    linkOpen = false;
    linkText = "";
    linkUrl = "";
  }

  /** Ctrl / ⌘ + クリックでリンクを既定ブラウザで開く（編集中の誤遷移を防ぐ） */
  function onEditorClick(event: MouseEvent) {
    if (!event.metaKey && !event.ctrlKey) return;
    const target = event.target as HTMLElement | null;
    const anchor = target?.closest?.("a[href]") as HTMLAnchorElement | null;
    if (!anchor) return;
    event.preventDefault();
    void openExternal(anchor.getAttribute("href") ?? "");
  }

  function onKeydown(event: KeyboardEvent) {
    if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "s") {
      event.preventDefault();
      void flush();
    }
    if (event.key === "Escape" && linkOpen) {
      linkOpen = false;
    }
  }

  const statusLabel = $derived(
    status === "saving"
      ? t("editor.saving")
      : status === "dirty"
        ? t("editor.dirty")
        : savedAt
          ? t("editor.saved", { time: new Date(savedAt).toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" }) })
          : "",
  );
</script>

<svelte:window onkeydown={onKeydown} />

{#if !doc}
  <div class="placeholder center">
    <p class="faint">{t("editor.noDoc")}</p>
  </div>
{:else}
  <div class="editor-shell">
    <div class="toolbar">
      <div class="group">
        <button class="ghost sm" title={t("editor.bold")} onclick={() => exec("bold")}><b>B</b></button>
        <button class="ghost sm" title={t("editor.italic")} onclick={() => exec("italic")}><i>I</i></button>
        <button class="ghost sm" title={t("editor.underline")} onclick={() => exec("underline")}><u>U</u></button>
        <button class="ghost sm" title={t("editor.strike")} onclick={() => exec("strikeThrough")}><s>S</s></button>
      </div>
      <div class="divider"></div>
      <div class="group">
        <button class="ghost sm" title={t("editor.h2")} onclick={() => exec("formatBlock", "<h2>")}>H2</button>
        <button class="ghost sm" title={t("editor.h3")} onclick={() => exec("formatBlock", "<h3>")}>H3</button>
        <button class="ghost sm" title={t("kind.doc")} onclick={() => exec("formatBlock", "<p>")}>¶</button>
      </div>
      <div class="divider"></div>
      <div class="group">
        <button class="ghost sm" title={t("editor.bullet")} onclick={() => exec("insertUnorderedList")}>• {t("editor.list")}</button>
        <button class="ghost sm" title={t("editor.ordered")} onclick={() => exec("insertOrderedList")}>1. {t("editor.list")}</button>
        <button class="ghost sm" title={t("editor.quote")} onclick={() => exec("formatBlock", "<blockquote>")}>❝</button>
      </div>
      <div class="divider"></div>
      <div class="group">
        <button class="ghost sm" title={t("ins.image")} onclick={() => imageInput?.click()}>
          <svg viewBox="0 0 16 16" aria-hidden="true"><rect x="1.5" y="2.5" width="13" height="11" rx="1.5" /><circle cx="5.5" cy="6.5" r="1.2" /><path d="M2.5 12l3.5-3.5 2.5 2.5 2-2 3 3" /></svg>
          <span class="lbl">{t("ins.image")}</span>
        </button>
        <button class="ghost sm" title={t("ins.video")} onclick={() => videoInput?.click()}>
          <svg viewBox="0 0 16 16" aria-hidden="true"><rect x="1.5" y="3.5" width="9" height="9" rx="1.5" /><path d="M10.5 7l4-2.5v7l-4-2.5z" /></svg>
          <span class="lbl">{t("ins.video")}</span>
        </button>
        <button class="ghost sm" class:on={linkOpen} title={t("ins.link")} onclick={openLinkPanel}>
          <svg viewBox="0 0 16 16" aria-hidden="true"><path d="M6.5 9.5l3-3" /><path d="M6 4.5l1-1a2.5 2.5 0 013.5 3.5l-1 1" /><path d="M10 11.5l-1 1A2.5 2.5 0 015.5 9l1-1" /></svg>
          <span class="lbl">{t("ins.link")}</span>
        </button>
      </div>
      <div class="spacer"></div>
      {#if note}
        <span class="note">{note}</span>
      {/if}
      <span class="status mono" class:dirty={status === "dirty" || status === "saving"}>{statusLabel}</span>
      <input
        class="file"
        type="file"
        accept={IMAGE_ACCEPT}
        bind:this={imageInput}
        onchange={onImagePicked}
        aria-label={t("ins.image")}
        tabindex="-1"
      />
      <input
        class="file"
        type="file"
        accept={VIDEO_ACCEPT}
        bind:this={videoInput}
        onchange={onVideoPicked}
        aria-label={t("ins.video")}
        tabindex="-1"
      />
    </div>

    {#if linkOpen}
      <div class="linkpanel">
        <label class="field">
          <span>{t("ins.linkText")}</span>
          <input class="inp" bind:value={linkText} aria-label={t("ins.linkText")} />
        </label>
        <label class="field grow">
          <span>{t("ins.linkUrl")}</span>
          <input class="inp" bind:value={linkUrl} aria-label={t("ins.linkUrl")} inputmode="url" />
        </label>
        <button class="primary sm" onclick={insertLink}>{t("ins.insert")}</button>
        <button class="ghost sm" onclick={() => (linkOpen = false)}>{t("ins.cancel")}</button>
      </div>
    {/if}

    <div class="paper scroll">
      <input class="title" bind:value={titleInput} oninput={handleTitleInput} aria-label={t("kind.doc")} />
      <!-- contenteditable 自体が編集可能な入力なので、クリック/キー操作の警告は対象外 -->
      <!-- svelte-ignore a11y_click_events_have_key_events a11y_no_static_element_interactions -->
      <div
        class="content"
        contenteditable="true"
        bind:this={editorEl}
        oninput={handleInput}
        onblur={() => void flush()}
        onclick={onEditorClick}
        role="textbox"
        tabindex="0"
        aria-multiline="true"
        aria-label={t("kind.doc")}
      ></div>
    </div>

    <div class="footer mono">
      <span class="hint">{t("ins.linkHint")}</span>
      <span class="spacer"></span>
      <span>{t("editor.chars", { n: charCount.toLocaleString() })}</span>
    </div>
  </div>
{/if}

<style>
  .placeholder { height: 100%; color: var(--text-faint); }
  .editor-shell {
    display: flex; flex-direction: column; height: 100%; min-height: 0; min-width: 0;
    background: var(--bg);
  }
  .paper { overscroll-behavior: contain; }
  .toolbar {
    display: flex; align-items: center; gap: 6px;
    padding: 8px 14px; border-bottom: 1px solid var(--border);
    background: var(--bg-elev); flex: none;
    /* 幅が足りないときにボタンが縮んで位置がずれないように固定する
       （状態テキストの文字数変化でレイアウトが動くと、クリック位置も動いてしまう） */
    flex-wrap: nowrap; overflow: hidden;
  }
  .toolbar > *, .group, .divider { flex: none; }
  .group { display: flex; gap: 2px; }
  .spacer { flex: 1 1 auto; min-width: 0; }
  .status { flex: none; }
  @media (max-width: 1100px) {
    .lbl { display: none; }
  }
  .divider { width: 1px; height: 18px; background: var(--border); margin: 0 4px; }
  .status { font-size: 11.5px; color: var(--text-faint); }
  .status.dirty { color: var(--warn); }
  .note { font-size: 11.5px; color: var(--warn); max-width: 320px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .file { position: absolute; width: 1px; height: 1px; opacity: 0; pointer-events: none; }
  .lbl { margin-left: 3px; }
  .toolbar button svg { width: 14px; height: 14px; stroke: currentColor; stroke-width: 1.3; fill: none; }
  .toolbar button.on { background: var(--accent-soft); border-color: color-mix(in srgb, var(--accent) 35%, var(--border)); }
  .linkpanel {
    display: flex; align-items: flex-end; gap: 8px; padding: 8px 14px;
    border-bottom: 1px solid var(--border); background: var(--bg-sunken); flex: none;
    flex-wrap: wrap;
  }
  .field { display: flex; flex-direction: column; gap: 3px; font-size: 11px; color: var(--text-soft); }
  .field.grow { flex: 1; min-width: 180px; }
  .inp { font: inherit; font-size: 12.5px; padding: 5px 8px; border-radius: 8px; border: 1px solid var(--border); background: var(--bg); color: var(--text); }
  .paper {
    flex: 1; overflow-y: auto; padding: 40px 24px 80px;
    display: flex; flex-direction: column; align-items: center;
  }
  .title {
    width: min(720px, 100%);
    font-size: 26px; font-weight: 700; letter-spacing: -0.01em;
    border: none; background: transparent; padding: 0 0 10px;
    border-bottom: 1px solid transparent;
  }
  .title:focus { box-shadow: none; border-bottom-color: var(--border); }
  .content {
    width: min(720px, 100%);
    min-height: 60vh;
    margin-top: 18px;
    font-size: 15px;
    line-height: 1.9;
    outline: none;
  }
  .content :global(h1) { font-size: 24px; margin: 1.4em 0 0.5em; }
  .content :global(h2) { font-size: 19px; margin: 1.3em 0 0.45em; }
  .content :global(h3) { font-size: 16px; margin: 1.2em 0 0.4em; }
  .content :global(p) { margin: 0.7em 0; }
  .content :global(ul), .content :global(ol) { padding-left: 1.4em; margin: 0.6em 0; }
  .content :global(blockquote) {
    border-left: 3px solid var(--border-strong); margin: 0.8em 0;
    padding: 0.1em 0 0.1em 1em; color: var(--text-soft);
  }
  .content :global(a) { color: var(--accent); text-underline-offset: 2px; }
  .content :global(img) { max-width: 100%; height: auto; border-radius: 8px; margin: 0.4em 0; }
  .content :global(video) { max-width: 100%; border-radius: 8px; margin: 0.4em 0; background: #000; }
  .content :global(code) {
    font-family: var(--mono); font-size: 0.88em;
    background: var(--bg-sunken); padding: 0.1em 0.35em; border-radius: 4px;
  }
  .footer {
    padding: 6px 16px; border-top: 1px solid var(--border);
    font-size: 11px; color: var(--text-faint); background: var(--bg-elev);
    display: flex; align-items: center; gap: 8px; flex: none;
  }
  .hint { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
</style>
