<script lang="ts">
  // 文書エディタ（v2）
  //  ・ページ表示（A4 / レター、余白、ズーム）と印刷
  //  ・段落スタイル（タイトル / 見出し / 引用 / コード …）、フォント、色、配置、行間
  //  ・表の挿入と行/列の増減、検索と置換、アウトライン、文字数・読了時間
  //  ・保存形式は HTML（contenteditable）。ページ設定は先頭の HTML コメントに埋め込む
  import { api } from "../api";
  import { t } from "../i18n.svelte";
  import { htmlToPlainText, sanitizeHtml } from "../format";
  import {
    escapeAttr, fileToDataUri, IMAGE_ACCEPT, MAX_IMAGE_BYTES, MAX_VIDEO_BYTES,
    normalizeUrl, openExternal, VIDEO_ACCEPT,
  } from "../media";
  import {
    applyParagraphStyle, clearFormatting, clearPaintedHits, currentParagraphStyle,
    documentOutline, findMatches, insertPageBreakHtml, insertRuleHtml, paintHits,
    replaceAll, replaceHit, setFontFamily, setFontSize, setHighlight,
    setTextColor, tableAction, tableHtml, textStats, type OutlineItem, type ParaStyle,
    type TextHit,
  } from "../richtext";
  import type { Doc } from "../types";

  let {
    doc,
    onSaved,
  }: { doc: Doc | null; onSaved?: (updatedAt: number, title: string) => void } = $props();

  const AUTOSAVE_MS = 800;

  interface PageSetup {
    size: "A4" | "Letter";
    margin: number; // mm
    landscape: boolean;
  }

  const PAGE_MM: Record<"A4" | "Letter", { w: number; h: number }> = {
    A4: { w: 210, h: 297 },
    Letter: { w: 215.9, h: 279.4 },
  };
  const MM_TO_PX = 96 / 25.4;

  const FONTS = [
    { value: "", label: "既定" },
    { value: "var(--sans)", label: "ゴシック体" },
    { value: '"Hiragino Mincho ProN", "Yu Mincho", "Noto Serif JP", serif', label: "明朝体" },
    { value: "var(--mono)", label: "等幅" },
  ];
  const SIZES = [8, 9, 10, 10.5, 11, 12, 14, 16, 18, 20, 24, 28, 36, 48];

  let editorEl = $state<HTMLDivElement>();
  let loadedId = $state<string | null>(null);
  let titleInput = $state("");
  let page = $state<PageSetup>({ size: "A4", margin: 25, landscape: false });
  let zoom = $state(1);
  let status = $state<"idle" | "dirty" | "saving" | "saved">("idle");
  let savedAt = $state(0);
  let pending = $state<{ id: string; title: string; content: string; plain: string } | null>(null);
  let saveTimer: ReturnType<typeof setTimeout> | undefined;

  let blockStyle = $state<ParaStyle>("body");
  let activeFont = $state("");
  let activeSize = $state(11);
  let stats = $state({ chars: 0, charsNoSpace: 0, words: 0, paragraphs: 0, minutes: 1 });
  let pageCount = $state(1);

  // 挿入
  let imageInput = $state<HTMLInputElement>();
  let videoInput = $state<HTMLInputElement>();
  let linkOpen = $state(false);
  let linkText = $state("");
  let linkUrl = $state("");
  let tableOpen = $state(false);
  let tableRows = $state(3);
  let tableCols = $state(3);
  let tableHeader = $state(true);
  let note = $state<string | null>(null);
  let noteTimer: ReturnType<typeof setTimeout> | undefined;

  // 検索・置換
  let findOpen = $state(false);
  let findQuery = $state("");
  let replaceWith = $state("");
  let hits = $state<TextHit[]>([]);
  let hitIndex = $state(0);
  let caseSensitive = $state(false);

  // アウトライン
  let outlineOpen = $state(false);
  let outline = $state<OutlineItem[]>([]);

  const pageBox = $derived.by(() => {
    const dim = PAGE_MM[page.size];
    const w = (page.landscape ? dim.h : dim.w) * MM_TO_PX;
    const h = (page.landscape ? dim.w : dim.h) * MM_TO_PX;
    return { w: Math.round(w), h: Math.round(h), pad: Math.round(page.margin * MM_TO_PX) };
  });

  // ── 読み込み・保存 ───────────────────────────────────────────────────────
  const PAGE_COMMENT = /^\s*<!--poccham-page:(.*?)-->/s;

  function splitPage(content: string): { body: string; setup: PageSetup | null } {
    const m = PAGE_COMMENT.exec(content ?? "");
    if (!m) return { body: content ?? "", setup: null };
    try {
      const parsed = JSON.parse(m[1]) as Partial<PageSetup>;
      return {
        body: content.replace(PAGE_COMMENT, ""),
        setup: {
          size: parsed.size === "Letter" ? "Letter" : "A4",
          margin: typeof parsed.margin === "number" ? parsed.margin : 25,
          landscape: Boolean(parsed.landscape),
        },
      };
    } catch {
      return { body: content.replace(PAGE_COMMENT, ""), setup: null };
    }
  }

  $effect(() => {
    const current = doc;
    if (!current || current.id === loadedId) return;
    if (pending) void flush();
    const { body, setup } = splitPage(current.content);
    loadedId = current.id;
    titleInput = current.title;
    if (setup) page = setup;
    status = "idle";
    if (editorEl) {
      editorEl.innerHTML = body || "<p><br></p>";
      refreshStats();
    }
  });

  function refreshStats() {
    if (!editorEl) return;
    const text = htmlToPlainText(editorEl.innerHTML);
    stats = textStats(text);
    const contentHeight = Math.max(1, pageBox.h - pageBox.pad * 2);
    pageCount = Math.max(1, Math.ceil((editorEl.scrollHeight + 24) / contentHeight));
    if (outlineOpen) outline = documentOutline(editorEl);
  }

  function handleInput() {
    if (!editorEl || !loadedId) return;
    const html = sanitizeHtml(editorEl.innerHTML);
    const plain = htmlToPlainText(html);
    refreshStats();
    pending = { id: loadedId, title: titleInput, content: pageComment() + html, plain };
    status = "dirty";
    clearTimeout(saveTimer);
    saveTimer = setTimeout(() => void flush(), AUTOSAVE_MS);
  }

  function pageComment(): string {
    return `<!--poccham-page:${JSON.stringify(page)}-->`;
  }

  async function flush() {
    const payload = pending;
    if (!payload) return;
    pending = null;
    status = "saving";
    try {
      const ts = await api.saveDocument(payload.id, payload.title, payload.content, payload.plain);
      savedAt = ts;
      status = "saved";
      onSaved?.(ts, payload.title);
    } catch (e) {
      console.error("保存に失敗しました", e);
      pending = payload;
      status = "dirty";
    }
  }

  // ── 書式 ─────────────────────────────────────────────────────────────────
  function exec(command: string, value?: string) {
    editorEl?.focus();
    document.execCommand("styleWithCSS", false, "true");
    document.execCommand(command, false, value);
    syncToolbar();
    handleInput();
  }

  function applyStyle(style: ParaStyle) {
    if (!editorEl) return;
    editorEl.focus();
    applyParagraphStyle(editorEl, style);
    blockStyle = style;
    handleInput();
  }

  function applySize(px: number) {
    editorEl?.focus();
    setFontSize(px);
    activeSize = px;
    handleInput();
  }

  function applyFont(family: string) {
    editorEl?.focus();
    setFontFamily(family);
    activeFont = family;
    handleInput();
  }

  function insertHtml(html: string) {
    if (!editorEl) return;
    editorEl.focus();
    const ok = document.execCommand("insertHTML", false, html);
    if (!ok) editorEl.insertAdjacentHTML("beforeend", html);
    handleInput();
  }

  function insertTableNow() {
    insertHtml(tableHtml(tableRows, tableCols, tableHeader));
    tableOpen = false;
  }

  function doTableAction(action: Parameters<typeof tableAction>[0]) {
    if (tableAction(action)) handleInput();
    else showNote(t("editor.noTable"));
  }

  function syncToolbar() {
    if (!editorEl) return;
    blockStyle = currentParagraphStyle(editorEl);
  }

  function onSelectionChange() {
    if (!editorEl) return;
    const sel = window.getSelection();
    if (!sel || sel.rangeCount === 0) return;
    if (!editorEl.contains(sel.getRangeAt(0).startContainer)) return;
    syncToolbar();
  }

  // ── ページ設定 ───────────────────────────────────────────────────────────
  function applyPage(next: Partial<PageSetup>) {
    page = { ...page, ...next };
    refreshStats();
    handleInput();
  }

  // ── 検索・置換 ───────────────────────────────────────────────────────────
  function runFind(reset = true) {
    if (!editorEl) return;
    clearPaintedHits(editorEl);
    hits = findQuery ? findMatches(editorEl, findQuery, caseSensitive) : [];
    paintHits(hits);
    if (reset) hitIndex = 0;
    if (hits.length) scrollToHit(0);
  }

  function scrollToHit(index: number) {
    const hit = hits[index];
    if (!hit) return;
    hitIndex = index;
    const el = hit.range.startContainer.parentElement;
    el?.scrollIntoView({ block: "center", behavior: "smooth" });
  }

  function nextHit(delta: number) {
    if (!hits.length) return;
    const next = (hitIndex + delta + hits.length) % hits.length;
    scrollToHit(next);
  }

  function replaceCurrent() {
    const hit = hits[hitIndex];
    if (!hit || !editorEl) return;
    clearPaintedHits(editorEl);
    replaceHit(hit, replaceWith);
    handleInput();
    runFind(false);
  }

  function replaceEverything() {
    if (!editorEl || !findQuery) return;
    clearPaintedHits(editorEl);
    const count = replaceAll(editorEl, findQuery, replaceWith, caseSensitive);
    handleInput();
    hits = [];
    hitIndex = 0;
    showNote(t("editor.replaced", { n: count }));
  }

  // ── 挿入 ─────────────────────────────────────────────────────────────────
  function showNote(message: string) {
    note = message;
    clearTimeout(noteTimer);
    noteTimer = setTimeout(() => (note = null), 5000);
  }

  async function onImagePicked(event: Event) {
    const input = event.currentTarget as HTMLInputElement;
    const file = input.files?.[0];
    input.value = "";
    if (!file) return;
    if (file.size > MAX_IMAGE_BYTES) {
      showNote(t("ins.tooLarge", { size: Math.round(MAX_IMAGE_BYTES / 1024 / 1024) }));
      return;
    }
    try {
      const uri = await fileToDataUri(file);
      insertHtml(`<img src="${uri}" alt="${escapeAttr(file.name)}" style="max-width:100%;height:auto"><p><br></p>`);
    } catch (e) {
      console.error(e);
      showNote(t("ins.failed"));
    }
  }

  async function onVideoPicked(event: Event) {
    const input = event.currentTarget as HTMLInputElement;
    const file = input.files?.[0];
    input.value = "";
    if (!file) return;
    if (file.size > MAX_VIDEO_BYTES) {
      showNote(t("ins.tooLarge", { size: Math.round(MAX_VIDEO_BYTES / 1024 / 1024) }));
      return;
    }
    try {
      const uri = await fileToDataUri(file);
      insertHtml(`<video controls src="${uri}" style="max-width:100%" aria-label="${escapeAttr(file.name)}"></video><p><br></p>`);
    } catch (e) {
      console.error(e);
      showNote(t("ins.failed"));
    }
  }

  function openLinkPanel() {
    const selected = (window.getSelection()?.toString() ?? "").trim();
    linkText = selected;
    linkUrl = "";
    linkOpen = true;
  }

  function insertLink() {
    const url = normalizeUrl(linkUrl);
    if (!url) {
      showNote(t("ins.badUrl"));
      return;
    }
    const label = linkText.trim() || url;
    insertHtml(`<a href="${escapeAttr(url)}" target="_blank" rel="noopener">${escapeAttr(label)}</a>`);
    linkOpen = false;
    linkText = "";
    linkUrl = "";
  }

  function onEditorClick(event: MouseEvent) {
    if (!event.metaKey && !event.ctrlKey) return;
    const target = event.target as HTMLElement | null;
    const anchor = target?.closest?.("a[href]") as HTMLAnchorElement | null;
    if (!anchor) return;
    event.preventDefault();
    void openExternal(anchor.getAttribute("href") ?? "");
  }

  function onKeydown(event: KeyboardEvent) {
    const meta = event.metaKey || event.ctrlKey;
    if (meta && event.key.toLowerCase() === "s") {
      event.preventDefault();
      void flush();
    }
    if (meta && event.key.toLowerCase() === "f") {
      event.preventDefault();
      findOpen = true;
    }
    if (meta && event.key.toLowerCase() === "b") { event.preventDefault(); exec("bold"); }
    if (meta && event.key.toLowerCase() === "i") { event.preventDefault(); exec("italic"); }
    if (meta && event.key.toLowerCase() === "u") { event.preventDefault(); exec("underline"); }
    if (meta && event.key.toLowerCase() === "p") { event.preventDefault(); printDoc(); }
    if (event.key === "Escape") {
      if (linkOpen) linkOpen = false;
      if (tableOpen) tableOpen = false;
    }
  }

  function printDoc() {
    void flush();
    window.print();
  }

  const statusLabel = $derived(
    status === "saving"
      ? t("editor.saving")
      : status === "dirty"
        ? t("editor.dirty")
        : savedAt
          ? t("editor.saved", { time: new Date(savedAt).toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" }) })
          : "",
  );

  const alignOf = (cmd: string) => {
    try {
      return document.queryCommandState(cmd);
    } catch {
      return false;
    }
  };
</script>

<svelte:window onkeydown={onKeydown} />
<svelte:document onselectionchange={onSelectionChange} />

{#if !doc}
  <div class="placeholder center">
    <p class="faint">{t("editor.noDoc")}</p>
  </div>
{:else}
  <div class="editor-shell">
    <div class="toolbar">
      <div class="group">
        <button class="ghost sm" title={t("undo")} onclick={() => exec("undo")}>↶</button>
        <button class="ghost sm" title={t("redo")} onclick={() => exec("redo")}>↷</button>
        <button class="ghost sm" title={t("editor.print")} onclick={printDoc}>⎙</button>
      </div>
      <div class="divider"></div>
      <label class="pick">
        <select
          aria-label={t("editor.style")}
          title={t("editor.style")}
          value={blockStyle}
          onchange={(e) => applyStyle((e.currentTarget as HTMLSelectElement).value as ParaStyle)}
        >
          {#each ["title", "subtitle", "h1", "h2", "h3", "body", "quote", "code", "caption"] as s (s)}
            <option value={s}>{t(`ps.${s}`)}</option>
          {/each}
        </select>
      </label>
      <label class="pick">
        <select
          aria-label={t("editor.font")}
          title={t("editor.font")}
          value={activeFont}
          onchange={(e) => applyFont((e.currentTarget as HTMLSelectElement).value)}
        >
          {#each FONTS as f (f.value)}
            <option value={f.value}>{f.label === "既定" ? t("editor.fontDefault") : f.label === "ゴシック体" ? t("editor.fontSans") : f.label === "明朝体" ? t("editor.fontSerif") : t("editor.fontMono")}</option>
          {/each}
        </select>
      </label>
      <label class="pick narrow">
        <select
          aria-label={t("editor.fontSize")}
          title={t("editor.fontSize")}
          value={String(activeSize)}
          onchange={(e) => applySize(Number((e.currentTarget as HTMLSelectElement).value))}
        >
          {#each SIZES as s (s)}
            <option value={String(s)}>{s}</option>
          {/each}
        </select>
      </label>
      <div class="divider"></div>
      <div class="group">
        <button class="ghost sm" title={t("editor.bold")} onclick={() => exec("bold")}><b>B</b></button>
        <button class="ghost sm" title={t("editor.italic")} onclick={() => exec("italic")}><i>I</i></button>
        <button class="ghost sm" title={t("editor.underline")} onclick={() => exec("underline")}><u>U</u></button>
        <button class="ghost sm" title={t("editor.strike")} onclick={() => exec("strikeThrough")}><s>S</s></button>
        <button class="ghost sm" title={t("editor.super")} onclick={() => exec("superscript")}>x²</button>
        <button class="ghost sm" title={t("editor.sub")} onclick={() => exec("subscript")}>x₂</button>
        <button class="ghost sm" title={t("editor.clear")} onclick={() => { clearFormatting(); handleInput(); }}>⌫</button>
      </div>
      <div class="divider"></div>
      <label class="pick color" title={t("editor.textColor")}>
        <span class="chip">A</span>
        <input type="color" aria-label={t("editor.textColor")} value="#1f2328" oninput={(e) => { setTextColor((e.currentTarget as HTMLInputElement).value); blockStyle = blockStyle; }} />
      </label>
      <label class="pick color" title={t("editor.highlight")}>
        <span class="chip hl">▨</span>
        <input type="color" aria-label={t("editor.highlight")} value="#ffe37d" oninput={(e) => { setHighlight((e.currentTarget as HTMLInputElement).value); }} />
      </label>
      <div class="divider"></div>
      <div class="group">
        <button class="ghost sm" class:on={alignOf("justifyLeft")} title={t("al.left")} onclick={() => exec("justifyLeft")}>⇤</button>
        <button class="ghost sm" class:on={alignOf("justifyCenter")} title={t("al.center2")} onclick={() => exec("justifyCenter")}>↔</button>
        <button class="ghost sm" class:on={alignOf("justifyRight")} title={t("al.right")} onclick={() => exec("justifyRight")}>⇥</button>
        <button class="ghost sm" class:on={alignOf("justifyFull")} title={t("editor.justify")} onclick={() => exec("justifyFull")}>☰</button>
      </div>
      <div class="divider"></div>
      <div class="group">
        <button class="ghost sm" title={t("al.bullet")} onclick={() => exec("insertUnorderedList")}>•</button>
        <button class="ghost sm" title={t("al.number")} onclick={() => exec("insertOrderedList")}>1.</button>
        <button class="ghost sm" title={t("al.outdent")} onclick={() => exec("outdent")}>⇤⇤</button>
        <button class="ghost sm" title={t("al.indent")} onclick={() => exec("indent")}>⇥⇥</button>
      </div>
      <div class="divider"></div>
      <div class="group">
        <button class="ghost sm" title={t("ins.image")} onclick={() => imageInput?.click()}>🖼</button>
        <button class="ghost sm" title={t("ins.video")} onclick={() => videoInput?.click()}>▶</button>
        <button class="ghost sm" class:on={linkOpen} title={t("ins.link")} onclick={openLinkPanel}>🔗</button>
        <button class="ghost sm" class:on={tableOpen} title={t("editor.table")} onclick={() => (tableOpen = !tableOpen)}>▦</button>
        <button class="ghost sm" title={t("editor.rule")} onclick={() => insertHtml(insertRuleHtml())}>—</button>
        <button class="ghost sm" title={t("editor.pageBreak")} onclick={() => insertHtml(insertPageBreakHtml())}>⤓</button>
      </div>
      <div class="divider"></div>
      <div class="group">
        <button class="ghost sm" class:on={findOpen} title={t("editor.find")} onclick={() => (findOpen = !findOpen)}>🔍</button>
        <button class="ghost sm" class:on={outlineOpen} title={t("editor.outline")} onclick={() => { outlineOpen = !outlineOpen; if (outlineOpen && editorEl) outline = documentOutline(editorEl); }}>☰</button>
      </div>
      <div class="spacer"></div>
      <input class="file" type="file" accept={IMAGE_ACCEPT} bind:this={imageInput} onchange={onImagePicked} aria-label={t("ins.image")} tabindex="-1" />
      <input class="file" type="file" accept={VIDEO_ACCEPT} bind:this={videoInput} onchange={onVideoPicked} aria-label={t("ins.video")} tabindex="-1" />
    </div>

    <div class="subbar">
      <span class="seg">
        <label class="pick narrow" title={t("editor.pageSize")}>
          <select aria-label={t("editor.pageSize")} value={page.size} onchange={(e) => applyPage({ size: (e.currentTarget as HTMLSelectElement).value as "A4" | "Letter" })}>
            <option value="A4">A4</option>
            <option value="Letter">Letter</option>
          </select>
        </label>
        <label class="pick narrow" title={t("editor.margin")}>
          <select aria-label={t("editor.margin")} value={String(page.margin)} onchange={(e) => applyPage({ margin: Number((e.currentTarget as HTMLSelectElement).value) })}>
            {#each [10, 15, 20, 25, 30, 40] as m (m)}
              <option value={String(m)}>{t("editor.marginValue", { mm: m })}</option>
            {/each}
          </select>
        </label>
        <button class="ghost sm" title={t("editor.landscape")} class:on={page.landscape} onclick={() => applyPage({ landscape: !page.landscape })}>⤢</button>
      </span>
      <span class="divider"></span>
      <span class="seg">
        <button class="ghost sm" title={t("zoom.out")} onclick={() => (zoom = Math.max(0.6, Math.round((zoom - 0.1) * 10) / 10))}>−</button>
        <button class="ghost sm zoomv mono" title={t("zoom.reset")} onclick={() => (zoom = 1)}>{Math.round(zoom * 100)}%</button>
        <button class="ghost sm" title={t("zoom.in")} onclick={() => (zoom = Math.min(2, Math.round((zoom + 0.1) * 10) / 10))}>＋</button>
      </span>
      <span class="divider"></span>
      <span class="seg tableops">
        <button class="ghost sm" title={t("editor.rowAdd")} onclick={() => doTableAction("rowAfter")}>＋行</button>
        <button class="ghost sm" title={t("editor.colAdd")} onclick={() => doTableAction("colAfter")}>＋列</button>
        <button class="ghost sm" title={t("editor.rowDel")} onclick={() => doTableAction("delRow")}>−行</button>
        <button class="ghost sm" title={t("editor.colDel")} onclick={() => doTableAction("delCol")}>−列</button>
        <button class="ghost sm" title={t("editor.headerToggle")} onclick={() => doTableAction("toggleHeader")}>{t("editor.headerRow")}</button>
      </span>
      <span class="spacer"></span>
      {#if note}<span class="note">{note}</span>{/if}
      <span class="status mono" class:dirty={status === "dirty" || status === "saving"}>{statusLabel}</span>
      <span class="faint stats mono">{t("editor.stats", { words: stats.words, pages: pageCount })}</span>
    </div>

    {#if tableOpen}
      <div class="panel tablepanel">
        <span class="plabel">{t("editor.table")}</span>
        <label class="field">
          <span>{t("editor.rows")}</span>
          <input class="inp narrow" type="number" min="1" max="20" bind:value={tableRows} aria-label={t("editor.rows")} />
        </label>
        <label class="field">
          <span>{t("editor.cols")}</span>
          <input class="inp narrow" type="number" min="1" max="10" bind:value={tableCols} aria-label={t("editor.cols")} />
        </label>
        <label class="check">
          <input type="checkbox" bind:checked={tableHeader} />
          <span>{t("editor.headerRow")}</span>
        </label>
        <button class="primary sm" onclick={insertTableNow}>{t("ins.insert")}</button>
        <button class="ghost sm" onclick={() => (tableOpen = false)}>{t("ins.cancel")}</button>
      </div>
    {/if}

    {#if linkOpen}
      <div class="panel linkpanel">
        <label class="field">
          <span>{t("ins.linkText")}</span>
          <input class="inp" bind:value={linkText} aria-label={t("ins.linkText")} />
        </label>
        <label class="field grow">
          <span>{t("ins.linkUrl")}</span>
          <input class="inp" bind:value={linkUrl} aria-label={t("ins.linkUrl")} inputmode="url" />
        </label>
        <button class="primary sm" onclick={insertLink}>{t("ins.insert")}</button>
        <button class="ghost sm" onclick={() => (linkOpen = false)}>{t("ins.cancel")}</button>
      </div>
    {/if}

    {#if findOpen}
      <div class="panel findpanel">
        <label class="field grow">
          <span>{t("editor.find")}</span>
          <input
            class="inp"
            bind:value={findQuery}
            oninput={() => runFind()}
            aria-label={t("editor.find")}
          />
        </label>
        <label class="field grow">
          <span>{t("editor.replace")}</span>
          <input class="inp" bind:value={replaceWith} aria-label={t("editor.replace")} />
        </label>
        <label class="check">
          <input type="checkbox" bind:checked={caseSensitive} onchange={() => runFind()} />
          <span>{t("editor.caseSensitive")}</span>
        </label>
        <span class="found mono">{findQuery ? `${hits.length ? hitIndex + 1 : 0}/${hits.length}` : ""}</span>
        <button class="ghost sm" title={t("editor.prev")} onclick={() => nextHit(-1)} disabled={!hits.length}>↑</button>
        <button class="ghost sm" title={t("editor.next")} onclick={() => nextHit(1)} disabled={!hits.length}>↓</button>
        <button class="primary sm" onclick={replaceCurrent} disabled={!hits.length}>{t("editor.replaceOne")}</button>
        <button class="ghost sm" onclick={replaceEverything} disabled={!findQuery}>{t("editor.replaceAll")}</button>
        <button class="ghost sm" onclick={() => { clearPaintedHits(editorEl!); hits = []; findOpen = false; }}>{t("close")}</button>
      </div>
    {/if}

    <div class="canvas" class:with-outline={outlineOpen}>
      {#if outlineOpen}
        <aside class="outline">
          <div class="outline-head">{t("editor.outline")}</div>
          {#if !outline.length}<p class="faint small">{t("editor.outlineEmpty")}</p>{/if}
          {#each outline as item, i (i)}
            <button
              class="outline-item l{item.level}"
              onclick={() => item.el.scrollIntoView({ block: "center", behavior: "smooth" })}
            >
              {item.text}
            </button>
          {/each}
        </aside>
      {/if}

      <div class="paper scroll">
        <div
          class="doc-page rt-content"
          style:width={`${pageBox.w}px`}
          style:min-height={`${pageBox.h}px`}
          style:padding={`${pageBox.pad}px`}
          style:zoom={zoom}
        >
          <input class="title" bind:value={titleInput} oninput={handleInput} aria-label={t("kind.doc")} />
          <!-- svelte-ignore a11y_click_events_have_key_events a11y_no_static_element_interactions -->
          <div
            class="content"
            contenteditable="true"
            bind:this={editorEl}
            oninput={handleInput}
            onblur={() => void flush()}
            onclick={onEditorClick}
            onkeyup={syncToolbar}
            onmouseup={syncToolbar}
            role="textbox"
            tabindex="0"
            aria-multiline="true"
            aria-label={t("kind.doc")}
          ></div>
        </div>
      </div>
    </div>

    <div class="footer mono">
      <span class="hint">{t("editor.footerHint")}</span>
      <span class="spacer"></span>
      <span>{t("editor.charStats", { chars: stats.chars.toLocaleString(), minutes: stats.minutes })}</span>
    </div>
  </div>
{/if}

<style>
  .placeholder { height: 100%; color: var(--text-faint); }
  .editor-shell { display: flex; flex-direction: column; height: 100%; min-height: 0; min-width: 0; background: var(--bg); }
  .toolbar, .subbar {
    display: flex; align-items: center; gap: 6px;
    padding: 7px 14px; border-bottom: 1px solid var(--border);
    background: var(--bg-elev); flex: none; flex-wrap: wrap; row-gap: 4px; overflow: visible;
  }
  .subbar { background: var(--bg-sunken); gap: 8px; padding: 5px 14px; }
  .toolbar > *, .group, .divider, .seg { flex: none; }
  .group, .seg { display: flex; gap: 2px; align-items: center; }
  .spacer { flex: 1 1 auto; min-width: 0; }
  .divider { width: 1px; height: 18px; background: var(--border); margin: 0 4px; }
  .status { font-size: 11.5px; color: var(--text-faint); }
  .status.dirty { color: var(--warn); }
  .stats { font-size: 11px; white-space: nowrap; }
  .note { font-size: 11.5px; color: var(--warn); max-width: 300px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .file { position: absolute; width: 1px; height: 1px; opacity: 0; pointer-events: none; }
  .toolbar button { font-size: 12px; }
  .toolbar button.on, .subbar button.on { background: var(--accent-soft); border-color: color-mix(in srgb, var(--accent) 35%, var(--border)); }
  .pick { display: flex; align-items: center; gap: 4px; flex: none; }
  .pick select {
    font: inherit; font-size: 12px; padding: 4px 6px; border-radius: 7px; max-width: 140px;
    border: 1px solid var(--border); background: var(--bg); color: var(--text);
  }
  .pick.narrow select { max-width: 76px; }
  .pick.color { position: relative; cursor: pointer; }
  .pick.color input { width: 22px; height: 22px; padding: 0; border: 1px solid var(--border); border-radius: 6px; background: none; }
  .chip { font-size: 12px; font-weight: 700; color: var(--text-soft); }
  .chip.hl { color: #b58b00; }
  .zoomv { min-width: 44px; }

  .panel {
    display: flex; align-items: flex-end; gap: 8px; padding: 8px 14px;
    border-bottom: 1px solid var(--border); background: var(--bg-elev); flex: none; flex-wrap: wrap;
  }
  .plabel { font-size: 11px; color: var(--text-soft); align-self: center; }
  .field { display: flex; flex-direction: column; gap: 3px; font-size: 11px; color: var(--text-soft); }
  .field.grow { flex: 1 1 180px; min-width: 140px; }
  .inp {
    font: inherit; font-size: 12.5px; padding: 5px 8px; border-radius: 8px;
    border: 1px solid var(--border); background: var(--bg); color: var(--text);
  }
  .inp.narrow { width: 64px; }
  .check { display: flex; align-items: center; gap: 5px; font-size: 11.5px; color: var(--text-soft); align-self: center; }
  .found { font-size: 11.5px; color: var(--text-faint); min-width: 42px; }

  .canvas { flex: 1; display: flex; min-height: 0; min-width: 0; }
  .outline {
    width: 220px; flex: none; border-right: 1px solid var(--border); background: var(--sidebar);
    overflow-y: auto; padding: 10px 8px; overscroll-behavior: contain;
  }
  .outline-head { font-size: 11px; font-weight: 700; color: var(--text-faint); letter-spacing: 0.04em; padding: 2px 6px 8px; }
  .outline-item {
    display: block; width: 100%; text-align: left; border: none; background: none;
    font-size: 12px; color: var(--text-soft); padding: 4px 6px; border-radius: 6px;
    white-space: nowrap; overflow: hidden; text-overflow: ellipsis; cursor: pointer;
  }
  .outline-item:hover { background: var(--bg-sunken); color: var(--text); }
  .outline-item.l0, .outline-item.l1 { font-weight: 650; color: var(--text); }
  .outline-item.l2 { padding-left: 16px; }
  .outline-item.l3 { padding-left: 28px; }
  .small { font-size: 12px; }

  .paper {
    flex: 1; overflow-y: auto; padding: 26px 24px 90px;
    display: flex; flex-direction: column; align-items: center;
    overscroll-behavior: contain; background: var(--bg-sunken);
  }
  .doc-page {
    background: var(--bg-elev);
    border: 1px solid var(--border);
    border-radius: 4px;
    box-shadow: var(--shadow-md);
    box-sizing: border-box;
    transform-origin: top center;
  }
  .title {
    width: 100%; font-size: 26px; font-weight: 700; letter-spacing: -0.01em;
    border: none; background: transparent; padding: 0 0 10px; color: var(--text);
    border-bottom: 1px solid transparent; display: block;
  }
  .title:focus { box-shadow: none; border-bottom-color: var(--border); }
  .content { min-height: 40vh; outline: none; margin-top: 14px; }
  .footer {
    padding: 6px 16px; border-top: 1px solid var(--border);
    font-size: 11px; color: var(--text-faint); background: var(--bg-elev);
    display: flex; align-items: center; gap: 8px; flex: none;
  }
  .hint { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
</style>
