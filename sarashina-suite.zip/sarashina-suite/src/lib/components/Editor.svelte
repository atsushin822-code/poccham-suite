<script lang="ts">
  import { api } from "../api";
  import { t } from "../i18n.svelte";
  import { htmlToPlainText, sanitizeHtml } from "../format";
  import type { Doc } from "../types";

  let {
    doc,
    onSaved,
  }: { doc: Doc | null; onSaved?: (updatedAt: number, title: string) => void } = $props();

  let editorEl = $state<HTMLDivElement>();
  let loadedId = $state<string | null>(null);
  let titleInput = $state("");
  let charCount = $state(0);
  let status = $state<"idle" | "dirty" | "saving" | "saved">("idle");
  let savedAt = $state(0);
  let pending = $state<{ id: string; title: string; content: string; plain: string } | null>(null);
  let saveTimer: ReturnType<typeof setTimeout> | undefined;

  const AUTOSAVE_MS = 800;

  // ドキュメントが切り替わったら、未保存分をフラッシュしてから DOM を差し替える
  $effect(() => {
    const current = doc;
    if (!current) return;
    if (current.id === loadedId) return;

    if (pending) void flush();

    loadedId = current.id;
    titleInput = current.title;
    charCount = current.plainText.length;
    status = "idle";
    if (editorEl) {
      editorEl.innerHTML = current.content;
    }
  });

  function handleInput() {
    if (!editorEl || !loadedId) return;
    const html = sanitizeHtml(editorEl.innerHTML);
    const plain = htmlToPlainText(html);
    charCount = plain.length;
    pending = { id: loadedId, title: titleInput, content: html, plain };
    status = "dirty";
    clearTimeout(saveTimer);
    saveTimer = setTimeout(() => void flush(), AUTOSAVE_MS);
  }

  function handleTitleInput() {
    handleInput();
  }

  async function flush() {
    const payload = pending;
    if (!payload) return;
    pending = null;
    status = "saving";
    try {
      const ts = await api.saveDocument(payload.id, payload.title, payload.content, payload.plain);
      savedAt = ts;
      status = "saved";
      onSaved?.(ts, payload.title);
    } catch (e) {
      console.error("保存に失敗しました", e);
      pending = payload;
      status = "dirty";
    }
  }

  function exec(command: string, value?: string) {
    editorEl?.focus();
    document.execCommand(command, false, value);
    handleInput();
  }

  function onKeydown(event: KeyboardEvent) {
    if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "s") {
      event.preventDefault();
      void flush();
    }
  }

  const statusLabel = $derived(
    status === "saving"
      ? t("editor.saving")
      : status === "dirty"
        ? t("editor.dirty")
        : savedAt
          ? t("editor.saved", { time: new Date(savedAt).toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" }) })
          : "",
  );
</script>

<svelte:window onkeydown={onKeydown} />

{#if !doc}
  <div class="placeholder center">
    <p class="faint">{t("editor.noDoc")}</p>
  </div>
{:else}
  <div class="editor-shell">
    <div class="toolbar">
      <div class="group">
        <button class="ghost sm" title={t("editor.bold")} onclick={() => exec("bold")}><b>B</b></button>
        <button class="ghost sm" title={t("editor.italic")} onclick={() => exec("italic")}><i>I</i></button>
        <button class="ghost sm" title="下線" onclick={() => exec("underline")}><u>U</u></button>
        <button class="ghost sm" title="取り消し線" onclick={() => exec("strikeThrough")}><s>S</s></button>
      </div>
      <div class="divider"></div>
      <div class="group">
        <button class="ghost sm" title={t("editor.h2")} onclick={() => exec("formatBlock", "<h2>")}>H2</button>
        <button class="ghost sm" title={t("editor.h2")} onclick={() => exec("formatBlock", "<h3>")}>H3</button>
        <button class="ghost sm" title={t("kind.doc")} onclick={() => exec("formatBlock", "<p>")}>¶</button>
      </div>
      <div class="divider"></div>
      <div class="group">
        <button class="ghost sm" title={t("editor.bullet")} onclick={() => exec("insertUnorderedList")}>• リスト</button>
        <button class="ghost sm" title={t("editor.ordered")} onclick={() => exec("insertOrderedList")}>1. リスト</button>
        <button class="ghost sm" title={t("editor.quote")} onclick={() => exec("formatBlock", "<blockquote>")}>❝</button>
      </div>
      <div class="spacer"></div>
      <span class="status mono" class:dirty={status === "dirty" || status === "saving"}>{statusLabel}</span>
    </div>

    <div class="paper scroll">
      <input class="title" bind:value={titleInput} oninput={handleTitleInput} aria-label={t("kind.doc")} />
      <div
        class="content"
        contenteditable="true"
        bind:this={editorEl}
        oninput={handleInput}
        onblur={() => void flush()}
        role="textbox"
        aria-multiline="true"
        aria-label={t("kind.doc")}
      ></div>
    </div>

    <div class="footer mono">{t("editor.chars", { n: charCount.toLocaleString() })}</div>
  </div>
{/if}

<style>
  .placeholder { height: 100%; color: var(--text-faint); }
  .editor-shell {
    display: flex; flex-direction: column; height: 100%; min-height: 0; min-width: 0;
    background: var(--bg);
  }
  .paper { overscroll-behavior: contain; }
  .toolbar {
    display: flex; align-items: center; gap: 6px;
    padding: 8px 14px; border-bottom: 1px solid var(--border);
    background: var(--bg-elev);
  }
  .group { display: flex; gap: 2px; }
  .divider { width: 1px; height: 18px; background: var(--border); margin: 0 4px; }
  .status { font-size: 11.5px; color: var(--text-faint); }
  .status.dirty { color: var(--warn); }
  .paper {
    flex: 1; overflow-y: auto; padding: 40px 24px 80px;
    display: flex; flex-direction: column; align-items: center;
  }
  .title {
    width: min(720px, 100%);
    font-size: 26px; font-weight: 700; letter-spacing: -0.01em;
    border: none; background: transparent; padding: 0 0 10px;
    border-bottom: 1px solid transparent;
  }
  .title:focus { box-shadow: none; border-bottom-color: var(--border); }
  .content {
    width: min(720px, 100%);
    min-height: 60vh;
    margin-top: 18px;
    font-size: 15px;
    line-height: 1.9;
    outline: none;
  }
  .content :global(h1) { font-size: 24px; margin: 1.4em 0 0.5em; }
  .content :global(h2) { font-size: 19px; margin: 1.3em 0 0.45em; }
  .content :global(h3) { font-size: 16px; margin: 1.2em 0 0.4em; }
  .content :global(p) { margin: 0.7em 0; }
  .content :global(ul), .content :global(ol) { padding-left: 1.4em; margin: 0.6em 0; }
  .content :global(blockquote) {
    border-left: 3px solid var(--border-strong); margin: 0.8em 0;
    padding: 0.1em 0 0.1em 1em; color: var(--text-soft);
  }
  .content :global(a) { color: var(--accent); }
  .content :global(code) {
    font-family: var(--mono); font-size: 0.88em;
    background: var(--bg-sunken); padding: 0.1em 0.35em; border-radius: 4px;
  }
  .footer {
    padding: 6px 16px; border-top: 1px solid var(--border);
    font-size: 11px; color: var(--text-faint); background: var(--bg-elev);
    display: flex; justify-content: flex-end;
  }
</style>
