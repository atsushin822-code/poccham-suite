<script lang="ts">
  import { t } from "../i18n.svelte";
  import { TEMPLATES } from "../templates";

  let { onpick, onclose }: { onpick: (id: string) => void; onclose: () => void } = $props();

  function onKeydown(event: KeyboardEvent) {
    if (event.key === "Escape") onclose();
  }
</script>

<svelte:window onkeydown={onKeydown} />

<div class="overlay" role="dialog" aria-modal="true" aria-label={t("tpl.pick")}>
  <div class="sheet">
    <header>
      <h2>{t("tpl.pick")}</h2>
      <button class="ghost sm" onclick={onclose} aria-label={t("close")}>✕</button>
    </header>
    <div class="grid">
      {#each TEMPLATES as tpl (tpl.id)}
        <button class="card tpl" data-template={tpl.id} onclick={() => onpick(tpl.id)}>
          <span class="badge">{t(`kind.${tpl.kind}`)}</span>
          <span class="name">{t(tpl.nameKey)}</span>
          <span class="desc">{t(tpl.descKey)}</span>
        </button>
      {/each}
    </div>
    <footer>
      <span class="faint">{t("tpl.blank")}</span>
      <div class="spacer"></div>
      <button class="ghost sm" onclick={onclose}>{t("close")}</button>
    </footer>
  </div>
</div>

<style>
  .overlay {
    position: fixed; inset: 0; z-index: 900; display: grid; place-items: center;
    background: color-mix(in srgb, #000 45%, transparent); padding: 24px;
  }
  .sheet {
    width: min(920px, 100%); max-height: min(84vh, 760px); overflow: auto;
    background: var(--bg-elev); border-radius: var(--radius-lg);
    border: 1px solid var(--border); box-shadow: var(--shadow-md);
    padding: 18px 20px 14px; display: flex; flex-direction: column; gap: 14px;
  }
  header { display: flex; align-items: center; gap: 10px; }
  h2 { margin: 0; font-size: 16px; letter-spacing: -0.01em; }
  .spacer { flex: 1; }
  .grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(230px, 1fr)); gap: 12px; }
  .card.tpl {
    display: flex; flex-direction: column; gap: 6px; align-items: flex-start;
    text-align: left; padding: 14px; border-radius: 12px; border: 1px solid var(--border);
    background: var(--bg); cursor: pointer; transition: border-color 0.15s ease, transform 0.15s ease;
  }
  .card.tpl:hover { border-color: color-mix(in srgb, var(--accent) 45%, var(--border)); transform: translateY(-1px); }
  .badge {
    font-size: 10.5px; padding: 2px 7px; border-radius: 999px;
    background: var(--accent-soft); color: var(--accent-text); font-weight: 650;
  }
  .name { font-size: 14px; font-weight: 650; color: var(--text); }
  .desc { font-size: 12px; color: var(--text-soft); line-height: 1.6; }
  footer { display: flex; align-items: center; gap: 8px; border-top: 1px solid var(--border); padding-top: 10px; }
</style>
