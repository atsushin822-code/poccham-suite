<script lang="ts">
  // スライドエディタ。保存形式は section の連なり（slides.ts 参照）。
  import { api } from "../api";
  import { t } from "../i18n.svelte";
  import { fileToDataUri, IMAGE_ACCEPT, MAX_IMAGE_BYTES } from "../media";
  import { emptySlide, htmlToSlides, slidesToHtml, slidesToText, type Slide } from "../slides";
  import type { Doc } from "../types";

  let {
    doc,
    onSaved,
    onpresent,
  }: {
    doc: Doc | null;
    onSaved?: (updatedAt: number, title: string) => void;
    /** スライドショーを開始する（親 = Workspace が全画面表示を担当） */
    onpresent?: () => void;
  } = $props();

  const AUTOSAVE_MS = 800;

  let slides = $state<Slide[]>([emptySlide()]);
  let current = $state(0);
  let titleInput = $state("");
  let loadedId = $state<string | null>(null);

  let imageInput = $state<HTMLInputElement>();
  let imgNote = $state<string | null>(null);
  let noteTimer: ReturnType<typeof setTimeout> | undefined;

  let status = $state<"idle" | "dirty" | "saving" | "saved">("idle");
  let savedAt = $state(0);
  let pending = $state<{ id: string; title: string; content: string; plain: string } | null>(null);
  let saveTimer: ReturnType<typeof setTimeout> | undefined;

  $effect(() => {
    const d = doc;
    if (!d || d.id === loadedId) return;
    if (pending) void flush();
    loadedId = d.id;
    titleInput = d.title;
    slides = htmlToSlides(d.content);
    current = 0;
    status = "idle";
  });

  function scheduleSave() {
    if (!loadedId) return;
    pending = {
      id: loadedId,
      title: titleInput,
      content: slidesToHtml(slides),
      plain: slidesToText(slides),
    };
    status = "dirty";
    clearTimeout(saveTimer);
    saveTimer = setTimeout(() => void flush(), AUTOSAVE_MS);
  }

  async function flush() {
    const payload = pending;
    if (!payload) return;
    pending = null;
    status = "saving";
    try {
      const ts = await api.saveDocument(payload.id, payload.title, payload.content, payload.plain);
      savedAt = ts;
      status = "saved";
      onSaved?.(ts, payload.title);
    } catch (e) {
      console.error("保存に失敗しました", e);
      pending = payload;
      status = "dirty";
    }
  }

  function update(patch: Partial<Slide>) {
    const next = slides.map((s, i) => (i === current ? { ...s, ...patch } : s));
    slides = next;
    scheduleSave();
  }

  function addSlide() {
    const at = current + 1;
    slides = [...slides.slice(0, at), emptySlide(slides.length + 1), ...slides.slice(at)];
    current = at;
    scheduleSave();
  }

  function removeSlide() {
    if (slides.length <= 1) return;
    slides = slides.filter((_, i) => i !== current);
    current = Math.max(0, Math.min(current, slides.length - 1));
    scheduleSave();
  }

  function move(delta: number) {
    const to = current + delta;
    if (to < 0 || to >= slides.length) return;
    const next = [...slides];
    [next[current], next[to]] = [next[to], next[current]];
    slides = next;
    current = to;
    scheduleSave();
  }

  /** スライドに画像を貼る（data URI として本文に保存する） */
  async function onImagePicked(event: Event) {
    const input = event.currentTarget as HTMLInputElement;
    const file = input.files?.[0];
    input.value = "";
    if (!file) return;
    if (file.size > MAX_IMAGE_BYTES) {
      imgNote = t("ins.tooLarge", { size: Math.round(MAX_IMAGE_BYTES / 1024 / 1024) });
      clearTimeout(noteTimer);
      noteTimer = setTimeout(() => (imgNote = null), 5000);
      return;
    }
    try {
      update({ image: await fileToDataUri(file) });
      imgNote = null;
    } catch (e) {
      console.error(e);
      imgNote = t("ins.failed");
    }
  }

  function onWindowKeydown(event: KeyboardEvent) {
    if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "s") {
      event.preventDefault();
      void flush();
    }
  }

  const slide = $derived(slides[current] ?? emptySlide());

  const statusLabel = $derived(
    status === "saving"
      ? "保存中…"
      : status === "dirty"
        ? t("editor.dirty")
        : savedAt
          ? t("editor.saved", { time: new Date(savedAt).toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" }) })
          : "",
  );
</script>

<svelte:window onkeydown={onWindowKeydown} />

{#if !doc}
  <div class="placeholder center">
    <p class="faint">{t("editor.noDoc")}</p>
  </div>
{:else}
  <div class="slide-shell">
    <div class="head">
      <input class="title" bind:value={titleInput} oninput={scheduleSave} aria-label={t("kind.slide")} />
      <span class="spacer"></span>
      {#if imgNote}
        <span class="note">{imgNote}</span>
      {/if}
      <span class="status mono">{statusLabel}</span>
    </div>

    <div class="body">
      <aside class="thumbs">
        {#each slides as s, i (i)}
          <button class="thumb" class:active={i === current} onclick={() => (current = i)} title={`スライド ${i + 1}`}>
            <span class="no mono">{i + 1}</span>
            <span class="thumb-title">{s.title || t("slide.untitled")}</span>
            {#if s.image}<span class="thumb-img" aria-hidden="true">▣</span>{/if}
          </button>
        {/each}
        <div class="thumb-actions">
          <button class="ghost sm" onclick={addSlide} title={t("slide.add")}>{t("slide.add")}</button>
          <button class="ghost sm" onclick={() => move(-1)} disabled={current === 0} title={t("slide.up")}>↑</button>
          <button class="ghost sm" onclick={() => move(1)} disabled={current === slides.length - 1} title={t("slide.down")}>↓</button>
          <button class="ghost sm" onclick={removeSlide} disabled={slides.length <= 1} title={t("slide.remove")}>{t("slide.remove")}</button>
        </div>
      </aside>

      <div class="editor">
        <label class="field">
          <span class="label">{t("slide.title")}</span>
          <input
            class="s-title"
            value={slide.title}
            oninput={(e) => update({ title: (e.currentTarget as HTMLInputElement).value })}
            aria-label={t("slide.title")}
          />
        </label>
        <label class="field grow">
          <span class="label">{t("slide.body")}</span>
          <textarea
            class="s-body"
            value={slide.body}
            oninput={(e) => update({ body: (e.currentTarget as HTMLTextAreaElement).value })}
            aria-label={t("slide.body")}
          ></textarea>
        </label>

        <div class="field">
          <span class="label">{t("ins.image")}</span>
          <div class="imgrow">
            <button class="ghost sm" onclick={() => imageInput?.click()}>
              {slide.image ? t("ins.imageChange") : t("ins.imageAdd")}
            </button>
            {#if slide.image}
              <button class="ghost sm" onclick={() => update({ image: undefined })}>{t("ins.imageRemove")}</button>
              <img class="mini" src={slide.image} alt="" />
            {/if}
            <input
              class="file"
              type="file"
              accept={IMAGE_ACCEPT}
              bind:this={imageInput}
              onchange={onImagePicked}
              aria-label={t("ins.image")}
              tabindex="-1"
            />
          </div>
        </div>

        <div class="preview-wrap">
          <div class="preview-head">
            <span class="label">{t("slide.preview")}</span>
            <div class="spacer"></div>
            {#if onpresent}
              <button class="ghost sm" onclick={onpresent} title={t("slide.present")}>▶ {t("slide.present")}</button>
            {/if}
          </div>
          <div class="preview">
            <h2>{slide.title || t("slide.untitled")}</h2>
            {#if slide.image}
              <img class="preview-img" src={slide.image} alt="" />
            {/if}
            {#each (slide.body || "").split("\n") as line, i (i)}
              {#if line.trim()}
                <p>{line}</p>
              {/if}
            {/each}
            <span class="pageno mono">{current + 1} / {slides.length}</span>
          </div>
        </div>
      </div>
    </div>
  </div>
{/if}

<style>
  .slide-shell { display: flex; flex-direction: column; height: 100%; min-height: 0; background: var(--bg); }
  .head {
    display: flex; align-items: center; gap: 10px;
    padding: 10px 18px; border-bottom: 1px solid var(--border);
  }
  .title {
    font-size: 20px; font-weight: 650; border: none; background: transparent;
    color: var(--text); outline: none; min-width: 240px; flex: 0 1 420px;
  }
  .spacer { flex: 1; }
  .status { font-size: 11px; color: var(--text-faint); }
  .body { flex: 1; display: grid; grid-template-columns: 176px minmax(0, 1fr); min-height: 0; }
  .thumbs {
    border-right: 1px solid var(--border); padding: 10px; overflow: auto;
    display: flex; flex-direction: column; gap: 8px; background: var(--bg-elev);
  }
  .thumb {
    display: flex; align-items: center; gap: 8px; text-align: left;
    border: 1px solid var(--border); border-radius: 10px; padding: 8px 10px;
    background: var(--bg); color: var(--text); cursor: pointer; font: inherit; font-size: 12px;
  }
  .thumb.active { border-color: var(--accent); box-shadow: 0 0 0 2px color-mix(in srgb, var(--accent) 22%, transparent); }
  .no { color: var(--text-faint); font-size: 11px; }
  .thumb-title { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .thumb-actions { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 4px; }
  .editor { padding: 14px 18px; overflow: auto; display: flex; flex-direction: column; gap: 12px; min-height: 0; }
  .field { display: flex; flex-direction: column; gap: 5px; }
  .field.grow { flex: 1; min-height: 120px; }
  .label { font-size: 11px; color: var(--text-faint); }
  .s-title {
    font-size: 16px; padding: 8px 10px; border-radius: 10px;
    border: 1px solid var(--border); background: var(--bg); color: var(--text);
  }
  .s-body {
    flex: 1; min-height: 110px; resize: vertical; font: inherit; font-size: 13px; line-height: 1.7;
    padding: 10px; border-radius: 10px; border: 1px solid var(--border);
    background: var(--bg); color: var(--text);
  }
  .preview-wrap { display: flex; flex-direction: column; gap: 5px; }
  .preview-head { display: flex; align-items: center; gap: 8px; }
  .preview-head .spacer { flex: 1; }
  .preview {
    position: relative; aspect-ratio: 16 / 9; width: 100%; max-width: 640px;
    background: linear-gradient(135deg, #ffffff, #f4f6fb);
    border: 1px solid var(--border); border-radius: 12px;
    padding: 22px 26px; color: #1d1d1f; overflow: hidden;
    box-shadow: 0 6px 20px rgba(20, 24, 60, 0.07);
  }
  .preview h2 { font-size: clamp(15px, 2.1vw, 22px); margin: 0 0 10px; }
  .preview p { margin: 0 0 6px; font-size: clamp(11px, 1.35vw, 14px); line-height: 1.6; }
  .imgrow { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
  .mini { height: 34px; border-radius: 6px; border: 1px solid var(--border); }
  .file { position: absolute; width: 1px; height: 1px; opacity: 0; pointer-events: none; }
  .note { font-size: 11px; color: var(--warn); }
  .thumb-img { margin-left: auto; color: var(--accent); font-size: 10px; }
  .preview-img { display: block; max-width: 100%; max-height: 48%; object-fit: contain; border-radius: 8px; margin: 0 0 8px; }
  .pageno { position: absolute; right: 14px; bottom: 10px; }
  .pageno.mono { font-size: 11px; color: #8b8b93; }
  .placeholder { height: 100%; }
</style>
