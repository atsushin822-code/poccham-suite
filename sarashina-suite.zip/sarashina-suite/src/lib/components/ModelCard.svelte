<script lang="ts">
  import ProgressBar from "./ProgressBar.svelte";
  import { formatBytes, formatEta, formatSpeed } from "../format";
  import { t } from "../i18n.svelte";
  import type { DownloadEvent, ModelView } from "../types";

  let {
    model,
    progress = null,
    busy = false,
    ondownload,
    oncancel,
    ondelete,
    onactivate,
    active = false,
  }: {
    model: ModelView;
    progress?: DownloadEvent | null;
    busy?: boolean;
    ondownload: (id: string) => void;
    oncancel: (id: string) => void;
    ondelete: (id: string) => void;
    onactivate: (id: string) => void;
    active?: boolean;
  } = $props();

  const running = $derived(
    progress != null &&
      (progress.phase === "preparing" || progress.phase === "downloading" || progress.phase === "verifying"),
  );
  const failed = $derived(progress?.phase === "failed");
  const cancelled = $derived(progress?.phase === "cancelled");
  const ratio = $derived(
    progress && progress.total > 0 ? Math.min(1, progress.downloaded / progress.total) : 0,
  );
  const phaseLabel = $derived(
    progress?.phase === "verifying"
      ? t("model.verifying")
      : progress?.phase === "preparing"
        ? t("model.preparing")
        : t("model.downloading"),
  );
</script>

<article class:recommended={model.recommended} class:active>
  <div class="head">
    <div>
      <h3>
        {model.displayName}
        {#if model.recommended}<span class="tag accent">{t("model.recommended")}</span>{/if}
        {#if active}<span class="tag ok">{t("model.inUse")}</span>{/if}
      </h3>
      <p class="desc">{model.description}</p>
    </div>
    <div class="specs mono">
      <div>{formatBytes(model.sizeBytes)}</div>
      <div class="faint">{t("model.ram", { gb: model.minRamGb })}</div>
    </div>
  </div>

  <div class="meta">
    <span class="tag">{model.params}</span>
    <span class="tag">{model.quant}</span>
    {#if model.installed}<span class="tag ok">{t("model.installed")}</span>{/if}
    {#if model.status === "partial" && !running}<span class="tag warn">{t("model.partial")}</span>{/if}
  </div>

  {#if running && progress}
    <div class="progress">
      <ProgressBar
        value={ratio}
        label={phaseLabel}
        detail={`${formatBytes(progress.downloaded)} / ${formatBytes(progress.total)} ・ ${formatSpeed(progress.bytesPerSec)} ・ ${formatEta(progress.etaSecs)}`}
        indeterminate={progress.phase === "preparing"}
      />
    </div>
  {/if}

  {#if failed}
    <div class="note error">{t("model.failed")}: {progress?.message ?? ""}</div>
  {:else if cancelled}
    <div class="note">{t("model.cancelled")}</div>
  {/if}

  <div class="actions">
    {#if model.installed}
      {#if !active}
        <button class="sm" onclick={() => onactivate(model.id)}>{t("model.use")}</button>
      {/if}
      <button class="sm danger" onclick={() => ondelete(model.id)}>{t("model.delete")}</button>
    {:else if running}
      <button class="sm danger" onclick={() => oncancel(model.id)}>{t("model.cancel")}</button>
    {:else}
      <button class="primary sm" disabled={busy} onclick={() => ondownload(model.id)}>
        {model.status === "partial" || failed || cancelled ? t("model.resume") : t("model.download")}
      </button>
    {/if}
  </div>
</article>

<style>
  article {
    border: 1px solid var(--border); border-radius: var(--radius-lg);
    background: var(--bg-elev); padding: 16px 18px; box-shadow: var(--shadow-sm);
    display: flex; flex-direction: column; gap: 11px;
  }
  article.recommended { border-color: color-mix(in srgb, var(--accent) 32%, var(--border)); }
  article.active {
    box-shadow: 0 0 0 1px color-mix(in srgb, var(--ok) 40%, transparent), var(--shadow-sm);
  }
  .head { display: flex; justify-content: space-between; gap: 14px; align-items: flex-start; }
  h3 {
    margin: 0 0 4px; font-size: 14.5px; font-weight: 650;
    display: flex; align-items: center; gap: 7px; flex-wrap: wrap;
  }
  .desc { margin: 0; font-size: 12.5px; color: var(--text-soft); line-height: 1.6; }
  .specs { text-align: right; font-size: 12px; flex: none; }
  .meta { display: flex; gap: 5px; flex-wrap: wrap; }
  .progress { padding: 2px 0; }
  .note { font-size: 12px; color: var(--text-soft); }
  .note.error { color: var(--danger); }
  .actions { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
</style>
