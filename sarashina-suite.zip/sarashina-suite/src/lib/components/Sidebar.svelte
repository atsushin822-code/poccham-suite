<script lang="ts">
  import { api } from "../api";
  import { formatRelative } from "../format";
  import { t } from "../i18n.svelte";
  import { store } from "../stores/app.svelte";
  import type { DocumentKind, DocumentSummary, SearchHit } from "../types";

  // 種別アイコン（インライン SVG: フォント依存なし）。ラベルは表示言語に追従する
  const KINDS: DocumentKind[] = ["doc", "sheet", "slide"];
  const kindLabel = (kind: DocumentKind) =>
    kind === "sheet" ? t("kind.sheet") : kind === "slide" ? t("kind.slide") : t("kind.doc");

  let {
    documents = [],
    activeId = null,
    engineLabel = "",
    demo = false,
    web = false,
    onselect,
    oncreate,
    ondelete,
    onpin,
    onsettings,
    oninstall,
  }: {
    documents: DocumentSummary[];
    activeId?: string | null;
    engineLabel?: string;
    demo?: boolean;
    /** 静的 Web 版ではモデル導入ができないため導線を無効化する */
    web?: boolean;
    onselect: (id: string) => void;
    oncreate: (kind: DocumentKind) => void;
    ondelete: (id: string) => void;
    onpin: (id: string, pinned: boolean) => void;
    onsettings: () => void;
    oninstall: () => void;
  } = $props();

  let query = $state("");
  let hits = $state<SearchHit[]>([]);
  let searching = $state(false);

  // FTS5(trigram) 全文検索。2 文字以上で発火し、入力は 250ms デバウンス。
  let timer: ReturnType<typeof setTimeout> | undefined;
  function onSearchInput() {
    clearTimeout(timer);
    const q = query.trim();
    if (q.length < 2) {
      hits = [];
      searching = false;
      return;
    }
    searching = true;
    timer = setTimeout(async () => {
      try {
        hits = await api.searchDocuments(q);
      } catch {
        hits = [];
      } finally {
        searching = false;
      }
    }, 250);
  }
</script>

<aside>
  <div class="brand">
    <div class="logo">P</div>
    <div class="who">
      <div class="name">{t("app.name")}</div>
      {#if store.userName}
        <div class="sub greeting">{t("work.greeting", { name: store.userName })}</div>
      {:else}
        <div class="sub">{demo ? t("nav.demo") : t("nav.offline")}</div>
      {/if}
    </div>
  </div>

  <div class="actions">
    {#each KINDS as kind (kind)}
      <button class="create" title={kindLabel(kind)} onclick={() => oncreate(kind)} data-kind={kind}>
        {#if kind === "doc"}
          <svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 1.5h6l4 4v9h-10z" /><path d="M9 1.5v4h4" /></svg>
        {:else if kind === "sheet"}
          <svg viewBox="0 0 16 16" aria-hidden="true"><rect x="1.5" y="2.5" width="13" height="11" rx="1.5" /><path d="M1.5 6.5h13M6 2.5v11M10.5 2.5v11" /></svg>
        {:else}
          <svg viewBox="0 0 16 16" aria-hidden="true"><rect x="1.5" y="3" width="13" height="10" rx="1.5" /><path d="M4.5 6.2h4M4.5 8.6h6M4.5 11h3" /></svg>
        {/if}
        <span class="create-label">＋ {kindLabel(kind)}</span>
      </button>
    {/each}
  </div>

  <div class="search">
    <input
      type="search"
      bind:value={query}
      oninput={onSearchInput}
      aria-label={t("nav.search")}
      title={t("nav.searchHint")}
    />
  </div>

  <div class="list scroll">
    {#if query.trim().length >= 2}
      <div class="section-title">
        {t("nav.searchResults")} <span class="faint">{searching ? "…" : hits.length}</span>
      </div>
      {#each hits as hit (hit.id)}
        <button class="item" class:active={hit.id === activeId} onclick={() => onselect(hit.id)}>
          <div class="item-title">{hit.title}</div>
          <div class="item-preview">{@html hit.snippet.replaceAll("<<", "<mark>").replaceAll(">>", "</mark>")}</div>
        </button>
      {:else}
        <div class="empty">{t("nav.noMatch")}</div>
      {/each}
    {:else}
      <div class="section-title">{t("nav.documents")} <span class="faint">{documents.length}</span></div>
      {#each documents as doc (doc.id)}
        <div class="item-wrap">
          <button class="item" class:active={doc.id === activeId} onclick={() => onselect(doc.id)}>
            <div class="item-title">
              <span class="kind" data-kind={doc.kind} title={kindLabel(doc.kind)}>
                {#if doc.kind === "sheet"}
                  <svg viewBox="0 0 16 16" aria-hidden="true"><rect x="1.5" y="2.5" width="13" height="11" rx="1.5" /><path d="M1.5 6.5h13M6 2.5v11M10.5 2.5v11" /></svg>
                {:else if doc.kind === "slide"}
                  <svg viewBox="0 0 16 16" aria-hidden="true"><rect x="1.5" y="3" width="13" height="10" rx="1.5" /><path d="M4.5 6.2h4M4.5 8.6h6M4.5 11h3" /></svg>
                {:else}
                  <svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 1.5h6l4 4v9h-10z" /><path d="M9 1.5v4h4" /></svg>
                {/if}
              </span>
              {#if doc.pinned}<span class="pin">●</span>{/if}
              {doc.title}
            </div>
            <div class="item-preview">{doc.preview || t("nav.emptyDoc")}</div>
            <div class="item-meta">{formatRelative(doc.updatedAt)}</div>
          </button>
          <div class="item-tools">
            <button
              class="ghost sm"
              title={doc.pinned ? t("nav.unpin") : t("nav.pin")}
              onclick={() => onpin(doc.id, !doc.pinned)}>★</button>
            <button class="ghost sm" title={t("nav.delete")} onclick={() => ondelete(doc.id)}>✕</button>
          </div>
        </div>
      {:else}
        <div class="empty">{t("nav.empty")}</div>
      {/each}
    {/if}
  </div>

  <div class="footer">
    <button
      class="engine"
      onclick={oninstall}
      disabled={web}
      title={web ? t("ai.webNotice") : t("ai.install")}
    >
      <span class="dot" class:on={store.engineReady}></span>
      <span class="engine-label">{engineLabel}</span>
    </button>
    <button class="ghost sm" onclick={onsettings}>{t("nav.settings")}</button>
  </div>
</aside>

<style>
  aside {
    display: flex;
    flex-direction: column;
    height: 100%;
    background: var(--sidebar);
    border-right: 1px solid var(--border);
    min-width: 0;
  }
  .brand { display: flex; gap: 10px; align-items: center; padding: 16px 16px 10px; }
  .logo {
    width: 30px; height: 30px; border-radius: 9px;
    background: linear-gradient(135deg, var(--accent), #22d3ee);
    color: #fff; font-weight: 700; display: grid; place-items: center;
    box-shadow: var(--shadow-sm);
  }
  .who { min-width: 0; }
  .name {
    font-weight: 650; font-size: 13.5px; letter-spacing: 0.01em;
    overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
  }
  .greeting { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .sub { font-size: 11px; color: var(--text-faint); }
  .actions {
    display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 6px; padding: 4px 12px 10px;
  }
  .create {
    display: flex; align-items: center; justify-content: center; gap: 4px;
    padding: 8px 4px; font-size: 11.5px; border-radius: 9px; cursor: pointer;
    border: 1px solid var(--border); background: var(--bg-elev); color: var(--text);
    transition: background 0.12s, border-color 0.12s;
  }
  .create:hover { background: var(--bg-sunken); border-color: color-mix(in srgb, var(--accent) 35%, var(--border)); }
  .create svg { width: 14px; height: 14px; stroke: currentColor; stroke-width: 1.3; fill: none; flex: none; }
  .create-label { white-space: nowrap; }
  .kind { display: inline-flex; vertical-align: -2px; margin-right: 5px; color: var(--text-faint); }
  .kind svg { width: 12px; height: 12px; stroke: currentColor; stroke-width: 1.3; fill: none; }
  .search { padding: 0 12px 10px; }
  .search input { width: 100%; padding: 7px 10px; font-size: 13px; }
  .list { flex: 1; padding: 0 8px 8px; min-height: 0; }
  .section-title {
    font-size: 11px; text-transform: uppercase; letter-spacing: 0.07em;
    color: var(--text-faint); padding: 8px 8px 6px;
  }
  .item-wrap { position: relative; }
  .item {
    display: block; width: 100%; text-align: left;
    background: transparent; border: 1px solid transparent; border-radius: 9px;
    padding: 8px 10px; margin-bottom: 2px;
  }
  .item:hover { background: var(--bg-sunken); }
  .item.active { background: var(--accent-soft); border-color: color-mix(in srgb, var(--accent) 25%, transparent); }
  .item-title {
    font-size: 13px; font-weight: 600; color: var(--text);
    overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
  }
  .pin { color: var(--accent); font-size: 9px; margin-right: 3px; }
  .item-preview {
    font-size: 11.5px; color: var(--text-faint); line-height: 1.45;
    display: -webkit-box; -webkit-line-clamp: 2; line-clamp: 2; -webkit-box-orient: vertical;
    overflow: hidden; margin-top: 1px;
  }
  .item-preview :global(mark) { background: color-mix(in srgb, var(--accent) 22%, transparent); color: inherit; border-radius: 3px; }
  .item-meta { font-size: 10.5px; color: var(--text-faint); margin-top: 3px; }
  .item-tools {
    position: absolute; right: 6px; top: 6px; display: none; gap: 2px;
    background: var(--bg-elev); border-radius: 8px; box-shadow: var(--shadow-sm); padding: 1px;
  }
  .item-wrap:hover .item-tools { display: flex; }
  .empty { padding: 22px 10px; text-align: center; color: var(--text-faint); font-size: 12.5px; }
  .footer {
    border-top: 1px solid var(--border); padding: 10px 12px;
    display: flex; align-items: center; gap: 8px;
  }
  .engine {
    flex: 1; display: flex; align-items: center; gap: 7px; justify-content: flex-start;
    font-size: 11.5px; color: var(--text-soft); background: transparent; border-color: transparent;
    overflow: hidden;
  }
  .engine:hover { background: var(--bg-sunken); }
  .engine-label { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .dot { width: 7px; height: 7px; border-radius: 50%; background: var(--text-faint); flex: none; }
  .dot.on { background: var(--ok); box-shadow: 0 0 0 3px color-mix(in srgb, var(--ok) 18%, transparent); }
</style>
