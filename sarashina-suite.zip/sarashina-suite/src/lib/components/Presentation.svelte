<script lang="ts">
  // スライドショー（全画面）。←/→/Space で移動、Esc で終了。
  import { onMount } from "svelte";
  import { t } from "../i18n.svelte";
  import type { Slide } from "../slides";

  let { slides, start = 0, onclose }: { slides: Slide[]; start?: number; onclose: () => void } = $props();

  // 開いた時点の値を初期位置にする（以降はコンポーネント内で管理する）
  // svelte-ignore state_referenced_locally
  let index = $state(Math.min(start, Math.max(0, slides.length - 1)));
  let fsRequested = false;

  const slide = $derived(slides[index] ?? { title: "", body: "" });
  const lines = $derived((slide.body || "").split(/\r?\n/).filter((l) => l.trim() !== ""));
  const progress = $derived(slides.length > 1 ? (index + 1) / slides.length : 1);

  function next() {
    if (index < slides.length - 1) index += 1;
  }
  function prev() {
    if (index > 0) index -= 1;
  }

  async function close() {
    try {
      if (document.fullscreenElement) await document.exitFullscreen();
    } catch {
      /* 全画面でない場合は無視 */
    }
    onclose();
  }

  function onKeydown(event: KeyboardEvent) {
    switch (event.key) {
      case "ArrowRight":
      case "ArrowDown":
      case " ":
      case "PageDown":
      case "Enter":
        event.preventDefault();
        next();
        break;
      case "ArrowLeft":
      case "ArrowUp":
      case "PageUp":
      case "Backspace":
        event.preventDefault();
        prev();
        break;
      case "Home":
        index = 0;
        break;
      case "End":
        index = slides.length - 1;
        break;
      case "Escape":
        event.preventDefault();
        void close();
        break;
    }
  }

  onMount(() => {
    const el = document.documentElement;
    if (!document.fullscreenElement && el.requestFullscreen) {
      el.requestFullscreen().then(
        () => (fsRequested = true),
        () => (fsRequested = false),
      );
    }
    return () => {
      if (fsRequested && document.fullscreenElement) void document.exitFullscreen();
    };
  });
</script>

<svelte:window onkeydown={onKeydown} />

<div class="present" role="dialog" aria-label={t("slide.present")}>
  <div class="stage">
    <h1>{slide.title}</h1>
    {#if lines.length}
      <ul>
        {#each lines as line, i (i)}
          <li>{line}</li>
        {/each}
      </ul>
    {/if}
  </div>

  <div class="bar">
    <div class="progress"><span style={`width:${progress * 100}%`}></span></div>
    <div class="row">
      <button class="ghost sm" onclick={prev} disabled={index === 0} aria-label={t("present.prev")}>←</button>
      <span class="counter mono">{index + 1} / {slides.length}</span>
      <button class="ghost sm" onclick={next} disabled={index === slides.length - 1} aria-label={t("present.next")}>→</button>
      <div class="spacer"></div>
      <span class="hint faint">{t("present.exit")}</span>
      <button class="ghost sm" onclick={close} aria-label={t("common.close")}>✕</button>
    </div>
  </div>
</div>

<style>
  .present {
    position: fixed;
    inset: 0;
    z-index: 1000;
    background: #0b0c10;
    color: #f7f8fb;
    display: flex;
    flex-direction: column;
  }
  .stage {
    flex: 1;
    min-height: 0;
    display: flex;
    flex-direction: column;
    justify-content: center;
    gap: 26px;
    padding: 6vh 9vw;
    overflow-y: auto;
  }
  h1 {
    margin: 0;
    font-size: clamp(26px, 4.4vw, 58px);
    line-height: 1.25;
    letter-spacing: -0.015em;
  }
  ul { margin: 0; padding-left: 1.2em; display: flex; flex-direction: column; gap: 14px; }
  li { font-size: clamp(16px, 2.1vw, 30px); line-height: 1.6; color: #d9dce6; }
  .bar { padding: 0 18px 14px; }
  .progress { height: 3px; background: #23252c; border-radius: 999px; overflow: hidden; }
  .progress span { display: block; height: 100%; background: linear-gradient(90deg, #8b8cff, #22d3ee); transition: width 0.18s ease; }
  .row { display: flex; align-items: center; gap: 8px; padding-top: 8px; }
  .counter { font-size: 12px; color: #9aa1ad; }
  .hint { font-size: 11px; }
  .bar button { background: transparent; border-color: #2c2f38; color: #d9dce6; }
  .bar button:hover { background: #1b1e25; }
</style>
