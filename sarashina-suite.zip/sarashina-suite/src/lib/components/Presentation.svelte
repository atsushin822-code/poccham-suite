<script lang="ts">
  // スライドショー（全画面）。←/→/Space で移動、Esc で終了。
  import { onMount } from "svelte";
  import { t } from "../i18n.svelte";
  import { splitBody, type Slide } from "../slides";

  let { slides, start = 0, onclose }: { slides: Slide[]; start?: number; onclose: () => void } = $props();

  // 開いた時点の値を初期位置にする（以降はコンポーネント内で管理する）
  // svelte-ignore state_referenced_locally
  let index = $state(Math.min(start, Math.max(0, slides.length - 1)));
  let fsRequested = false;

  const slide = $derived(slides[index] ?? { title: "", body: "" });
  const body = $derived(splitBody(slide));
  const layout = $derived(slide.layout ?? "content");
  const transition = $derived(slide.transition ?? "none");
  const progress = $derived(slides.length > 1 ? (index + 1) / slides.length : 1);
  let showNotes = $state(false);
  let clock = $state(0);
  let timer: ReturnType<typeof setInterval> | undefined;

  function next() {
    if (index < slides.length - 1) index += 1;
  }
  function prev() {
    if (index > 0) index -= 1;
  }

  async function close() {
    try {
      if (document.fullscreenElement) await document.exitFullscreen();
    } catch {
      /* 全画面でない場合は無視 */
    }
    onclose();
  }

  function onKeydown(event: KeyboardEvent) {
    switch (event.key) {
      case "ArrowRight":
      case "ArrowDown":
      case " ":
      case "PageDown":
      case "Enter":
        event.preventDefault();
        next();
        break;
      case "ArrowLeft":
      case "ArrowUp":
      case "PageUp":
      case "Backspace":
        event.preventDefault();
        prev();
        break;
      case "Home":
        index = 0;
        break;
      case "End":
        index = slides.length - 1;
        break;
      case "n":
      case "N":
        event.preventDefault();
        showNotes = !showNotes;
        break;
      case "Escape":
        event.preventDefault();
        void close();
        break;
    }
  }

  onMount(() => {
    timer = setInterval(() => (clock += 1), 1000);
    const el = document.documentElement;
    if (!document.fullscreenElement && el.requestFullscreen) {
      el.requestFullscreen().then(
        () => (fsRequested = true),
        () => (fsRequested = false),
      );
    }
    return () => {
      clearInterval(timer);
      if (fsRequested && document.fullscreenElement) void document.exitFullscreen();
    };
  });
</script>

<svelte:window onkeydown={onKeydown} />

<div class="present" role="dialog" aria-label={t("slide.present")}>
  <div class="stage {`layout-${layout}`} {`tr-${transition}`}">
    {#key index}
    <div class="slide-body">
      <div class="text">
        <h1 class:display={layout === "title" || layout === "section"}>{slide.title}</h1>
        {#if layout === "twoCol"}
          <div class="cols">
            <ul>{#each body.left as line, i (i)}<li>{line}</li>{/each}</ul>
            <ul>{#each body.right as line, i (i)}<li>{line}</li>{/each}</ul>
          </div>
        {:else if layout === "quote"}
          {#each body.left as line, i (i)}<p class="quote">{line}</p>{/each}
        {:else if body.left.length}
          <ul class:big={layout === "title" || layout === "section"}>
            {#each body.left as line, i (i)}<li>{line}</li>{/each}
          </ul>
        {/if}
      </div>
      {#if slide.image}
        <div class="shot"><img src={slide.image} alt="" /></div>
      {/if}
    </div>
    {/key}
  </div>

  {#if showNotes && slide.notes}
    <div class="notes">
      <span class="notes-label">{t("slide.notes")}</span>
      <div class="notes-text">{slide.notes}</div>
    </div>
  {/if}

  <div class="bar">
    <div class="progress"><span style={`width:${progress * 100}%`}></span></div>
    <div class="row">
      <button class="ghost sm" onclick={prev} disabled={index === 0} aria-label={t("present.prev")}>←</button>
      <span class="counter mono">{index + 1} / {slides.length}</span>
      <button class="ghost sm" onclick={next} disabled={index === slides.length - 1} aria-label={t("present.next")}>→</button>
      <div class="spacer"></div>
      <span class="hint faint">{t("present.clock", { time: `${String(Math.floor(clock / 60)).padStart(2, "0")}:${String(clock % 60).padStart(2, "0")}` })}</span>
      {#if slide.notes}
        <button class="ghost sm" class:on={showNotes} onclick={() => (showNotes = !showNotes)} title={t("slide.notesHint")}>📝</button>
      {/if}
      <span class="hint faint">{t("present.exit")}</span>
      <button class="ghost sm" onclick={close} aria-label={t("common.close")}>✕</button>
    </div>
  </div>
</div>

<style>
  .present {
    position: fixed;
    inset: 0;
    z-index: 1000;
    background: #0b0c10;
    color: #f7f8fb;
    display: flex;
    flex-direction: column;
  }
  .stage {
    flex: 1;
    min-height: 0;
    display: flex;
    flex-direction: column;
    justify-content: center;
    gap: 26px;
    padding: 6vh 9vw;
    overflow-y: auto;
  }
  .text { display: flex; flex-direction: column; gap: 26px; }
  .shot { display: flex; justify-content: center; min-height: 0; }
  .shot img {
    max-width: 100%;
    max-height: 46vh;
    object-fit: contain;
    border-radius: 10px;
    box-shadow: 0 10px 40px rgba(0, 0, 0, 0.45);
  }
  h1 {
    margin: 0;
    font-size: clamp(26px, 4.4vw, 58px);
    line-height: 1.25;
    letter-spacing: -0.015em;
  }
  ul { margin: 0; padding-left: 1.2em; display: flex; flex-direction: column; gap: 14px; }
  li { font-size: clamp(16px, 2.1vw, 30px); line-height: 1.6; color: #d9dce6; }
  .bar { padding: 0 18px 14px; }
  .progress { height: 3px; background: #23252c; border-radius: 999px; overflow: hidden; }
  .progress span { display: block; height: 100%; background: linear-gradient(90deg, #8b8cff, #22d3ee); transition: width 0.18s ease; }
  .row { display: flex; align-items: center; gap: 8px; padding-top: 8px; }
  .counter { font-size: 12px; color: #9aa1ad; }
  .hint { font-size: 11px; }
  .bar button { background: transparent; border-color: #2c2f38; color: #d9dce6; }
  .bar button:hover { background: #1b1e25; }
  .bar button.on { background: #23262f; color: #fff; }
  .slide-body { display: flex; flex-direction: column; gap: 26px; }
  .layout-title .slide-body, .layout-section .slide-body { align-items: center; text-align: center; }
  .layout-title h1 { font-size: clamp(30px, 5.4vw, 74px); }
  .layout-section h1 { font-size: clamp(26px, 4.6vw, 60px); }
  ul.big li { font-size: clamp(15px, 1.9vw, 26px); }
  .cols { display: grid; grid-template-columns: 1fr 1fr; gap: 40px; }
  .quote { font-size: clamp(20px, 3vw, 42px); line-height: 1.5; font-style: italic; color: #e6e8f0; margin: 0 0 10px; }
  .notes {
    margin: 0 18px 10px; padding: 10px 14px; border-radius: 10px;
    background: #14161c; border: 1px solid #262a33; max-height: 22vh; overflow-y: auto;
  }
  .notes-label { font-size: 11px; color: #8f96a3; display: block; margin-bottom: 4px; }
  .notes-text { font-size: 14px; line-height: 1.7; color: #d5d9e2; white-space: pre-wrap; }
  .tr-fade .slide-body { animation: fade 0.32s ease; }
  .tr-slide .slide-body { animation: slidein 0.3s cubic-bezier(0.2, 0.8, 0.2, 1); }
  .tr-zoom .slide-body { animation: zoomin 0.3s ease; }
  @keyframes fade { from { opacity: 0; } to { opacity: 1; } }
  @keyframes slidein { from { transform: translateX(4%); opacity: 0.4; } to { transform: none; opacity: 1; } }
  @keyframes zoomin { from { transform: scale(0.94); opacity: 0.3; } to { transform: none; opacity: 1; } }
  @media (prefers-reduced-motion: reduce) {
    .slide-body { animation: none !important; }
  }
</style>
