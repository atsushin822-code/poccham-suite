<script lang="ts">
  import { onMount } from "svelte";
  import { t } from "../i18n.svelte";
  import { api } from "../api";
  import type { AppInfo } from "../types";

  let { onclose }: { onclose: () => void } = $props();
  let info = $state<AppInfo | null>(null);

  onMount(async () => {
    try {
      info = await api.appInfo();
    } catch {
      info = null;
    }
  });

  const shortcuts = [
    { keys: "Ctrl / ⌘ + S", key: "shortcut.save" },
    { keys: "Ctrl / ⌘ + P", key: "shortcut.print" },
    { keys: "Ctrl / ⌘ + F", key: "shortcut.find" },
    { keys: "Ctrl / ⌘ + B", key: "shortcut.bold" },
    { keys: "Ctrl / ⌘ + I", key: "shortcut.italic" },
    { keys: "Ctrl / ⌘ + U", key: "shortcut.underline" },
    { keys: "Ctrl / ⌘ + Z", key: "undo" },
    { keys: "← → / Space", key: "shortcut.present" },
    { keys: "Esc", key: "shortcut.close" },
  ];

  function onKeydown(event: KeyboardEvent) {
    if (event.key === "Escape") onclose();
  }
</script>

<svelte:window onkeydown={onKeydown} />

<div class="overlay" role="dialog" aria-modal="true" aria-label={t("about.title")}>
  <div class="sheet about">
    <header>
      <div class="brand">
        <span class="logo" aria-hidden="true">P</span>
        <div>
          <h2>{t("app.name")}</h2>
          <p class="muted">{t("app.edition")} · {t("app.version", { version: info?.version ?? "0.2.0" })}</p>
        </div>
      </div>
      <div class="spacer"></div>
      <button class="ghost sm" onclick={onclose} aria-label={t("close")}>✕</button>
    </header>

    <p class="lead">{t("about.tagline")}</p>

    <section>
      <h3>{t("app.shortcuts")}</h3>
      <div class="keys">
        {#each shortcuts as s (s.key)}
          <div class="krow"><kbd>{s.keys}</kbd><span>{t(s.key)}</span></div>
        {/each}
      </div>
    </section>

    <section>
      <h3>{t("app.buildInfo")}</h3>
      <dl class="info">
        <dt>{t("app.platform")}</dt><dd>{info?.platform ?? "web"}</dd>
        <dt>{t("app.backend")}</dt><dd>{info?.backend ?? "web"}</dd>
        <dt>{t("app.dataDir")}</dt><dd class="mono small">{info?.dataDir ?? t("about.storage")}</dd>
        <dt>{t("app.license")}</dt><dd>Proprietary — {t("app.copyright")}</dd>
      </dl>
    </section>

    <section>
      <h3>{t("about.thirdPartyNotice")}</h3>
      <p class="small muted">{t("app.thirdParty")}</p>
      <p class="small muted">
        Svelte (MIT) · Vite (MIT) · Tauri (Apache-2.0 / MIT) · llama.cpp (MIT) ·
        Rust crates (MIT / Apache-2.0)
      </p>
    </section>

    <footer>
      <span class="faint small">{t("app.copyright")}</span>
      <div class="spacer"></div>
      <button class="primary sm" onclick={onclose}>{t("close")}</button>
    </footer>
  </div>
</div>

<style>
  .overlay {
    position: fixed; inset: 0; z-index: 900; display: grid; place-items: center;
    background: color-mix(in srgb, #000 45%, transparent); padding: 24px;
  }
  .sheet {
    width: min(640px, 100%); max-height: 84vh; overflow: auto;
    background: var(--bg-elev); border-radius: var(--radius-lg);
    border: 1px solid var(--border); box-shadow: var(--shadow-md);
    padding: 20px 22px 16px; display: flex; flex-direction: column; gap: 16px;
  }
  header { display: flex; align-items: flex-start; gap: 10px; }
  .brand { display: flex; gap: 12px; align-items: center; }
  .logo {
    width: 40px; height: 40px; border-radius: 12px; display: grid; place-items: center;
    background: linear-gradient(135deg, var(--accent), #22d3ee); color: #fff; font-weight: 800; font-size: 20px;
  }
  h2 { margin: 0; font-size: 17px; }
  h3 { margin: 0 0 8px; font-size: 12px; letter-spacing: 0.04em; color: var(--text-faint); text-transform: uppercase; }
  p { margin: 0; }
  .lead { font-size: 13px; color: var(--text-soft); line-height: 1.7; }
  .spacer { flex: 1; }
  .keys { display: grid; grid-template-columns: 1fr 1fr; gap: 6px 18px; }
  .krow { display: flex; align-items: center; gap: 8px; font-size: 12px; color: var(--text-soft); }
  kbd {
    font-family: var(--mono); font-size: 11px; padding: 2px 6px; border-radius: 6px;
    border: 1px solid var(--border); background: var(--bg-sunken); color: var(--text); white-space: nowrap;
  }
  .info { display: grid; grid-template-columns: 110px 1fr; gap: 4px 12px; margin: 0; font-size: 12px; }
  .info dt { color: var(--text-faint); }
  .info dd { margin: 0; color: var(--text-soft); overflow-wrap: anywhere; }
  .small { font-size: 11.5px; }
  footer { display: flex; align-items: center; gap: 8px; border-top: 1px solid var(--border); padding-top: 10px; }
</style>
