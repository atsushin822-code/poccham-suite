// 依存ライブラリなしの ZIP 書き出し（無圧縮 = store のみ）。
//
// OOXML（.docx / .xlsx / .pptx）は ZIP コンテナなので、これがあれば
// 追加の npm パッケージ無しで Office ファイルを生成できる。
// 無圧縮でも Office は問題なく開ける（サイズは少し大きくなるだけ）。

/** CRC-32（ZIP のチェックサム） */
const CRC_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let i = 0; i < 256; i += 1) {
    let c = i;
    for (let k = 0; k < 8; k += 1) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    table[i] = c >>> 0;
  }
  return table;
})();

export function crc32(data: Uint8Array): number {
  let crc = 0xffffffff;
  for (let i = 0; i < data.length; i += 1) crc = CRC_TABLE[(crc ^ data[i]) & 0xff] ^ (crc >>> 8);
  return (crc ^ 0xffffffff) >>> 0;
}

const utf8 = new TextEncoder();

export interface ZipEntry {
  /** アーカイブ内パス（例: "word/document.xml"） */
  name: string;
  data: Uint8Array | string;
}

function dosDateTime(d: Date): { time: number; date: number } {
  const time = (d.getHours() << 11) | (d.getMinutes() << 5) | Math.floor(d.getSeconds() / 2);
  const date = ((d.getFullYear() - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate();
  return { time, date };
}

/** ZIP を組み立てる（ZIP64 非対応 = 4GB 未満を想定） */
export function makeZip(entries: ZipEntry[], now = new Date()): Uint8Array {
  const { time, date } = dosDateTime(now);
  const chunks: Uint8Array[] = [];
  const central: Uint8Array[] = [];
  let offset = 0;

  for (const entry of entries) {
    const nameBytes = utf8.encode(entry.name);
    const data = typeof entry.data === "string" ? utf8.encode(entry.data) : entry.data;
    const crc = crc32(data);

    const local = new Uint8Array(30 + nameBytes.length);
    const dv = new DataView(local.buffer);
    dv.setUint32(0, 0x04034b50, true); // 署名
    dv.setUint16(4, 20, true); // 必要バージョン
    dv.setUint16(6, 0x0800, true); // ファイル名は UTF-8
    dv.setUint16(8, 0, true); // 無圧縮
    dv.setUint16(10, time, true);
    dv.setUint16(12, date, true);
    dv.setUint32(14, crc, true);
    dv.setUint32(18, data.length, true);
    dv.setUint32(22, data.length, true);
    dv.setUint16(26, nameBytes.length, true);
    dv.setUint16(28, 0, true);
    local.set(nameBytes, 30);

    chunks.push(local, data);

    const cen = new Uint8Array(46 + nameBytes.length);
    const cv = new DataView(cen.buffer);
    cv.setUint32(0, 0x02014b50, true); // 中央ディレクトリ署名
    cv.setUint16(4, 20, true); // 作成バージョン
    cv.setUint16(6, 20, true); // 必要バージョン
    cv.setUint16(8, 0x0800, true);
    cv.setUint16(10, 0, true);
    cv.setUint16(12, time, true);
    cv.setUint16(14, date, true);
    cv.setUint32(16, crc, true);
    cv.setUint32(20, data.length, true);
    cv.setUint32(24, data.length, true);
    cv.setUint16(28, nameBytes.length, true);
    cv.setUint16(30, 0, true); // extra
    cv.setUint16(32, 0, true); // comment
    cv.setUint16(34, 0, true); // disk
    cv.setUint16(36, 0, true); // internal attrs
    cv.setUint32(38, 0, true); // external attrs
    cv.setUint32(42, offset, true); // local header の位置
    cen.set(nameBytes, 46);
    central.push(cen);

    offset += local.length + data.length;
  }

  const centralSize = central.reduce((n, c) => n + c.length, 0);
  const end = new Uint8Array(22);
  const ev = new DataView(end.buffer);
  ev.setUint32(0, 0x06054b50, true);
  ev.setUint16(8, entries.length, true);
  ev.setUint16(10, entries.length, true);
  ev.setUint32(12, centralSize, true);
  ev.setUint32(16, offset, true);

  const total = offset + centralSize + end.length;
  const out = new Uint8Array(total);
  let pos = 0;
  for (const chunk of chunks) {
    out.set(chunk, pos);
    pos += chunk.length;
  }
  for (const chunk of central) {
    out.set(chunk, pos);
    pos += chunk.length;
  }
  out.set(end, pos);
  return out;
}

// --- 読み込み（インポート用） ---------------------------------------------
//
// OOXML の読み込みには「ZIP の展開」が必要。外部ライブラリを足さない方針なので
// ① ZIP セントラルディレクトリの解析 ② raw deflate（RFC1951）の展開 を自前で持つ。
// `DecompressionStream` は WebView によっては未実装（macOS 12 以前など）なので使わない。

const LEN_BASE = [
  3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59,
  67, 83, 99, 115, 131, 163, 195, 227, 258,
];
const LEN_EXTRA = [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0];
const DIST_BASE = [
  1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769,
  1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577,
];
const DIST_EXTRA = [0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13];
const CL_ORDER = [16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15];

interface Huffman {
  counts: Uint16Array;
  symbols: Uint16Array;
}

function buildHuffman(lengths: Uint8Array): Huffman {
  const counts = new Uint16Array(16);
  for (let i = 0; i < lengths.length; i += 1) counts[lengths[i]] += 1;
  counts[0] = 0;
  const offsets = new Uint16Array(16);
  let total = 0;
  for (let len = 1; len < 16; len += 1) {
    offsets[len] = total;
    total += counts[len];
  }
  const symbols = new Uint16Array(total);
  const cursor = offsets.slice();
  for (let i = 0; i < lengths.length; i += 1) {
    const len = lengths[i];
    if (len) symbols[cursor[len]++] = i;
  }
  return { counts, symbols };
}

/** raw deflate（ヘッダ無し）を展開する */
export function inflateRaw(data: Uint8Array, sizeHint = 0): Uint8Array {
  let pos = 0;
  let bitBuf = 0;
  let bitCnt = 0;
  let out = new Uint8Array(Math.max(4096, sizeHint || data.length * 4));
  let outLen = 0;

  const ensure = (extra: number) => {
    if (outLen + extra <= out.length) return;
    let cap = out.length * 2;
    while (cap < outLen + extra) cap *= 2;
    const next = new Uint8Array(cap);
    next.set(out.subarray(0, outLen));
    out = next;
  };
  const readBit = (): number => {
    if (bitCnt === 0) {
      if (pos >= data.length) throw new Error("deflate: データが途中で終わっています");
      bitBuf = data[pos];
      pos += 1;
      bitCnt = 8;
    }
    const bit = bitBuf & 1;
    bitBuf >>= 1;
    bitCnt -= 1;
    return bit;
  };
  const readBits = (n: number): number => {
    let v = 0;
    for (let i = 0; i < n; i += 1) v |= readBit() << i;
    return v;
  };
  const decode = (h: Huffman): number => {
    let code = 0;
    let first = 0;
    let index = 0;
    for (let len = 1; len <= 15; len += 1) {
      code |= readBit();
      const count = h.counts[len];
      if (code - first < count) return h.symbols[index + (code - first)];
      index += count;
      first = (first + count) << 1;
      code <<= 1;
    }
    throw new Error("deflate: ハフマン符号が壊れています");
  };

  let fixedLit: Huffman | null = null;
  let fixedDist: Huffman | null = null;
  let final = 0;

  while (!final) {
    final = readBit();
    const type = readBits(2);

    if (type === 0) {
      bitCnt = 0; // バイト境界へ戻す
      if (pos + 4 > data.length) throw new Error("deflate: データが途中で終わっています");
      const len = data[pos] | (data[pos + 1] << 8);
      const nlen = data[pos + 2] | (data[pos + 3] << 8);
      pos += 4;
      if ((len ^ 0xffff) !== nlen) throw new Error("deflate: 長さ情報が壊れています");
      if (pos + len > data.length) throw new Error("deflate: データが途中で終わっています");
      ensure(len);
      out.set(data.subarray(pos, pos + len), outLen);
      outLen += len;
      pos += len;
      continue;
    }
    if (type === 3) throw new Error("deflate: 未対応のブロック形式です");

    let lit: Huffman;
    let dist: Huffman;
    if (type === 1) {
      if (!fixedLit || !fixedDist) {
        const lens = new Uint8Array(288);
        for (let i = 0; i < 144; i += 1) lens[i] = 8;
        for (let i = 144; i < 256; i += 1) lens[i] = 9;
        for (let i = 256; i < 280; i += 1) lens[i] = 7;
        for (let i = 280; i < 288; i += 1) lens[i] = 8;
        fixedLit = buildHuffman(lens);
        fixedDist = buildHuffman(new Uint8Array(30).fill(5));
      }
      lit = fixedLit;
      dist = fixedDist;
    } else {
      const hlit = readBits(5) + 257;
      const hdist = readBits(5) + 1;
      const hclen = readBits(4) + 4;
      const clLens = new Uint8Array(19);
      for (let i = 0; i < hclen; i += 1) clLens[CL_ORDER[i]] = readBits(3);
      const clHuff = buildHuffman(clLens);
      const lens = new Uint8Array(hlit + hdist);
      let i = 0;
      while (i < lens.length) {
        const sym = decode(clHuff);
        if (sym < 16) {
          lens[i] = sym;
          i += 1;
        } else if (sym === 16) {
          if (i === 0) throw new Error("deflate: 繰り返し符号が不正です");
          const value = lens[i - 1];
          let rep = 3 + readBits(2);
          while (rep > 0 && i < lens.length) {
            lens[i] = value;
            i += 1;
            rep -= 1;
          }
        } else if (sym === 17) {
          let rep = 3 + readBits(3);
          while (rep > 0 && i < lens.length) {
            lens[i] = 0;
            i += 1;
            rep -= 1;
          }
        } else {
          let rep = 11 + readBits(7);
          while (rep > 0 && i < lens.length) {
            lens[i] = 0;
            i += 1;
            rep -= 1;
          }
        }
      }
      lit = buildHuffman(lens.subarray(0, hlit));
      dist = buildHuffman(lens.subarray(hlit));
    }

    for (;;) {
      const sym = decode(lit);
      if (sym < 256) {
        ensure(1);
        out[outLen] = sym;
        outLen += 1;
        continue;
      }
      if (sym === 256) break;
      const li = sym - 257;
      if (li >= LEN_BASE.length) throw new Error("deflate: 長さ符号が不正です");
      const length = LEN_BASE[li] + readBits(LEN_EXTRA[li]);
      const di = decode(dist);
      if (di >= DIST_BASE.length) throw new Error("deflate: 距離符号が不正です");
      const distance = DIST_BASE[di] + readBits(DIST_EXTRA[di]);
      if (distance > outLen) throw new Error("deflate: 参照先が範囲外です");
      ensure(length);
      for (let k = 0; k < length; k += 1) {
        out[outLen] = out[outLen - distance];
        outLen += 1;
      }
    }
  }

  return out.subarray(0, outLen);
}

const zipDecoder = new TextDecoder("utf-8");
const zipEncoder = new TextEncoder();

interface ZipEntryInfo {
  method: number;
  compressed: number;
  size: number;
  offset: number;
}

/** ZIP アーカイブの読み取りビュー（遅延展開） */
export interface ZipArchive {
  names: string[];
  has(name: string): boolean;
  bytes(name: string): Uint8Array | null;
  text(name: string): string | null;
}

export function readZip(data: Uint8Array): ZipArchive {
  const view = new DataView(data.buffer, data.byteOffset, data.byteLength);
  const limit = Math.max(0, data.length - 0xffff - 22);
  let eocd = -1;
  for (let i = data.length - 22; i >= limit; i -= 1) {
    if (view.getUint32(i, true) === 0x06054b50) {
      eocd = i;
      break;
    }
  }
  if (eocd < 0) throw new Error("not-zip");

  const count = view.getUint16(eocd + 10, true);
  const cdOffset = view.getUint32(eocd + 16, true);
  const entries = new Map<string, ZipEntryInfo>();
  let p = cdOffset;
  for (let i = 0; i < count; i += 1) {
    if (p + 46 > data.length || view.getUint32(p, true) !== 0x02014b50) break;
    const method = view.getUint16(p + 10, true);
    const compressed = view.getUint32(p + 20, true);
    const size = view.getUint32(p + 24, true);
    const nameLen = view.getUint16(p + 28, true);
    const extraLen = view.getUint16(p + 30, true);
    const commentLen = view.getUint16(p + 32, true);
    const offset = view.getUint32(p + 42, true);
    const name = zipDecoder.decode(data.subarray(p + 46, p + 46 + nameLen));
    entries.set(name, { method, compressed, size, offset });
    p += 46 + nameLen + extraLen + commentLen;
  }

  const bytes = (name: string): Uint8Array | null => {
    const entry = entries.get(name);
    if (!entry) return null;
    const lp = entry.offset;
    if (lp + 30 > data.length || view.getUint32(lp, true) !== 0x04034b50) return null;
    const nameLen = view.getUint16(lp + 26, true);
    const extraLen = view.getUint16(lp + 28, true);
    const start = lp + 30 + nameLen + extraLen;
    const raw = data.subarray(start, start + entry.compressed);
    if (entry.method === 0) return raw.slice();
    if (entry.method === 8) return inflateRaw(raw, entry.size);
    throw new Error("zip: 未対応の圧縮方式です");
  };

  return {
    names: [...entries.keys()],
    has: (name: string) => entries.has(name),
    bytes,
    text: (name: string) => {
      const b = bytes(name);
      return b ? zipDecoder.decode(b) : null;
    },
  };
}

/** 文字列を UTF-8 バイト列にする（importers から使う） */
export function utf8Bytes(text: string): Uint8Array {
  return zipEncoder.encode(text);
}
