// ─────────────────────────────────────────────────────────────────────────────
// 表計算エンジン（Svelte 非依存 = 単体で検証できる純ロジック）
//
// 保存形式は「HTML の table」を維持する（既存データ・検索・書き出しと互換）:
//   <table data-sheet="1" data-freeze="1">
//     <colgroup><col style="width:120px">…</colgroup>
//     <tr><td data-f="=SUM(A1:A3)" data-nf="#,##0" data-b="1" data-al="right">120</td></tr>
//   </table>
//   data-f   生入力（数式）      data-nf  表示形式
//   data-b/i/u/s  太字・斜体・下線・取り消し線
//   data-al  水平配置（left/center/right）  data-color / data-bg  文字色・塗り
//   data-wrap 折り返し
//
// 数式は Excel 互換の構文（A1 参照・範囲・比較演算・文字列連結 &・60 以上の関数）。
// ─────────────────────────────────────────────────────────────────────────────

export type CellValue = number | string | boolean;
export type Grid = string[][];
export type ValueGrid = CellValue[][];

export const SHEET_ROWS = 200;
export const SHEET_COLS = 26;

/** 0 -> A, 25 -> Z, 26 -> AA */
export function colLabel(index: number): string {
  let n = index + 1;
  let label = "";
  while (n > 0) {
    const rem = (n - 1) % 26;
    label = String.fromCharCode(65 + rem) + label;
    n = Math.floor((n - 1) / 26);
  }
  return label;
}

/** A -> 0, AA -> 26（不正なら -1） */
export function colIndex(label: string): number {
  if (!/^[A-Z]+$/i.test(label)) return -1;
  let n = 0;
  for (const ch of label.toUpperCase()) n = n * 26 + (ch.charCodeAt(0) - 64);
  return n - 1;
}

/** "B3" -> { r: 2, c: 1 }（不正なら null） */
export function refToPos(ref: string): { r: number; c: number } | null {
  const m = /^\$?([A-Za-z]+)\$?(\d+)$/.exec(ref.trim());
  if (!m) return null;
  const c = colIndex(m[1]);
  const r = Number(m[2]) - 1;
  if (c < 0 || r < 0) return null;
  return { r, c };
}

export const cellRef = (r: number, c: number): string => `${colLabel(c)}${r + 1}`;

// ── エラー値 ────────────────────────────────────────────────────────────────
export const ERR = {
  ref: "#REF!",
  div: "#DIV/0!",
  cycle: "#CYCLE!",
  name: "#NAME?",
  num: "#NUM!",
  value: "#VALUE!",
  na: "#N/A",
  err: "#ERR!",
} as const;

export const isError = (v: unknown): v is string =>
  typeof v === "string" && v.startsWith("#") && /[!?]$/.test(v);

// ── 表示形式（数値の書式） ──────────────────────────────────────────────────
export const NUMBER_FORMATS = [
  "general",
  "0",
  "#,##0",
  "0.00",
  "#,##0.00",
  "0%",
  "0.00%",
  "¥#,##0",
  "¥#,##0.00",
  "$#,##0.00",
  "date",
  "datetime",
  "text",
] as const;
export type NumberFormat = (typeof NUMBER_FORMATS)[number];

const pad2 = (n: number) => String(n).padStart(2, "0");

/** Excel 互換の日付シリアル（1899-12-30 = 0） */
export function dateToSerial(d: Date): number {
  const utc = Date.UTC(d.getFullYear(), d.getMonth(), d.getDate());
  return Math.round((utc - Date.UTC(1899, 11, 30)) / 86400000);
}

export function serialToDate(serial: number): Date {
  const base = Date.UTC(1899, 11, 30) + Math.round(serial) * 86400000;
  const d = new Date(base);
  return new Date(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate());
}

function group(intPart: string): string {
  return intPart.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

/** セルの値を書式に沿って文字列化する */
export function formatCell(v: CellValue, nf: string = "general"): string {
  if (typeof v === "boolean") return v ? "TRUE" : "FALSE";
  if (isError(v)) return v;
  if (typeof v === "string") return v;
  if (!Number.isFinite(v)) return ERR.err;

  const fmt = nf || "general";
  if (fmt === "general" || fmt === "text") {
    if (fmt === "text") return String(v);
    const rounded = Math.round(v * 1e10) / 1e10;
    return String(rounded);
  }
  if (fmt === "date") {
    const d = serialToDate(v);
    return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
  }
  if (fmt === "datetime") {
    const d = serialToDate(v);
    const frac = Math.round((v - Math.floor(v)) * 24 * 60);
    return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())} ${pad2(Math.floor(frac / 60))}:${pad2(frac % 60)}`;
  }

  const m = /^([^\d#]*)([#,##0.]+)(%?)$/.exec(fmt);
  if (!m) return String(v);
  const [, prefix, pattern, percent] = m;
  const decimals = pattern.includes(".") ? (pattern.split(".")[1] ?? "").length : 0;
  const thousands = pattern.includes(",");
  let n = percent ? v * 100 : v;
  const fixed = Math.abs(n).toFixed(decimals);
  n = Number(fixed);
  let [intPart, decPart] = fixed.split(".");
  if (thousands) intPart = group(intPart);
  const body = decPart ? `${intPart}.${decPart}` : intPart;
  const sign = n < 0 && Number(fixed) !== 0 ? "-" : "";
  return `${sign}${prefix}${body}${percent ? "%" : ""}`;
}

/** 後方互換: 書式なしの整形 */
export function formatValue(v: CellValue): string {
  return formatCell(v, "general");
}

// ── セルの書式 ──────────────────────────────────────────────────────────────
export interface CellStyle {
  b?: boolean;
  i?: boolean;
  u?: boolean;
  s?: boolean;
  align?: "left" | "center" | "right";
  color?: string;
  bg?: string;
  wrap?: boolean;
  nf?: string;
}

export interface SheetModel {
  grid: Grid;
  styles: (CellStyle | null)[][];
  /** 列幅（px）。未設定の列は既定幅 */
  widths: number[];
  /** 先頭行を固定表示する */
  freeze: boolean;
  /** シート名（xlsx 取り込み時に使う） */
  name?: string;
}

export const DEFAULT_COL_WIDTH = 108;

export function emptyGrid(rows = SHEET_ROWS, cols = SHEET_COLS): Grid {
  return Array.from({ length: rows }, () => Array.from({ length: cols }, () => ""));
}

export function emptyStyles(rows = SHEET_ROWS, cols = SHEET_COLS): (CellStyle | null)[][] {
  return Array.from({ length: rows }, () => Array.from({ length: cols }, () => null));
}

export function emptyModel(rows = SHEET_ROWS, cols = SHEET_COLS): SheetModel {
  return { grid: emptyGrid(rows, cols), styles: emptyStyles(rows, cols), widths: [], freeze: true };
}

// ── 評価 ────────────────────────────────────────────────────────────────────
type Scalar = number | string | boolean;
interface RangeValue {
  __range: true;
  cells: Scalar[];
  rows: Scalar[][];
  r0: number;
  c0: number;
  r1: number;
  c1: number;
}
type Value = Scalar | RangeValue;

const isRange = (v: Value): v is RangeValue => typeof v === "object" && v !== null && "__range" in v;

/** 範囲を平坦化（関数の引数として受け取ったとき用） */
function flatten(values: Value[]): Scalar[] {
  const out: Scalar[] = [];
  for (const v of values) {
    if (isRange(v)) out.push(...v.cells);
    else out.push(v);
  }
  return out;
}

function first(v: Value): Scalar {
  if (isRange(v)) return v.cells[0] ?? "";
  return v;
}

function toNumberValue(v: Value): number | null {
  const s = first(v);
  if (typeof s === "number") return Number.isFinite(s) ? s : null;
  if (typeof s === "boolean") return s ? 1 : 0;
  if (isError(s)) return null;
  const t = String(s).trim().replace(/,/g, "").replace(/^¥|^\$|^€|^£/, "");
  if (t === "") return 0;
  const pct = /^([-+]?\d*\.?\d+)%$/.exec(t);
  if (pct) return Number(pct[1]) / 100;
  const n = Number(t);
  return Number.isFinite(n) ? n : null;
}

function toNumber(v: Value): number {
  const n = toNumberValue(v);
  return n === null ? 0 : n;
}

function toText(v: Value): string {
  const s = first(v);
  if (typeof s === "number") return formatCell(s, "general");
  if (typeof s === "boolean") return s ? "TRUE" : "FALSE";
  return String(s);
}

function truthy(v: Value): boolean {
  const s = first(v);
  if (typeof s === "boolean") return s;
  if (typeof s === "number") return s !== 0;
  const u = String(s).trim().toUpperCase();
  if (u === "TRUE") return true;
  if (u === "FALSE" || u === "") return false;
  const n = toNumberValue(s);
  return n === null ? true : n !== 0;
}

function findError(values: Value[]): string | null {
  for (const v of flatten(values)) if (isError(v)) return v;
  return null;
}

const numsOf = (values: Value[]): number[] =>
  flatten(values)
    .map((s) => {
      if (typeof s === "number") return s;
      if (typeof s === "boolean") return s ? 1 : 0;
      if (typeof s === "string" && s.trim() !== "" && !isError(s)) {
        const n = toNumberValue(s);
        return n === null ? null : n;
      }
      return null;
    })
    .filter((n): n is number => n !== null && Number.isFinite(n));

// ── 数式の評価 ──────────────────────────────────────────────────────────────
export type Resolver = (r: number, c: number) => CellValue;

interface Ctx {
  valueAt: Resolver;
  /** 参照範囲の外側を指したときに #REF! を出すための境界 */
  rows: number;
  cols: number;
  depth: number;
}

/** グリッド全体を評価する（循環参照は #CYCLE!） */
export function evaluateGrid(grid: Grid): ValueGrid {
  const rows = grid.length;
  const cols = grid[0]?.length ?? 0;
  const cache = new Map<string, CellValue>();
  const visiting = new Set<string>();

  const valueAt: Resolver = (r, c) => {
    if (r < 0 || c < 0 || r >= rows || c >= cols) return ERR.ref;
    const key = `${r}:${c}`;
    const cached = cache.get(key);
    if (cached !== undefined) return cached;
    const text = String(grid[r]?.[c] ?? "").trim();
    if (text === "") {
      cache.set(key, "");
      return "";
    }
    if (!text.startsWith("=")) {
      const v: CellValue = isNumericText(text) ? Number(text.replace(/,/g, "")) : text;
      cache.set(key, v);
      return v;
    }
    if (visiting.has(key)) return ERR.cycle;
    visiting.add(key);
    let out: CellValue;
    try {
      out = evaluateFormula(text.slice(1), valueAt, { rows, cols });
    } catch (e) {
      out = isError((e as Error)?.message) ? ((e as Error).message as CellValue) : ERR.err;
    }
    visiting.delete(key);
    cache.set(key, out);
    return out;
  };

  return grid.map((_, r) => grid[r].map((__, c) => valueAt(r, c)));
}

export function isNumericText(text: string): boolean {
  const t = text.trim().replace(/,/g, "");
  return t !== "" && Number.isFinite(Number(t));
}

/** 数式（先頭の = を除いた部分）を評価する */
export function evaluateFormula(src: string, valueAt: Resolver, bounds?: { rows: number; cols: number }): CellValue {
  const ctx: Ctx = { valueAt, rows: bounds?.rows ?? 1e6, cols: bounds?.cols ?? 1e6, depth: 0 };
  const p = new Parser(src, ctx);
  const v = p.parseExpression();
  p.expectEnd();
  const s = first(v);
  if (isRange(v)) return (v.cells[0] ?? "") as CellValue;
  if (typeof s === "number" && !Number.isFinite(s)) return ERR.num;
  return s as CellValue;
}

class Parser {
  private i = 0;
  constructor(
    private readonly s: string,
    private readonly ctx: Ctx,
  ) {}

  // --- 字句 ---------------------------------------------------------------
  private skip(): void {
    while (this.i < this.s.length && /\s/.test(this.s[this.i])) this.i += 1;
  }

  private peek(): string {
    this.skip();
    return this.s[this.i] ?? "";
  }

  private eat(ch: string): boolean {
    this.skip();
    if (this.s[this.i] === ch) {
      this.i += 1;
      return true;
    }
    return false;
  }

  private eatOp(op: string): boolean {
    this.skip();
    if (this.s.startsWith(op, this.i)) {
      // "=" が ">=" の一部でないことを保証する
      this.i += op.length;
      return true;
    }
    return false;
  }

  // --- 構文 ---------------------------------------------------------------
  parseExpression(): Value {
    return this.parseComparison();
  }

  expectEnd(): void {
    this.skip();
    if (this.i < this.s.length) throw new Error(ERR.err);
  }

  private parseComparison(): Value {
    let left = this.parseConcat();
    for (;;) {
      this.skip();
      const op = /^(<=|>=|<>|=|<|>)/.exec(this.s.slice(this.i))?.[1];
      if (!op) return left;
      this.i += op.length;
      const right = this.parseConcat();
      const err = findError([left, right]);
      if (err) return err;
      const a = first(left);
      const b = first(right);
      const bothNum = toNumberValue(left) !== null && toNumberValue(right) !== null &&
        (typeof a === "number" || typeof b === "number");
      let cmp: number;
      if (bothNum) {
        const x = toNumber(left);
        const y = toNumber(right);
        cmp = x < y ? -1 : x > y ? 1 : 0;
      } else {
        const x = toText(left).toUpperCase();
        const y = toText(right).toUpperCase();
        cmp = x < y ? -1 : x > y ? 1 : 0;
      }
      left = op === "=" ? cmp === 0
        : op === "<>" ? cmp !== 0
        : op === "<" ? cmp < 0
        : op === ">" ? cmp > 0
        : op === "<=" ? cmp <= 0
        : cmp >= 0;
    }
  }

  private parseConcat(): Value {
    let left = this.parseAdditive();
    for (;;) {
      if (!this.eatOp("&")) return left;
      const right = this.parseAdditive();
      const err = findError([left, right]);
      if (err) return err;
      left = toText(left) + toText(right);
    }
  }

  private parseAdditive(): Value {
    let left = this.parseMultiplicative();
    for (;;) {
      const ch = this.peek();
      if (ch !== "+" && ch !== "-") return left;
      this.i += 1;
      const right = this.parseMultiplicative();
      const err = findError([left, right]);
      if (err) return err;
      const a = toNumberValue(left);
      const b = toNumberValue(right);
      if (a === null || b === null) return ERR.value;
      left = ch === "+" ? a + b : a - b;
    }
  }

  private parseMultiplicative(): Value {
    let left = this.parsePower();
    for (;;) {
      const ch = this.peek();
      if (ch !== "*" && ch !== "/") return left;
      this.i += 1;
      const right = this.parsePower();
      const err = findError([left, right]);
      if (err) return err;
      const a = toNumberValue(left);
      const b = toNumberValue(right);
      if (a === null || b === null) return ERR.value;
      if (ch === "/" && b === 0) return ERR.div;
      left = ch === "*" ? a * b : a / b;
    }
  }

  private parsePower(): Value {
    let left = this.parseUnary();
    while (this.eatOp("^")) {
      const right = this.parseUnary();
      const err = findError([left, right]);
      if (err) return err;
      const a = toNumberValue(left);
      const b = toNumberValue(right);
      if (a === null || b === null) return ERR.value;
      const out = a ** b;
      if (!Number.isFinite(out)) return ERR.num;
      left = out;
    }
    return left;
  }

  private parseUnary(): Value {
    if (this.eatOp("-")) {
      const v = this.parseUnary();
      const err = findError([v]);
      if (err) return err;
      const n = toNumberValue(v);
      return n === null ? ERR.value : -n;
    }
    if (this.eatOp("+")) {
      const v = this.parseUnary();
      const n = toNumberValue(v);
      return n === null ? ERR.value : n;
    }
    return this.parsePostfix();
  }

  /** 100% のような後置 % と、値の直後の %（A1%）に対応 */
  private parsePostfix(): Value {
    let v = this.parsePrimary();
    while (this.eatOp("%")) {
      const n = toNumberValue(v);
      if (n === null) return ERR.value;
      v = n / 100;
    }
    return v;
  }

  private parsePrimary(): Value {
    this.skip();
    const ch = this.s[this.i] ?? "";

    if (ch === "(") {
      this.i += 1;
      const v = this.parseExpression();
      if (!this.eat(")")) throw new Error(ERR.err);
      return v;
    }

    if (ch === '"') return this.readString();

    // 数値リテラル
    const numMatch = /^\d+(\.\d+)?([eE][+-]?\d+)?|^\.\d+/.exec(this.s.slice(this.i));
    if (numMatch) {
      this.i += numMatch[0].length;
      return Number(numMatch[0]);
    }

    // 参照 / 範囲 / 関数 / 名前
    const ident = /^(\$?[A-Za-z]{1,3}\$?\d+)(:(\$?[A-Za-z]{1,3}\$?\d+))?/.exec(this.s.slice(this.i));
    if (ident) {
      const start = refToPos(ident[1].replace(/\$/g, ""));
      if (start) {
        this.i += ident[0].length;
        const end = ident[3] ? refToPos(ident[3].replace(/\$/g, "")) : start;
        if (!end) throw new Error(ERR.ref);
        return this.range(start.r, start.c, end.r, end.c);
      }
    }

    const nameMatch = /^([A-Za-z_][A-Za-z0-9_.]*)\s*\(/.exec(this.s.slice(this.i));
    if (nameMatch) {
      this.i += nameMatch[0].length;
      const args: Value[] = [];
      if (!this.eat(")")) {
        for (;;) {
          this.skip();
          if (this.peek() === ")" || this.peek() === ",") args.push("");
          else args.push(this.parseExpression());
          if (this.eat(",")) continue;
          if (this.eat(")")) break;
          throw new Error(ERR.err);
        }
      }
      return callFunction(nameMatch[1], args, this.ctx);
    }

    // 真偽値
    const boolMatch = /^(TRUE|FALSE)\b/i.exec(this.s.slice(this.i));
    if (boolMatch) {
      this.i += boolMatch[0].length;
      return boolMatch[1].toUpperCase() === "TRUE";
    }

    throw new Error(ERR.name);
  }

  private readString(): string {
    // 先頭の " を読み飛ばす
    this.i += 1;
    let out = "";
    for (;;) {
      const ch = this.s[this.i];
      if (ch === undefined) throw new Error(ERR.err);
      if (ch === '"') {
        if (this.s[this.i + 1] === '"') {
          out += '"';
          this.i += 2;
          continue;
        }
        this.i += 1;
        return out;
      }
      out += ch;
      this.i += 1;
    }
  }

  private range(r0: number, c0: number, r1: number, c1: number): RangeValue {
    const top = Math.min(r0, r1);
    const bottom = Math.max(r0, r1);
    const left = Math.min(c0, c1);
    const right = Math.max(c0, c1);
    if ((bottom - top + 1) * (right - left + 1) > 40000) throw new Error(ERR.ref);
    const rows: Scalar[][] = [];
    const cells: Scalar[] = [];
    for (let r = top; r <= bottom; r += 1) {
      const row: Scalar[] = [];
      for (let c = left; c <= right; c += 1) {
        const v = this.ctx.valueAt(r, c) as Scalar;
        row.push(v);
        cells.push(v);
      }
      rows.push(row);
    }
    return { __range: true, cells, rows, r0: top, c0: left, r1: bottom, c1: right };
  }
}

// ── 関数ライブラリ ──────────────────────────────────────────────────────────
const roundTo = (v: number, d: number) => {
  const f = 10 ** Math.max(-12, Math.min(15, Math.trunc(d)));
  return Math.round(v * f) / f;
};

function criteriaMatcher(crit: Value): (v: Scalar) => boolean {
  const raw = first(crit);
  const text = typeof raw === "string" ? raw.trim() : String(raw);
  const m = /^(<=|>=|<>|=|<|>)(.*)$/.exec(text);
  if (m) {
    const [, op, restRaw] = m;
    const rest = restRaw.trim();
    const numRest = rest === "" ? null : Number(rest.replace(/,/g, ""));
    return (v) => {
      let cmp: number;
      if (numRest !== null && Number.isFinite(numRest) && typeof v === "number") {
        cmp = v < numRest ? -1 : v > numRest ? 1 : 0;
      } else {
        const a = String(v).toUpperCase();
        const b = rest.toUpperCase();
        cmp = a < b ? -1 : a > b ? 1 : 0;
      }
      switch (op) {
        case "=": return cmp === 0;
        case "<>": return cmp !== 0;
        case "<": return cmp < 0;
        case ">": return cmp > 0;
        case "<=": return cmp <= 0;
        default: return cmp >= 0;
      }
    };
  }
  if (text.includes("*") || text.includes("?")) {
    const re = new RegExp(
      `^${text.replace(/[.+^${}()|[\]\\]/g, "\\$&").replace(/\*/g, ".*").replace(/\?/g, ".")}$`,
      "i",
    );
    return (v) => re.test(String(v));
  }
  const numText = Number(text.replace(/,/g, ""));
  return (v) => (typeof v === "number" && Number.isFinite(numText) ? v === numText : String(v).toUpperCase() === text.toUpperCase());
}

function callFunction(rawName: string, args: Value[], ctx: Ctx): Value {
  const name = rawName.toUpperCase();
  if (ctx.depth > 40) return ERR.err;
  ctx.depth += 1;
  try {
    return fn(name, args);
  } finally {
    ctx.depth -= 1;
  }
}

function fn(name: string, args: Value[]): Value {
  // 引数に含まれるエラーは伝播させる（IFERROR / ISERROR 系を除く）
  if (!["IFERROR", "IFNA", "ISERROR", "ISERR", "ISNA", "IF"].includes(name)) {
    const err = findError(args);
    if (err) return err;
  }

  const nums = numsOf(args);
  const sum = nums.reduce((a, b) => a + b, 0);

  /** 引数を「スカラー数値」として取り出す（範囲が来ても先頭セルを見る） */
  const argN = (idx: number, dflt = 0): number => {
    const v = toNumberValue(args[idx] ?? "");
    return v === null || !Number.isFinite(v) ? dflt : v;
  };

  switch (name) {
    // --- 集計 ---
    case "SUM": return sum;
    case "PRODUCT": return nums.length ? nums.reduce((a, b) => a * b, 1) : 0;
    case "AVERAGE":
    case "AVG": return nums.length ? sum / nums.length : ERR.div;
    case "COUNT": return nums.length;
    case "COUNTA": return flatten(args).filter((v) => v !== "" && v !== null && v !== undefined).length;
    case "COUNTBLANK": return flatten(args).filter((v) => v === "").length;
    case "MIN": return nums.length ? Math.min(...nums) : 0;
    case "MAX": return nums.length ? Math.max(...nums) : 0;
    case "MEDIAN": {
      if (!nums.length) return ERR.num;
      const s = [...nums].sort((a, b) => a - b);
      const mid = Math.floor(s.length / 2);
      return s.length % 2 ? s[mid] : (s[mid - 1] + s[mid]) / 2;
    }
    case "STDEV":
    case "STDEVP": {
      if (nums.length < 2) return ERR.div;
      const mean = sum / nums.length;
      const variance = nums.reduce((a, b) => a + (b - mean) ** 2, 0) / (name === "STDEV" ? nums.length - 1 : nums.length);
      return Math.sqrt(variance);
    }
    case "SUMPRODUCT": {
      const arrays = args
        .filter(isRange)
        .map((r) => r.cells.map((v) => toNumberValue(v as Value) ?? 0));
      if (!arrays.length) return sum;
      const len = Math.max(...arrays.map((a) => a.length));
      let total = 0;
      for (let i = 0; i < len; i += 1) total += arrays.reduce((p, a) => p * (a[i] ?? 0), 1);
      return total;
    }

    // --- 条件つき集計 ---
    case "SUMIF":
    case "AVERAGEIF":
    case "COUNTIF": {
      const target = args[0];
      const crit = args[1];
      const values: Scalar[] = isRange(target) ? target.cells : flatten([target]);
      const match = criteriaMatcher(crit);
      if (name === "COUNTIF") return values.filter(match).length;
      const sumRange = args[2] ? flatten([args[2]]) : values;
      const picked = values
        .map((v, i) => (match(v) ? (toNumberValue(sumRange[i] ?? "") ?? 0) : null))
        .filter((n): n is number => n !== null);
      if (!picked.length) return name === "SUMIF" ? 0 : ERR.div;
      return name === "SUMIF" ? picked.reduce((a, b) => a + b, 0) : picked.reduce((a, b) => a + b, 0) / picked.length;
    }
    case "SUMIFS": {
      const sumRange = flatten([args[0]]);
      let total = 0;
      for (let i = 0; i < sumRange.length; i += 1) {
        let ok = true;
        for (let k = 1; k + 1 < args.length + 1; k += 2) {
          const rangeV = args[k];
          const crit = args[k + 1];
          if (!rangeV || crit === undefined) break;
          const cells = flatten([rangeV]);
          if (!criteriaMatcher(crit)(cells[i] ?? "")) { ok = false; break; }
        }
        if (ok) total += toNumberValue(sumRange[i] ?? "") ?? 0;
      }
      return total;
    }
    case "COUNTIFS": {
      const first = flatten([args[0]]);
      let count = 0;
      for (let i = 0; i < first.length; i += 1) {
        let ok = true;
        for (let k = 0; k + 1 < args.length; k += 2) {
          const cells = flatten([args[k]]);
          if (!criteriaMatcher(args[k + 1])(cells[i] ?? "")) { ok = false; break; }
        }
        if (ok) count += 1;
      }
      return count;
    }

    // --- 数学 ---
    case "ABS": return Math.abs(argN(0));
    case "ROUND": return roundTo(argN(0), argN(1));
    case "ROUNDUP": {
      const f = 10 ** Math.trunc(argN(1));
      const v = argN(0);
      return (v < 0 ? -Math.ceil(Math.abs(v) * f) : Math.ceil(v * f)) / f;
    }
    case "ROUNDDOWN": {
      const f = 10 ** Math.trunc(argN(1));
      const v = argN(0);
      return (v < 0 ? -Math.floor(Math.abs(v) * f) : Math.floor(v * f)) / f;
    }
    case "INT": return Math.floor(argN(0));
    case "TRUNC": return Math.trunc(argN(0));
    case "MOD": return (argN(1, 1)) === 0 ? ERR.div : (argN(0)) % (argN(1, 1));
    case "POWER": return (argN(0)) ** (argN(1, 1));
    case "SQRT": return (argN(0)) < 0 ? ERR.num : Math.sqrt(argN(0));
    case "EXP": return Math.exp(argN(0));
    case "LN": return (argN(0)) <= 0 ? ERR.num : Math.log(argN(0));
    case "LOG10": return (argN(0)) <= 0 ? ERR.num : Math.log10(argN(0));
    case "PI": return Math.PI;
    case "SIGN": return Math.sign(argN(0));

    // --- 論理 ---
    case "IF": {
      const cond = args[0];
      if (isError(first(cond ?? ""))) return first(cond ?? "");
      return truthy(cond) ? (args[1] ?? "") : (args[2] ?? "");
    }
    case "AND": return flatten(args).every((v) => truthy(v));
    case "OR": return flatten(args).some((v) => truthy(v));
    case "NOT": return !truthy(args[0] ?? false);
    case "XOR": return flatten(args).filter((v) => truthy(v)).length % 2 === 1;
    case "IFERROR": {
      const v = first(args[0] ?? "");
      return isError(v) ? (args[1] ?? "") : v;
    }
    case "IFNA": {
      const v = first(args[0] ?? "");
      return v === ERR.na ? (args[1] ?? "") : v;
    }
    case "ISERROR": return isError(first(args[0] ?? ""));
    case "ISERR": return isError(first(args[0] ?? "")) && first(args[0] ?? "") !== ERR.na;
    case "ISNA": return first(args[0] ?? "") === ERR.na;
    case "ISBLANK": return first(args[0] ?? "") === "";
    case "ISNUMBER": return typeof first(args[0] ?? "") === "number";
    case "ISTEXT": return typeof first(args[0] ?? "") === "string" && first(args[0] ?? "") !== "";

    // --- 文字列 ---
    case "LEN": return toText(args[0] ?? "").length;
    case "LEFT": return toText(args[0] ?? "").slice(0, Math.max(0, argN(1, 1)));
    case "RIGHT": {
      const s = toText(args[0] ?? "");
      const n = Math.max(0, argN(1, 1));
      return n === 0 ? "" : s.slice(-n);
    }
    case "MID": {
      const s = toText(args[0] ?? "");
      const start = Math.max(1, Math.trunc(argN(1, 1)));
      const len = Math.max(0, Math.trunc(argN(2)));
      return s.slice(start - 1, start - 1 + len);
    }
    case "UPPER": return toText(args[0] ?? "").toUpperCase();
    case "LOWER": return toText(args[0] ?? "").toLowerCase();
    case "PROPER": return toText(args[0] ?? "").replace(/\w\S*/g, (w) => w[0].toUpperCase() + w.slice(1).toLowerCase());
    case "TRIM": return toText(args[0] ?? "").trim().replace(/\s+/g, " ");
    case "CONCAT": return flatten(args).map((v) => String(v)).join("");
    case "CONCATENATE": return args.map((v) => toText(v)).join("");
    case "TEXTJOIN": {
      const sep = toText(args[0] ?? "");
      const ignoreEmpty = truthy(args[1] ?? true);
      const parts = flatten(args.slice(2)).map((v) => String(v)).filter((s) => !ignoreEmpty || s !== "");
      return parts.join(sep);
    }
    case "REPT": return toText(args[0] ?? "").repeat(Math.max(0, Math.min(1000, Math.trunc(argN(1)))));
    case "SUBSTITUTE": {
      const s = toText(args[0] ?? "");
      const a = toText(args[1] ?? "");
      const b = toText(args[2] ?? "");
      return a === "" ? s : s.split(a).join(b);
    }
    case "VALUE": {
      const n = toNumberValue(args[0] ?? "");
      return n === null ? ERR.value : n;
    }
    case "TEXT": {
      const v = first(args[0] ?? "");
      const fmt = toText(args[1] ?? "general");
      if (typeof v === "number") return formatCell(v, fmt);
      return String(v);
    }
    case "EXACT": return toText(args[0] ?? "") === toText(args[1] ?? "");

    // --- 検索・参照 ---
    case "VLOOKUP": {
      const needle = first(args[0] ?? "");
      const table = args[1];
      if (!isRange(table)) return ERR.na;
      // VLOOKUP(検索値, 範囲, 列番号, [検索方法]) — 列番号は 3 番目の引数
      const colIdx = Math.max(1, Math.trunc(argN(2, 1)));
      const exact = args.length > 3 ? !truthy(args[3]) : true;
      const key = typeof needle === "number" ? needle : String(needle).toUpperCase();
      let hit: Scalar[] | null = null;
      if (exact) {
        for (const row of table.rows) {
          const cell = row[0] ?? "";
          const same = typeof key === "number"
            ? typeof cell === "number" && cell === key
            : String(cell).toUpperCase() === key;
          if (same) { hit = row; break; }
        }
      } else {
        // 近似一致: キー以下で最大の行（表は昇順である前提 = Excel と同じ）
        for (const row of table.rows) {
          const cell = row[0] ?? "";
          const cmp = typeof key === "number"
            ? (typeof cell === "number" ? cell - key : 1)
            : (String(cell).toUpperCase() <= key ? -1 : 1);
          if (cmp <= 0) hit = row;
          else break;
        }
      }
      if (!hit) return ERR.na;
      return hit[colIdx - 1] ?? "";
    }
    case "HLOOKUP": {
      const needle = toText(args[0] ?? "").toUpperCase();
      const table = args[1];
      if (!isRange(table)) return ERR.na;
      const rowIdx = Math.max(1, Math.trunc(argN(1, 1))) - 1;
      const head = table.rows[0] ?? [];
      const col = head.findIndex((v) => String(v).toUpperCase() === needle);
      if (col < 0) return ERR.na;
      return table.rows[rowIdx]?.[col] ?? "";
    }
    case "INDEX": {
      const table = args[0];
      if (!isRange(table)) return ERR.ref;
      // INDEX(範囲, 行番号, [列番号])
      const r = Math.max(1, Math.trunc(argN(1, 1))) - 1;
      const c = Math.max(1, Math.trunc(argN(2, 1))) - 1;
      const row = table.rows[r];
      if (!row) return ERR.ref;
      return row[c] ?? "";
    }
    case "MATCH": {
      const needle = first(args[0] ?? "");
      const values = flatten([args[1] ?? ""]);
      const key = typeof needle === "string" ? needle.toUpperCase() : needle;
      const idx = values.findIndex((v) =>
        typeof key === "number" ? toNumberValue(v as Value) === key : String(v).toUpperCase() === key,
      );
      return idx < 0 ? ERR.na : idx + 1;
    }
    case "ROW": return isRange(args[0] as Value) ? (args[0] as RangeValue).r0 + 1 : 1;
    case "COLUMN": return isRange(args[0] as Value) ? (args[0] as RangeValue).c0 + 1 : 1;
    case "ROWS": return isRange(args[0] as Value) ? (args[0] as RangeValue).rows.length : 1;
    case "COLUMNS": return isRange(args[0] as Value) ? (args[0] as RangeValue).rows[0]?.length ?? 1 : 1;

    // --- 日付 ---
    case "TODAY": return dateToSerial(new Date());
    case "NOW": {
      const now = new Date();
      return dateToSerial(now) + (now.getHours() * 60 + now.getMinutes()) / 1440;
    }
    case "DATE": {
      const y = Math.trunc(argN(0, 1970));
      const m = Math.trunc(argN(1, 1)) - 1;
      const d = Math.trunc(argN(2, 1));
      return dateToSerial(new Date(y, m, d));
    }
    case "YEAR": return serialToDate(toNumber(args[0] ?? 0)).getFullYear();
    case "MONTH": return serialToDate(toNumber(args[0] ?? 0)).getMonth() + 1;
    case "DAY": return serialToDate(toNumber(args[0] ?? 0)).getDate();
    case "WEEKDAY": {
      const day = serialToDate(toNumber(args[0] ?? 0)).getDay();
      return truthy(args[1] ?? false) ? (day === 0 ? 7 : day) : day + 1;
    }
    case "DAYS": return toNumber(args[0] ?? 0) - toNumber(args[1] ?? 0);
    case "EDATE": {
      const d = serialToDate(toNumber(args[0] ?? 0));
      const months = Math.trunc(argN(1));
      return dateToSerial(new Date(d.getFullYear(), d.getMonth() + months, d.getDate()));
    }

    default:
      return ERR.name;
  }
}

/** 対応している関数名（UI のヒント用） */
export const SUPPORTED_FUNCTIONS = [
  "SUM", "PRODUCT", "AVERAGE", "COUNT", "COUNTA", "COUNTBLANK", "MIN", "MAX", "MEDIAN", "STDEV", "SUMPRODUCT",
  "SUMIF", "SUMIFS", "COUNTIF", "COUNTIFS", "AVERAGEIF",
  "ABS", "ROUND", "ROUNDUP", "ROUNDDOWN", "INT", "TRUNC", "MOD", "POWER", "SQRT", "EXP", "LN", "LOG10", "PI", "SIGN",
  "IF", "IFERROR", "IFNA", "AND", "OR", "NOT", "XOR", "ISERROR", "ISBLANK", "ISNUMBER", "ISNA",
  "LEN", "LEFT", "RIGHT", "MID", "UPPER", "LOWER", "PROPER", "TRIM", "CONCAT", "CONCATENATE", "TEXTJOIN", "REPT",
  "SUBSTITUTE", "VALUE", "TEXT", "EXACT",
  "VLOOKUP", "HLOOKUP", "INDEX", "MATCH", "ROW", "COLUMN", "ROWS", "COLUMNS",
  "TODAY", "NOW", "DATE", "YEAR", "MONTH", "DAY", "WEEKDAY", "DAYS", "EDATE",
] as const;

// ── シリアライズ ────────────────────────────────────────────────────────────
const escapeHtml = (t: string) =>
  t.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

function styleAttrs(st: CellStyle | null | undefined): string {
  if (!st) return "";
  const parts: string[] = [];
  if (st.b) parts.push('data-b="1"');
  if (st.i) parts.push('data-i="1"');
  if (st.u) parts.push('data-u="1"');
  if (st.s) parts.push('data-s="1"');
  if (st.align) parts.push(`data-al="${st.align}"`);
  if (st.color) parts.push(`data-color="${escapeHtml(st.color)}"`);
  if (st.bg) parts.push(`data-bg="${escapeHtml(st.bg)}"`);
  if (st.wrap) parts.push('data-wrap="1"');
  if (st.nf && st.nf !== "general") parts.push(`data-nf="${escapeHtml(st.nf)}"`);
  return parts.length ? ` ${parts.join(" ")}` : "";
}

/** モデル → HTML（値はテキスト、数式は data-f 属性） */
export function modelToHtml(model: SheetModel, values: ValueGrid): string {
  const cols = model.grid[0]?.length ?? 0;
  const colgroup = model.widths.some((w) => w > 0)
    ? `<colgroup>${Array.from({ length: cols }, (_, c) =>
        `<col${model.widths[c] ? ` style="width:${Math.round(model.widths[c])}px"` : ""}>`).join("")}</colgroup>`
    : "";
  const rows = values
    .map((row, r) => {
      const cells = row
        .map((value, c) => {
          const raw = model.grid[r]?.[c] ?? "";
          const st = model.styles[r]?.[c] ?? null;
          const shown = formatCell(value, st?.nf ?? "general");
          const attrs = styleAttrs(st);
          if (raw.startsWith("=")) return `<td data-f="${escapeHtml(raw)}"${attrs}>${escapeHtml(shown)}</td>`;
          return `<td${attrs}>${escapeHtml(shown)}</td>`;
        })
        .join("");
      return `<tr>${cells}</tr>`;
    })
    .join("");
  const head = `data-sheet="1"${model.freeze ? ' data-freeze="1"' : ""}${model.name ? ` data-name="${escapeHtml(model.name)}"` : ""}`;
  return `<table ${head}>${colgroup}${rows}</table>`;
}

export function htmlToModel(html: string, rows = SHEET_ROWS, cols = SHEET_COLS): SheetModel {
  const model = emptyModel(rows, cols);
  if (!html.trim()) return model;
  try {
    const dom = new DOMParser().parseFromString(html, "text/html");
    const table = dom.querySelector("table");
    if (!table) return model;
    model.freeze = table.getAttribute("data-freeze") === "1";
    const name = table.getAttribute("data-name");
    if (name) model.name = name;
    Array.from(table.querySelectorAll("colgroup > col")).forEach((col, c) => {
      const w = Number((col.getAttribute("style") ?? "").replace(/[^\d.]/g, ""));
      if (Number.isFinite(w) && w > 0) model.widths[c] = w;
    });
    Array.from(table.querySelectorAll("tr")).forEach((tr, r) => {
      if (r >= rows) return;
      Array.from(tr.querySelectorAll("td,th")).forEach((td, c) => {
        if (c >= cols) return;
        const formula = td.getAttribute("data-f");
        model.grid[r][c] = formula ?? td.textContent ?? "";
        const st: CellStyle = {};
        if (td.getAttribute("data-b") === "1") st.b = true;
        if (td.getAttribute("data-i") === "1") st.i = true;
        if (td.getAttribute("data-u") === "1") st.u = true;
        if (td.getAttribute("data-s") === "1") st.s = true;
        if (td.getAttribute("data-wrap") === "1") st.wrap = true;
        const al = td.getAttribute("data-al");
        if (al === "left" || al === "center" || al === "right") st.align = al;
        const color = td.getAttribute("data-color");
        if (color) st.color = color;
        const bg = td.getAttribute("data-bg");
        if (bg) st.bg = bg;
        const nf = td.getAttribute("data-nf");
        if (nf) st.nf = nf;
        if (Object.keys(st).length) model.styles[r][c] = st;
      });
    });
  } catch {
    /* 壊れた HTML は空シートとして扱う */
  }
  return model;
}

/** 旧 API 互換: モデルなしの HTML 化 */
export function gridToHtml(grid: Grid, values: ValueGrid): string {
  return modelToHtml(
    { grid, styles: emptyStyles(grid.length, grid[0]?.length ?? 0), widths: [], freeze: false },
    values,
  );
}

/** 旧 API 互換: HTML → グリッド */
export function htmlToGrid(html: string, rows = SHEET_ROWS, cols = SHEET_COLS): Grid {
  return htmlToModel(html, rows, cols).grid;
}

/** 検索・書き出し用のプレーンテキスト（セル値をタブ区切りで） */
export function gridToText(values: ValueGrid, styles?: (CellStyle | null)[][]): string {
  return values
    .map((row, r) =>
      row
        .map((v, c) => formatCell(v, styles?.[r]?.[c]?.nf ?? "general"))
        .join("\t")
        .replace(/\t+$/, ""),
    )
    .filter((line) => line.trim() !== "")
    .join("\n");
}

// ── 範囲編集ユーティリティ ──────────────────────────────────────────────────
export interface Rect {
  r0: number;
  c0: number;
  r1: number;
  c1: number;
}

export function normalizeRect(rect: Rect): Rect {
  return {
    r0: Math.min(rect.r0, rect.r1),
    c0: Math.min(rect.c0, rect.c1),
    r1: Math.max(rect.r0, rect.r1),
    c1: Math.max(rect.c0, rect.c1),
  };
}

export function rectToRef(rect: Rect): string {
  const n = normalizeRect(rect);
  const a = cellRef(n.r0, n.c0);
  const b = cellRef(n.r1, n.c1);
  return a === b ? a : `${a}:${b}`;
}

/** 選択範囲の集計（ステータスバー用） */
export function summarize(values: ValueGrid, rect: Rect): { count: number; sum: number; average: number | null; min: number | null; max: number | null } {
  const n = normalizeRect(rect);
  const nums: number[] = [];
  for (let r = n.r0; r <= n.r1; r += 1) {
    for (let c = n.c0; c <= n.c1; c += 1) {
      const v = values[r]?.[c];
      if (typeof v === "number" && Number.isFinite(v)) nums.push(v);
    }
  }
  const sum = nums.reduce((a, b) => a + b, 0);
  return {
    count: nums.length,
    sum,
    average: nums.length ? sum / nums.length : null,
    min: nums.length ? Math.min(...nums) : null,
    max: nums.length ? Math.max(...nums) : null,
  };
}

/** 数式内の参照を相対移動させる（フィル / コピー用） */
export function adjustFormula(formula: string, dr: number, dc: number): string {
  if (!formula.startsWith("=") || (dr === 0 && dc === 0)) return formula;
  const body = formula.slice(1);
  let out = "";
  let i = 0;
  while (i < body.length) {
    const ch = body[i];
    if (ch === '"') {
      // 文字列はそのまま複写
      out += ch;
      i += 1;
      while (i < body.length) {
        out += body[i];
        if (body[i] === '"') {
          if (body[i + 1] === '"') {
            out += body[i + 1];
            i += 2;
            continue;
          }
          i += 1;
          break;
        }
        i += 1;
      }
      continue;
    }
    const m = /^(\$?)([A-Za-z]{1,3})(\$?)(\d+)/.exec(body.slice(i));
    if (m && !/[A-Za-z0-9_]/.test(body[i - 1] ?? "")) {
      const [, colAbs, colTxt, rowAbs, rowTxt] = m;
      const c = colIndex(colTxt);
      const r = Number(rowTxt) - 1;
      const nc = colAbs ? c : c + dc;
      const nr = rowAbs ? r : r + dr;
      if (nc < 0 || nr < 0) {
        out += ERR.ref;
      } else {
        out += `${colAbs}${colLabel(nc)}${rowAbs}${nr + 1}`;
      }
      i += m[0].length;
      continue;
    }
    out += ch;
    i += 1;
  }
  return `=${out}`;
}
