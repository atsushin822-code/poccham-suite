// スプレッドシートの純ロジック（Svelte 非依存 = 単体で検証しやすい）
//
// 保存形式は「HTML の table」にしてある:
//   <td data-f="=SUM(A1:A3)">120</td>
//     ↑ data-f に生入力（数式）、要素のテキストに計算結果
// こうすることで、既存の保存・検索・書き出し（HTML→md/txt）がそのまま機能する。

export type CellValue = number | string;
export type Grid = string[][];
export type ValueGrid = CellValue[][];

export const SHEET_ROWS = 40;
export const SHEET_COLS = 12;

/** 0 -> A, 25 -> Z, 26 -> AA */
export function colLabel(index: number): string {
  let n = index + 1;
  let label = "";
  while (n > 0) {
    const rem = (n - 1) % 26;
    label = String.fromCharCode(65 + rem) + label;
    n = Math.floor((n - 1) / 26);
  }
  return label;
}

/** A -> 0, AA -> 26（不正なら -1） */
export function colIndex(label: string): number {
  if (!/^[A-Z]+$/i.test(label)) return -1;
  let n = 0;
  for (const ch of label.toUpperCase()) n = n * 26 + (ch.charCodeAt(0) - 64);
  return n - 1;
}

/** "B3" -> { r: 2, c: 1 }（不正なら null） */
export function refToPos(ref: string): { r: number; c: number } | null {
  const m = /^\$?([A-Za-z]+)\$?(\d+)$/.exec(ref.trim());
  if (!m) return null;
  const c = colIndex(m[1]);
  const r = Number(m[2]) - 1;
  if (c < 0 || r < 0) return null;
  return { r, c };
}

export function toNumber(v: CellValue): number {
  if (typeof v === "number") return v;
  const t = v.trim().replace(/,/g, "");
  if (t === "") return 0;
  const n = Number(t);
  return Number.isFinite(n) ? n : 0;
}

export function isNumericText(text: string): boolean {
  const t = text.trim().replace(/,/g, "");
  return t !== "" && Number.isFinite(Number(t));
}

const ERR = {
  ref: "#REF!",
  div: "#DIV/0!",
  cycle: "#CYCLE!",
  err: "#ERR!",
  value: "#VALUE!",
};

/** 表示用の整形（小数は最大 6 桁、整数はそのまま） */
export function formatValue(v: CellValue): string {
  if (typeof v === "string") return v;
  if (!Number.isFinite(v)) return ERR.err;
  const rounded = Math.round(v * 1e6) / 1e6;
  return String(rounded);
}

/** グリッド全体を評価する（循環参照は #CYCLE!） */
export function evaluateGrid(grid: Grid): ValueGrid {
  const cache = new Map<string, CellValue>();
  const visiting = new Set<string>();

  const raw = (r: number, c: number): string => grid[r]?.[c] ?? "";

  function valueAt(r: number, c: number): CellValue {
    if (r < 0 || c < 0 || r >= grid.length || c >= (grid[0]?.length ?? 0)) return ERR.ref;
    const key = `${r}:${c}`;
    const cached = cache.get(key);
    if (cached !== undefined) return cached;
    const text = raw(r, c).trim();
    if (text === "") {
      cache.set(key, "");
      return "";
    }
    if (!text.startsWith("=")) {
      const v: CellValue = isNumericText(text) ? Number(text.replace(/,/g, "")) : text;
      cache.set(key, v);
      return v;
    }
    if (visiting.has(key)) return ERR.cycle;
    visiting.add(key);
    let out: CellValue;
    try {
      out = evaluateFormula(text.slice(1), valueAt);
    } catch {
      out = ERR.err;
    }
    visiting.delete(key);
    cache.set(key, out);
    return out;
  }

  return grid.map((row, r) => row.map((_, c) => valueAt(r, c)));
}

type Resolver = (r: number, c: number) => CellValue;

/** 数式（先頭の = を除いた部分）を評価する */
export function evaluateFormula(src: string, valueAt: Resolver): CellValue {
  let i = 0;

  const s = src;
  const skip = () => {
    while (i < s.length && /\s/.test(s[i])) i += 1;
  };
  const eat = (ch: string): boolean => {
    skip();
    if (s[i] === ch) {
      i += 1;
      return true;
    }
    return false;
  };

  const peekChar = (): string => {
    skip();
    return s[i] ?? "";
  };

  // --- 数値・参照・範囲・関数 -------------------------------------------
  function collectRange(): CellValue[] {
    const startRef = readRefToken();
    let cells: CellValue[] = [];
    if (startRef && eat(":")) {
      const endRef = readRefToken();
      if (!endRef) throw new Error(ERR.ref);
      const r0 = Math.min(startRef.r, endRef.r);
      const r1 = Math.max(startRef.r, endRef.r);
      const c0 = Math.min(startRef.c, endRef.c);
      const c1 = Math.max(startRef.c, endRef.c);
      if ((r1 - r0 + 1) * (c1 - c0 + 1) > 20000) throw new Error(ERR.ref);
      for (let r = r0; r <= r1; r += 1) {
        for (let c = c0; c <= c1; c += 1) cells.push(valueAt(r, c));
      }
    } else if (startRef) {
      cells = [valueAt(startRef.r, startRef.c)];
    }
    return cells;
  }

  function readRefToken(): { r: number; c: number } | null {
    skip();
    const m = /^\$?([A-Za-z]+)\$?(\d+)/.exec(s.slice(i));
    if (!m) return null;
    const pos = refToPos(`${m[1]}${m[2]}`);
    if (!pos) return null;
    i += m[0].length;
    return pos;
  }

  function aggregate(name: string, args: CellValue[]): CellValue {
    const nums = args.filter((v): v is number => typeof v === "number" && Number.isFinite(v));
    switch (name) {
      case "SUM":
        return nums.reduce((a, b) => a + b, 0);
      case "AVERAGE":
      case "AVG":
        return nums.length ? nums.reduce((a, b) => a + b, 0) / nums.length : ERR.div;
      case "COUNT":
        return nums.length;
      case "MIN":
        return nums.length ? Math.min(...nums) : 0;
      case "MAX":
        return nums.length ? Math.max(...nums) : 0;
      case "ABS":
        return nums.length ? Math.abs(nums[0]) : ERR.value;
      case "ROUND": {
        const [v, digits = 0] = nums;
        const d = Math.max(0, Math.min(10, Math.trunc(digits)));
        const f = 10 ** d;
        return Math.round((v ?? 0) * f) / f;
      }
      default:
        return ERR.err;
    }
  }

  function parsePrimary(): CellValue {
    skip();
    if (eat("(")) {
      const v = parseExpr();
      if (!eat(")")) throw new Error(ERR.err);
      return v;
    }
    if (eat("-")) return -toNumber(parsePrimary());
    if (eat("+")) return toNumber(parsePrimary());
    // 関数 or 参照
    const fnMatch = /^([A-Za-z][A-Za-z0-9]*)\(/.exec(s.slice(i));
    if (fnMatch) {
      const name = fnMatch[1].toUpperCase();
      i += fnMatch[0].length;
      const args: CellValue[] = [];
      if (!eat(")")) {
        for (;;) {
          const save = i;
          const cells = collectRange();
          const next = peekChar();
          if (cells.length > 0 && (next === "," || next === ")")) {
            args.push(...cells);
          } else {
            // A1/3 のような式が続く場合は参照ではなく式として読み直す
            i = save;
            args.push(parseExpr());
          }
          if (eat(",")) continue;
          if (eat(")")) break;
          throw new Error(ERR.err);
        }
      }
      return aggregate(name, args);
    }
    const cells = collectRange();
    if (cells.length === 1) return cells[0];
    if (cells.length > 1) throw new Error(ERR.err);
    // 数値リテラル
    skip();
    const numMatch = /^\d+(\.\d+)?([eE][+-]?\d+)?/.exec(s.slice(i));
    if (numMatch) {
      i += numMatch[0].length;
      return Number(numMatch[0]);
    }
    throw new Error(ERR.value);
  }

  function parseTerm(): CellValue {
    let left = parsePrimary();
    for (;;) {
      if (eat("*")) left = toNumber(left) * toNumber(parsePrimary());
      else if (eat("/")) {
        const rhs = toNumber(parsePrimary());
        left = rhs === 0 ? ERR.div : toNumber(left) / rhs;
        if (left === ERR.div) return left;
      } else if (eat("%")) left = toNumber(left) / 100;
      else break;
    }
    return left;
  }

  function parseExpr(): CellValue {
    let left = parseTerm();
    for (;;) {
      if (eat("+")) left = toNumber(left) + toNumber(parseTerm());
      else if (eat("-")) left = toNumber(left) - toNumber(parseTerm());
      else break;
    }
    return left;
  }

  const result = parseExpr();
  skip();
  if (i < s.length) throw new Error(ERR.err); // 余りはエラー扱い
  return result;
}

// --- シリアライズ ---------------------------------------------------------
const escapeHtml = (t: string) =>
  t.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

/** グリッド → HTML（値はテキスト、数式は data-f 属性） */
export function gridToHtml(grid: Grid, values: ValueGrid): string {
  const rows = values
    .map((row, r) => {
      const cells = row
        .map((value, c) => {
          const rawText = grid[r]?.[c] ?? "";
          const shown = formatValue(value);
          if (rawText.startsWith("=")) {
            return `<td data-f="${escapeHtml(rawText)}">${escapeHtml(shown)}</td>`;
          }
          return `<td>${escapeHtml(shown)}</td>`;
        })
        .join("");
      return `<tr>${cells}</tr>`;
    })
    .join("");
  return `<table data-sheet="1">${rows}</table>`;
}

/** HTML → グリッド（足りない分は空文字で埋める） */
export function htmlToGrid(html: string, rows = SHEET_ROWS, cols = SHEET_COLS): Grid {
  const grid: Grid = Array.from({ length: rows }, () => Array.from({ length: cols }, () => ""));
  if (!html.trim()) return grid;
  try {
    const doc = new DOMParser().parseFromString(html, "text/html");
    const trs = Array.from(doc.querySelectorAll("tr"));
    trs.forEach((tr, r) => {
      if (r >= rows) return;
      Array.from(tr.querySelectorAll("td,th")).forEach((td, c) => {
        if (c >= cols) return;
        const formula = td.getAttribute("data-f");
        grid[r][c] = formula ?? td.textContent ?? "";
      });
    });
  } catch {
    /* 壊れた HTML は空グリッドとして扱う */
  }
  return grid;
}

/** 検索用のプレーンテキスト（値だけをタブ区切りで） */
export function gridToText(values: ValueGrid): string {
  return values
    .map((row) => row.map((v) => formatValue(v)).join("\t").replace(/\t+$/, ""))
    .filter((line) => line.trim() !== "")
    .join("\n");
}
