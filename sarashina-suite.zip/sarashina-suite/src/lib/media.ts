// 画像 / 動画 / リンクの取り扱い（エディタでの挿入と、OOXML への埋め込み）。
//
// オフライン前提なので、ファイルは **data URI として文書の中に保存**する
// （外部 URL を貼ることもできるが、表示できるかは環境次第）。
// サイズ上限を超えるファイルは拒否し、UI が翻訳済みのメッセージを出す。

import { isTauri } from "./api";

export const IMAGE_ACCEPT = "image/png,image/jpeg,image/gif,image/webp,image/bmp,image/svg+xml";
export const VIDEO_ACCEPT = "video/mp4,video/webm,video/ogg,video/quicktime";

/** 文書に埋め込める画像の上限（SQLite にそのまま入るため控えめに） */
export const MAX_IMAGE_BYTES = 8 * 1024 * 1024;
/** 動画の上限。超える場合は URL 挿入を促す */
export const MAX_VIDEO_BYTES = 32 * 1024 * 1024;

export const escapeAttr = (text: string) =>
  text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

const EXT_BY_MIME: Record<string, string> = {
  "image/png": "png",
  "image/jpeg": "jpeg",
  "image/gif": "gif",
  "image/webp": "webp",
  "image/bmp": "bmp",
  "image/svg+xml": "svg",
};

const MIME_BY_EXT: Record<string, string> = {
  png: "image/png",
  jpg: "image/jpeg",
  jpeg: "image/jpeg",
  gif: "image/gif",
  webp: "image/webp",
  bmp: "image/bmp",
  svg: "image/svg+xml",
};

export interface DataUri {
  mime: string;
  ext: string;
  bytes: Uint8Array;
}

export function bytesToBase64(bytes: Uint8Array): string {
  let binary = "";
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
  }
  return btoa(binary);
}

export function base64ToBytes(text: string): Uint8Array {
  const binary = atob(text);
  const out = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i += 1) out[i] = binary.charCodeAt(i);
  return out;
}

/** `data:image/png;base64,....` を分解する（data URI 以外は null） */
export function parseDataUri(uri: string): DataUri | null {
  const match = /^data:([^;,]+)(;base64)?,(.*)$/s.exec(uri.trim());
  if (!match) return null;
  const mime = match[1].toLowerCase();
  const ext = EXT_BY_MIME[mime] ?? mime.split("/").pop() ?? "bin";
  try {
    const bytes = match[2] ? base64ToBytes(match[3]) : new TextEncoder().encode(decodeURIComponent(match[3]));
    return { mime, ext, bytes };
  } catch {
    return null;
  }
}

export function fileMime(file: File): string {
  if (file.type) return file.type;
  const ext = file.name.split(".").pop()?.toLowerCase() ?? "";
  return MIME_BY_EXT[ext] ?? "application/octet-stream";
}

/** ファイルを data URI にする */
export async function fileToDataUri(file: File): Promise<string> {
  const bytes = new Uint8Array(await file.arrayBuffer());
  return `data:${fileMime(file)};base64,${bytesToBase64(bytes)}`;
}

/** PNG / JPEG / GIF の実寸を読む（OOXML に埋め込むとき縦横比を保つため） */
export function imageSize(bytes: Uint8Array): { width: number; height: number } | null {
  if (!bytes || bytes.length < 24) return null;
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  // PNG: 8 バイト署名 + IHDR
  if (view.getUint32(0, false) === 0x89504e47 && view.getUint32(4, false) === 0x0d0a1a0a) {
    const width = view.getUint32(16, false);
    const height = view.getUint32(20, false);
    return width > 0 && height > 0 ? { width, height } : null;
  }
  // GIF: "GIF89a" / "GIF87a"
  if (view.getUint32(0, false) === 0x47494638) {
    const width = view.getUint16(6, true);
    const height = view.getUint16(8, true);
    return width > 0 && height > 0 ? { width, height } : null;
  }
  // JPEG: SOF マーカーを走査
  if (view.getUint16(0, false) === 0xffd8) {
    let offset = 2;
    while (offset + 9 < bytes.length) {
      if (bytes[offset] !== 0xff) {
        offset += 1;
        continue;
      }
      const marker = bytes[offset + 1];
      if (marker >= 0xc0 && marker <= 0xcf && marker !== 0xc4 && marker !== 0xc8 && marker !== 0xcc) {
        const height = view.getUint16(offset + 5, false);
        const width = view.getUint16(offset + 7, false);
        return width > 0 && height > 0 ? { width, height } : null;
      }
      const length = view.getUint16(offset + 2, false);
      if (length < 2) return null;
      offset += 2 + length;
    }
  }
  return null;
}

/** リンクを既定のブラウザで開く（Tauri は opener プラグイン、Web は window.open） */
export async function openExternal(url: string): Promise<void> {
  const trimmed = url.trim();
  if (!/^(https?:|mailto:)/i.test(trimmed)) return;
  if (isTauri) {
    const { openUrl } = await import("@tauri-apps/plugin-opener");
    await openUrl(trimmed);
    return;
  }
  window.open(trimmed, "_blank", "noopener,noreferrer");
}

/** 入力された URL を安全な形に整える（スキームが無ければ https を補う） */
export function normalizeUrl(raw: string): string {
  const text = raw.trim();
  if (!text) return "";
  if (/^(https?:|mailto:)/i.test(text)) return text;
  if (/^[\w.-]+\.[a-z]{2,}(\/|$)/i.test(text)) return `https://${text}`;
  return "";
}
