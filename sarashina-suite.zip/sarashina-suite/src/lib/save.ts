// 生成したファイルを保存する共通処理。
//
// デスクトップ版（Tauri）はアプリのデータフォルダ `exports/` に書き出し、
// Web 版は同じバイト列をそのままダウンロードする。呼び出し側は区別しなくてよい。

import { api } from "./api";

/** バイト列 → base64（大きいファイルでもスタックを溢れさせない） */
export function toBase64(data: string | Uint8Array): string {
  const bytes = typeof data === "string" ? new TextEncoder().encode(data) : data;
  let binary = "";
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
  }
  return btoa(binary);
}

/** 保存して「どこに保存したか」を返す */
export async function saveFile(name: string, data: string | Uint8Array): Promise<string> {
  return api.saveExportFile(name, toBase64(data));
}
