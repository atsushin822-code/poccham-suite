# Suite with Poccham AI

**オフラインで完結する超軽量・高速な統合 Office（Poccham AI 内蔵）。** 文書・表計算・スライドの編集と AI 支援のすべてを
端末内で実行し、ネットワークに一切依存しません（例外は初回のモデル取得のみ）。

| | |
|---|---|
| できること | **1 つのアプリで「文書 / 表計算 / スライド」** ＋ ローカル AI 支援 |
| コア | Tauri 2（Rust + 各 OS ネイティブ WebView） |
| フロント | Svelte 5（runes）+ TypeScript + Vite |
| ストレージ | SQLite（WAL + FTS5/trigram）をバイナリ同梱 |
| AI | **Poccham AI**（GGUF + llama.cpp / `llama-cpp-2`）|
| 配布 | Windows **ポータブル `.exe`（インストール不要）** / `.exe`(NSIS) / `.msi`, macOS `.dmg` + `.app.zip`, Linux `.AppImage`/`.deb`/`.rpm`。各 OS 用の**起動スクリプト（.bat / .sh / .command）**付き |

フロントエンドのビルド成果物は **JS 218KB (gzip 75KB) + CSS 30KB（合計 277KB）**。GPU なしのノート PC でも
1B モデルで 15〜25 tok/s 程度の日本語生成が動作する構成を既定にしています。

---

## 1. クイックスタート

### 前提ツール

| OS | 必要なもの |
|---|---|
| 共通 | Rust 1.80+, Node.js 20+, `cmake`, `clang`（llama.cpp のビルドに必要）|
| Windows | Visual Studio Build Tools（C++ ワークロード）、WebView2（Win11 は標準）|
| macOS | Xcode Command Line Tools（`xcode-select --install`）|
| Linux | `libwebkit2gtk-4.1-dev libgtk-3-dev librsvg2-dev libayatana-appindicator3-dev patchelf` |

### 開発

```bash
npm install
npm run icons       # src-tauri/icons/source.png から各 OS 用アイコンを生成（初回のみ）

# ① まずは UI だけ動かす（llama.cpp をビルドしない = 数十秒で起動）
npm run app:dev:stub

# ② ローカル推論込みで動かす（初回は llama.cpp の C++ ビルドで 3〜8 分）
npm run app:dev

# ③ テスト / 型チェック
npm run core:test   # コアドメインロジックのユニットテスト（15 件）
npm run check       # svelte-check（型 + アクセシビリティ）
```

> ブラウザだけで UI を確認したい場合は `npm run dev` を実行して `http://localhost:1420` を開きます。
> Tauri API が無い環境では自動的に**デモバックエンド**（`src/lib/demo.ts`）へフォールバックし、
> ダウンロード進捗やストリーミング表示まで含めて操作感を確認できます。

### 配布ビルド

```bash
npm run app:build                    # 現在の OS 向けバンドルを生成
npm run app:build -- --bundles appimage,deb    # Linux で対象を限定
npm run app:build -- --target aarch64-apple-darwin --features metal
```

成果物は `target/release/bundle/` 以下（`dmg/`, `msi/`, `nsis/`, `appimage/`, `deb/`, `rpm/`）。
ルートに Cargo ワークスペースがあるため `src-tauri/target/` ではなく **プロジェクト直下の `target/`** に出ます。

### 1 つのアプリに文書 / 表計算 / スライドを統合

サイドバー上部の 3 つのボタン（**＋文書 / ＋表計算 / ＋スライド**）から種別を選んで新規作成します。
一覧の各項目には種別アイコンが付き、開いた文書の種別に応じて編集 UI が切り替わります。
Tauri + Rust + SQLite + Svelte の構成は変えていません（`documents.kind` に `doc` / `sheet` / `slide` を
保存するだけで、保存・検索（FTS5）・書き出しは全種別で共通の経路を通ります）。

| 種別 | 編集 UI | 保存形式 | 取り込み | 書き出し（ネイティブ） | テキスト |
|---|---|---|---|---|---|
| 文書 `doc` | リッチテキスト（太字・見出し・箇条書き・画像・動画・リンク） | サニタイズ済み HTML | **.docx** | **.docx** / .poccham | md / txt / html |
| 表計算 `sheet` | 40 行 × 12 列グリッド ＋ 数式バー ＋ 複数シート | `<table data-sheet="1">`（数式は `data-f` に保持） | **.xlsx / .csv** | **.xlsx** / .poccham | md / txt（タブ・`|` 区切り） |
| スライド `slide` | サムネイル一覧 ＋ 見出し/本文 ＋ 画像 ＋ 16:9 プレビュー | `<section data-slide="1" data-img="…">` の連なり | **.pptx** | **.pptx** / .poccham | md / txt（`[1] 見出し` 形式） |

書き出しは**すべて端末内で完結**します。`.docx` / `.xlsx` / `.pptx` は ZIP + OOXML を自前で組み立てて生成し（外部ライブラリなし）、
`.xlsx` には数式と計算結果（キャッシュ値）の両方を書き込みます。`.poccham` は 3 種を 1 ファイルに同梱する
JSON 形式（`{format:"poccham", version:1, app:"Suite with Poccham AI", documents:[...]}`）で、再インポート可能です。

### 取り込み（.docx / .xlsx / .csv / .pptx）

サイドバーの **「取り込み」** から既存の Office ファイルを読み込めます（複数選択可・ドラッグ不要）。
解析はすべて端末内で完結し、**外部ライブラリを一切使っていません**（ZIP 展開 + XML 解析を自前実装）。

| 形式 | 取り込む内容 | 生成される文書 |
|---|---|---|
| `.docx` | 見出し（h1–h6）/ 太字・斜体・下線・取り消し線 / 箇条書き / 表（` | ` 区切りの段落）/ 埋め込み画像 / ハイパーリンク | 文書 1 件 |
| `.xlsx` | 値・共有文字列・数式（`SUM` などの対応関数は数式として保持）/ 複数シート | シートごとに 1 件（2 枚以上は `ファイル名 - シート名`） |
| `.csv` | RFC4180（引用符・セル内改行・カンマ入りセル）と区切り自動判定（`,` / `;` / タブ）、BOM 除去 | 表計算 1 件 |
| `.pptx` | スライドの並び順 / タイトルと本文（段落・改行を保持）/ 画像 | スライド 1 件 |
| `.poccham` | このアプリのネイティブ形式（文書・表計算・スライドをまとめて復元） | 件数ぶん |

* 画像は **data URI として文書の中に保存**されるため、元ファイルを移動しても表示は崩れません
* 数式エンジンが対応していない関数（`VLOOKUP` など）は、**Excel が保存した計算結果**を値として取り込みます
* 表計算はこのアプリの上限（40 行 × 12 列）に合わせて切り詰め、切り詰めた場合は通知に出します
* 取り込んだ文書は通常の文書と同じく自動保存・全文検索・AI 支援・書き出しの対象になります

### 画像・動画・リンクの挿入

文書エディタのツールバーから挿入できます。

| 種類 | 操作 | 保存のされ方 |
|---|---|---|
| 画像 | 「画像」→ ファイル選択（PNG / JPEG / GIF / WebP / BMP / SVG、**8 MB まで**） | data URI で本文に埋め込み。`.docx` 書き出し時は `word/media/` に展開 |
| 動画 | 「動画」→ ファイル選択（MP4 / WebM / OGG / MOV、**32 MB まで**） | data URI で `<video controls>` として埋め込み（アプリ内で再生） |
| リンク | 「リンク」→ 表示テキストと URL を入力 → 挿入 | `<a href>` として保存。`example.com/x` のような入力は `https://` を補完 |

* リンクは編集中の誤遷移を防ぐため、**Ctrl（⌘）+ クリック**で既定のブラウザが開きます
* スライドは 1 枚につき画像 1 枚を貼れます（`画像を貼る` / `差し替え` / `削除`）。プレビュー・スライドショー・`.pptx` 書き出しすべてに反映されます
* サイズ上限を超えた場合は挿入せず、理由をツールバーに表示します（上限は端末内 SQLite に保存する都合で設定）

### スライドショー（プレゼン機能）

スライドを開いて上部の **「プレゼン」** を押すと全画面のスライドショーになります。

* `→` / `Space` / クリックで次へ、`←` で前へ、`Esc` で終了（`Home` / `End` で先頭・末尾へジャンプ）
* 16:9 固定・レターボックス表示、下端に現在ページ / 総ページのインジケータ
* 編集中の内容をそのまま表示するため、発表前の書き出しは不要

### 初期セットアップと言語

初回起動時は**名前の入力**と**表示言語**の確認だけを行う軽量なセットアップ画面が出ます（`スキップ` 可・後から設定で変更可）。

* 名前はあいさつ文・AI への文脈付けに使われ、`settings` に保存されます
* 言語は **6 言語**（日本語 / English / 中文 / 한국어 / Español / Deutsch）に対応。
  未設定時は `navigator.language` に追従し、OS の言語を変えれば**再起動なしで追従**します
* 設定画面からいつでも手動で切り替え可能（自動追従 / 日本語 / English / …）
* 入力欄のプレースホルダ（透かし文字）は使用せず、**すべて可視ラベル + `aria-label`** で提示します

### デスクトップのスクロール

WebView 側で二重スクロールが起きないよう、`html` は `overflow: hidden` に固定し、`body` を唯一のスクロール
コンテナにしています（`overscroll-behavior: none`）。スクロールバーは全要素で**常時表示**（`scrollbar-width: thin`
+ `::-webkit-scrollbar`）にし、リスト・一覧・エディタ内のスクロール領域（`.scroll`）だけが内側で完結します。

**表計算で使える数式**（`=` から入力）

* 四則演算 `+ - * / %`、括弧、単項 `+ -`
* 参照 `A1` / `$A$1`、範囲 `A1:B3`
* 関数 `SUM` `AVERAGE`(`AVG`) `COUNT` `MIN` `MAX` `ABS` `ROUND(値, 桁)`
* エラー表示 `#REF!`（範囲外参照）`#DIV/0!` `#CYCLE!`（循環参照）`#VALUE!` `#ERR!`

**操作**: セルをクリックして選択 → 文字を打つ / `F2` / ダブルクリックで編集、`Enter` で確定して下へ、
`Tab` で右へ、`Esc` で取り消し、`Delete` で消去、矢印キーで移動。上部の数式バーから `=SUM(A1:A3)` を
直接入力することもできます。

![表計算エディタ](docs/web-preview-sheet.png)

![スライドエディタ](docs/web-preview-slide.png)

### Web 版（静的ファイルとして配信）

同じソースから、**サーバーサイド不要の静的サイト**としてビルドできます。

```bash
npm run build:web        # → build/ に index.html + assets（合計 ~140KB）
python3 -m http.server 8000   # 動作確認（http://localhost:8000/）
```

![Web 版の画面](docs/web-preview.png)

`base: "./"` で出力しているため、**サブディレクトリ配信**（例: `https://example.com/sarashina/`）でも
そのまま動きます。`build/` の中身を置くだけで、nginx / Apache / GitHub Pages / Netlify / S3 どこでも配信可能です。

| できること | できないこと |
|---|---|
| **文書 / 表計算 / スライド**の作成・編集・自動保存・検索・書き出し（.docx / .xlsx / .pptx / .poccham / md / txt / html） | **ローカル AI 推論**（GGUF の読み込みはデスクトップ版のみ） |
| ブラウザ内（IndexedDB）への永続保存 | 端末間の同期（データはブラウザごと） |

* 保存先は IndexedDB（DB 名 `sarashina-suite`）。`file://` で直接開くと保存できない場合があるため、
  必ず HTTP 経由で開いてください。
* AI パネルは「Web 版では使えません」という案内に切り替わり、モデル導入の導線も無効化されます。
* `?demo=1` を付けると、インメモリのモック（AI 応答もダミー）で UI を確認できます。
* 実ブラウザでの自動検証: `node scripts/web-e2e.mjs http://127.0.0.1:8000/`
  （`npm i -D playwright && npx playwright install chromium` が必要。23 項目を検証）
* 書き出しの自動検証: `node scripts/export-e2e.mjs http://127.0.0.1:8000/`（13 項目。生成した OOXML を保存）
* 取り込み／挿入の自動検証: `node scripts/import-e2e.mjs http://127.0.0.1:8000/ <fixtureDir>`（29 項目）

CI では `Run workflow` → `build: web` を選ぶと `Suite-with-Poccham-AI-web.zip`（artifact 名 `SuiteWithPocchamAI-web`）が Artifacts に出ます。
リポジトリ変数 `DEPLOY_PAGES=true` を設定しておくと、ビルド後に **GitHub Pages へ自動デプロイ**します
（Settings → Pages の Source を「GitHub Actions」にしておく）。

### 起動スクリプト（.bat / .sh / .command）

`launchers/` に 3 種類の起動スクリプトがあり、CI が各 OS の成果物へ自動で同梱します。

| OS | ファイル | 使い方 |
|---|---|---|
| Windows | `Start-Suite-with-Poccham-AI.bat` | `SuiteWithPocchamAI.exe` と同じフォルダに置いて**ダブルクリック**（ポータブル zip には最初から入っています）|
| Linux | `Start-Suite-with-Poccham-AI.sh` | AppImage と同じフォルダに置いて `./Start-Suite-with-Poccham-AI.sh`。実行権限が無ければ `bash Start-Suite-with-Poccham-AI.sh` |
| macOS | `Start-Suite-with-Poccham-AI.command` | `.app`（または `.dmg`）と同じフォルダに置いてダブルクリック。実行権限が無ければ `bash "Start-Suite-with-Poccham-AI.command"` |

自動で行うこと:

* **Windows**: 実行ファイルを同じフォルダ→サブフォルダの順で探して起動（WebView2 が無い場合の案内も表示）
* **Linux**: AppImage の**実行権限を付与**してから起動（CI の artifact はパーミッションが落ちるため）。deb/rpm 導入済みの `sarashina-suite` も検出
* **macOS**: `.app` の**隔離属性（com.apple.quarantine）を解除**して起動＝未署名ビルドの「開発元を確認できません」を回避。`.app` が無く `.dmg` だけの場合は自動マウントして Applications へコピー

### Windows ポータブル版（インストール不要）

CI は `SuiteWithPocchamAI-<version>-portable-x64.exe` と同名の `.zip` も生成します。これは
`target/release/sarashina-suite.exe`（生の実行ファイル）そのもので、**ダブルクリックで起動**できます。

* インストーラ・管理者権限・レジストリ書き込みは不要（設定と文書は `%APPDATA%\jp.sarashina.suite` に保存）
* 必要なのは **WebView2 ランタイム**のみ（Windows 11 は標準搭載、Windows 10 も Edge があれば導入済み。
  無い場合は NSIS インストーラを使うか、Microsoft の Evergreen ランタイムを入れてください）
* USB メモリに入れて持ち運べます（`.zip` を展開して `SuiteWithPocchamAI.exe` を実行）

タグを push するだけで 4 プラットフォーム分が自動ビルドされます（`.github/workflows/build.yml`）。
Git を使わず **zip + yml だけ**で回す手順は次のセクションを参照してください。

```bash
git tag v0.1.0 && git push origin v0.1.0
```

---

### zip + yml だけで GitHub Actions を回す（ローカル git 不要）

リポジトリに必要なのは **`sarashina-suite.zip`（この配布物）と `build.yml` の 2 つだけ**です。
ワークフローが zip を自動展開してプロジェクトの場所を解決するため、ソースを展開して push する必要はありません。

1. GitHub で空のリポジトリを作成する
2. **Add file → Upload files** で `sarashina-suite.zip` をリポジトリ直下にアップロードしてコミット
3. **Add file → Create new file** → ファイル名に `.github/workflows/build.yml` と入力し、
   ワークスペース直下の `build.yml` の内容を貼り付けてコミット
4. **Actions** タブ → `Build installers` → **Run workflow**
   - `build`: `all` / `linux` / `windows` / `macos` から選択
   - `skip_tests`: 検証ジョブを省略して時間を短縮
5. 実行完了後、ジョブページ下部の **Artifacts** から `SuiteWithPocchamAI-linux` / `-windows` / `-macos-arm64` / `-macos-x64` をダウンロード

* タグを push（`v0.1.0`）すると同じワークフローが **Release に dmg / msi / exe / AppImage / deb / rpm を自動添付**します。
* 展開済みの通常リポジトリでも動きます（`src-tauri/` が直下にあれば zip は不要）。
* ビルド時間の目安: 初回 15〜25 分（llama.cpp の C++ ビルドを含む）／キャッシュ後 6〜10 分。
* `Cargo.lock` と `package-lock.json` を同梱しているため、リリース間で依存がぶれません。
* macOS Intel のランナーは **`macos-15-intel`**。ARM は **`macos-15`**（`macos-14` 系は 2026-11-02 に廃止済み）。
* ビルド対象の切り替えは「`plan` ジョブが matrix の JSON を出力 → `build` ジョブが `fromJSON` で受け取る」方式です
  （`matrix` コンテキストはジョブレベルの `if:` では使えず、`github` / `inputs` / `needs` / `vars` しか参照できません）。
* ワークフローの静的検証は `actionlint`（+ shellcheck）で 0 エラーを確認済みです。
* **成果物の出力先**: ルートに `[workspace]` があるため `target/` は**プロジェクト直下**に出ます
  （`src-tauri/target/` ではありません）。収集ステップは両方を探します。
* **ランナーは変数で差し替え可能**: `LINUX_RUNNER` / `WINDOWS_RUNNER` / `MACOS_ARM_RUNNER` / `MACOS_X64_RUNNER`
  （未設定時は `ubuntu-22.04` / `windows-latest` / `macos-15` / `macos-15-intel`）。
  GitHub がイメージを廃止しても、YAML を書き換えず変数だけで追従できます。
* **Windows はポータブル `.exe` も同梱**: 収集ステップが生の exe を `SuiteWithPocchamAI-<ver>-portable-x64.exe`
  として複製し、隣接 DLL があれば zip にまとめます（無ければ exe 単体で動きます）。
* **Windows は NSIS も主成果物**: `wix.language` を `ja-JP` に限定しているため MSI も作れますが、
  MSI(WiX) が失敗した場合は NSIS のみで再試行して必ず `.exe` を残します。
* **空の署名環境変数は捨てる**: GitHub Actions は「未設定の Secret」を**空文字**として env に渡しますが、
  Tauri は `APPLE_SIGNING_IDENTITY=""` を「空の ID で codesign する」と解釈し、
  `error: The specified item could not be found in the keychain.` でバンドルに失敗します（macOS 15 ランナーで再現）。
  各ビルドステップは冒頭で空の署名系変数を `unset` し、署名なしで進むときは
  **ad-hoc 署名（`APPLE_SIGNING_IDENTITY="-"`）** を明示します（未署名の `.app` は Apple Silicon で起動できないため）。
  `APPLE_SIGNING=true` なのに `APPLE_SIGNING_IDENTITY` が空のときは、推測で別 ID を渡さず**即座に失敗**させます。
* **署名は任意**: リポジトリ変数 `APPLE_SIGNING` で制御します（未設定 = `auto`）。
  `auto` は証明書が無効でも警告を出して**署名なしで続行**、`true` は署名必須、`false` は常に署名なし。
* 成果物の収集は `find` → `$RUNNER_TEMP/artifacts` に平積み → ディレクトリごとアップロード（グロブ非依存）。
  0 件なら `target/` の構成を出力してジョブを失敗させるので、原因がログから即断できます。
* **macOS は「署名なし」が既定**。失敗するたびに条件を落として 4 段まで再試行します:
  `⓪署名あり`(vars.APPLE_SIGNING=true の時のみ) → `①Metal` → `②CPU(Metal無効/LTO=thin)` → `③.app のみ(zip 配布)`。
  どの段で成功しても成果物は残るので、証明書や Metal の環境差で CI が赤くなりません。
* **失敗時は自動で診断**: 「失敗時の診断情報」ステップが OS / Xcode / metal / codesign の状態と
  `bundle` ディレクトリ構成を**ジョブのサマリ**に出力し、`diag-<プラットフォーム>` artifact にも保存します。

## 2. ディレクトリ構造

```
sarashina-suite/
├── Cargo.toml                    # ワークスペース + リリースプロファイル(LTO/strip)
├── package.json / vite.config.ts / svelte.config.js / tsconfig.json
├── index.html
├── README.md / ARCHITECTURE.md
│
├── crates/sarashina-core/        # ★ UI/OS 非依存のドメインロジック（テスト対象）
│   ├── Cargo.toml
│   ├── migrations/001_init.sql   # SQLite スキーマ（user_version で管理）
│   └── src/
│       ├── lib.rs
│       ├── error.rs              # CoreError（Serialize して TS へ渡す）
│       ├── db.rs                 # 接続 / マイグレーション / CRUD / FTS5
│       ├── catalog.rs            # GGUF モデルカタログ（サイズ・SHA-256）
│       ├── download.rs           # Range レジューム + 進捗 + SHA-256 検証
│       ├── export.rs             # Markdown / HTML / TXT 書き出し（表計算・スライド対応）
│       └── inference/
│           ├── mod.rs
│           ├── engine.rs         # ワーカースレッド / Job / ハンドル
│           ├── llama.rs          # llama.cpp バックエンド（feature = "llama"）
│           ├── stub.rs           # ダミーバックエンド（feature 無効時）
│           └── prompt.rs         # チャットテンプレート / 予算調整
│
├── src-tauri/                    # ★ デスクトップ層（薄いアダプタ）
│   ├── Cargo.toml
│   ├── build.rs
│   ├── tauri.conf.json           # バンドル設定（最重要）
│   ├── entitlements.plist        # macOS 署名用
│   ├── capabilities/default.json # 許可する権限（最小限）
│   ├── icons/                    # source.png から tauri icon で生成
│   └── src/
│       ├── main.rs
│       ├── lib.rs                # Builder / invoke_handler 登録
│       ├── state.rs              # AppState（DB, engine, client, cancel flags）
│       ├── events.rs             # イベント名 + ProgressSink/TokenSink 実装
│       └── commands/
│           ├── mod.rs            # ブロッキングヘルパ
│           ├── app.rs            # app_info / settings / stats
│           ├── documents.rs      # CRUD / 検索 / エクスポート
│           ├── models.rs         # ダウンロード / 削除 / 切替 / エンジン設定
│           ├── files.rs          # 書き出しファイルの保存 / 保存先フォルダ
│           └── chat.rs           # セッション / ストリーミング生成
│
├── src/                          # ★ フロントエンド（Svelte 5 + TS）
│   ├── main.ts / app.css
│   ├── App.svelte                # view 切り替え（onboarding/workspace/settings）
│   └── lib/
│       ├── api.ts                # Tauri invoke の唯一の窓口 + デモ fallback
│       ├── demo.ts               # ブラウザ実行用モックバックエンド
│       ├── types.ts              # Rust DTO と 1:1 の型
│       ├── format.ts             # バイト/相対時刻/HTML サニタイズ
│       ├── i18n.svelte.ts        # 6 言語の辞書 + t() + システム言語追従
│       ├── exporters.ts          # .docx / .xlsx / .pptx / .poccham を自前生成
│       ├── importers.ts          # .docx / .xlsx / .csv / .pptx / .poccham の取り込み
│       ├── media.ts              # 画像・動画の data URI 化 / 実寸取得 / リンクを開く
│       ├── zip.ts                # 最小 ZIP ライタ + リーダ（自前 inflate 実装）
│       ├── save.ts               # 書き出しの保存（Tauri = データフォルダ / Web = ダウンロード）
│       ├── sheet.ts / slides.ts  # 表計算の数式評価 / スライドのモデル
│       ├── stores/app.svelte.ts  # runes ベースの共有状態
│       ├── components/           # Sidebar / Editor / SheetEditor / SlideEditor /
│       │                         #   Presentation / AIPanel / ModelCard / ProgressBar
│       └── views/                # NameSetup / Onboarding / Workspace / Settings
│
└── .github/workflows/
    └── build.yml                 # ★ これ 1 本で完結（zip 自動展開 + 4OS ビルド + Release 添付）
```

**設計の要**: `sarashina-core`（純粋ロジック）と `src-tauri`（OS 連携）を分離しているため、
DB・ダウンローダ・プロンプト構築は GUI なしで `cargo test` できます。
詳細は [ARCHITECTURE.md](./ARCHITECTURE.md) を参照してください。

---

## 3. 検証済みの内容（このリポジトリの状態）

| 項目 | 結果 |
|---|---|
| `cargo test -p sarashina-core` | **15 テスト全パス**（DB/CRUD/FTS5 / SQLite スキーマ / プロンプト / エクスポート（表計算の HTML 含む）/ パス処理）|
| `cargo test -p sarashina-suite --no-default-features` | **2 テストパス** |
| `cargo check -p sarashina-suite --no-default-features` | **成功（warning 0）** |
| `npm run check`（svelte-check） | **0 errors / 0 warnings** |
| `npm run build:web` | 成功（JS 183.5KB / gzip 62.7KB、CSS 27KB、`build/` 合計 236KB）|
| `scripts/web-e2e.mjs`（実ブラウザ） | **24/24 PASS**（3 種の作成・数式計算・リロード後の永続化・言語切替・名前セットアップ）|
| `scripts/export-e2e.mjs`（実ブラウザ） | **13/13 PASS**（docx / xlsx / pptx / poccham / md / txt / html、プレゼン操作、コンソールエラー 0）|
| `scripts/import-e2e.mjs`（実ブラウザ） | **29/29 PASS**（外部製の docx / xlsx / csv / pptx 取り込み、画像・動画・リンク挿入、docx 往復、画像つき pptx 書き出し）|
| 生成 OOXML のパース検証 | **ALL OK**（`python-docx` / `openpyxl` / `python-pptx` で開いて内容一致。xlsx は数式＋計算結果、docx / pptx は埋め込み画像も認識）|
| `actionlint -shellcheck`（`build.yml`） | **0 issues**（式・コンテキスト・runner ラベル・シェルまで静的検証）|
| WebKitGTK 4.1 環境 | Tauri 層まで型検証済み（実機の Tauri ビルド・macOS ビルドは未検証）|

---

## 4. よくある詰まりどころ

| 症状 | 対処 |
|---|---|
| `llama-cpp-sys-2` のビルドが失敗する | `cmake` と `clang`（+ Linux は `libclang-dev`）を入れる。Windows は VS Build Tools の C++ 必須 |
| `cargo check` が遅い / C++ をビルドしたくない | `--no-default-features`（スタブ推論）を使う。CI もこのモードで回している |
| Linux で `webkit2gtk-4.0` が見つからない | Tauri 2 は **4.1** 系が必要。`libwebkit2gtk-4.1-dev` を入れる |
| macOS で「開発元を確認できません」 | 未署名ビルドのため。配布時は `APPLE_*` シークレットを設定して署名 + 公証する |
| `error: The specified item could not be found in the keychain.`（`Signing with identity ""`） | `APPLE_SIGNING_IDENTITY` が**空文字**のまま Tauri に渡っている。ワークフローは冒頭で空の署名系変数を `unset` し ad-hoc（`-`）に切り替えるので、最新の `build.yml` なら解消済み。署名 ID を Secrets に入れた場合は、その証明書が `APPLE_CERTIFICATE` として取り込まれているか（`security find-identity -v -p codesigning` に出るか）を確認する |
| macOS で `xcrun: error: unable to find utility "metal"` | **Xcode 26 以降は Metal ツールチェーンが同梱されていない**。`xcodebuild -downloadComponent MetalToolchain` で導入する（ワークフローは自動導入し、失敗時は CPU 版へ自動フォールバックする）|
| CI で `No files were found with the provided path: .../src-tauri/target/**` | ルートが Cargo ワークスペースなので成果物は**プロジェクト直下の `target/`**。本ワークフローは `find` で両方を探してステージングする |
| `The configuration 'macos-14-arm64-us-xl' is not supported` | **`macos-14` 系ランナーは 2026-11-02 に廃止**されました（[公式チェンジログ](https://github.blog/changelog/2026-10-01-github-actions-macos-14-runner-image-retirement/)）。arm64 は `macos-15`（または `macos-latest`）を使ってください。本ワークフローは `macos-15` に更新済みで、リポジトリ変数 `MACOS_ARM_RUNNER` / `MACOS_X64_RUNNER` で差し替えも可能です |
| Windows で `error LGHT0311 : A string was provided with characters that are not available in the specified database code page '1252'` | WiX(MSI) の en-US データベースはコードページ 1252 のため、`shortDescription` 等の日本語を受け付けません。`bundle.windows.wix.language` を `"ja-JP"` のみにする（本リポジトリは対応済み）。CI は MSI 失敗時に NSIS へ自動フォールバックします |
| `SecKeychainItemImport: Unable to decode the provided data` | `APPLE_CERTIFICATE` が「`.p12` を base64 化した文字列」になっていない（PEM や改行混入）か、`APPLE_CERTIFICATE_PASSWORD` の不一致。署名をやめるなら Secrets を削除するか `APPLE_SIGNING=false` を設定（本ワークフローは失敗時に自動で署名なしへフォールバック）|
| macOS で `ld: out of memory` / SIGKILL | fat LTO と大規模 C++ 静的ライブラリのリンクでメモリ不足。CI のフォールバックは `CARGO_PROFILE_RELEASE_LTO=thin` で再試行する |
| モデルのダウンロードが遅い / 途中で止まる | 設定画面の「モデル取得ミラー」に自前ミラー URL を設定。`.part` から自動再開する |
| AI パネルが「モデルがまだ読み込まれていません」 | ダウンロード完了後、エンジンのロードに数秒かかる。設定画面のエンジン状態が `ready` になってから送信する |

---

## 5. ライセンス

* アプリコード: MIT OR Apache-2.0
* **モデルの重み**: 本アプリには**同梱していません**。初回セットアップ時にユーザー自身が配布元から取得し、
  ダウンロードされたモデルは配布元のライセンスに従います（アプリコードのライセンスとは独立）。
* 書き出し（.docx / .xlsx / .pptx）は外部ライブラリを使わず自前生成しているため、追加のライセンス制約はありません。
