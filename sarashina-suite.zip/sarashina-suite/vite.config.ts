import { defineConfig } from "vite";
import { svelte } from "@sveltejs/vite-plugin-svelte";

const host = process.env.TAURI_DEV_HOST;

// Tauri は固定ポートを要求するため strictPort: true。
// 0.0.0.0 バインド + allowedHosts でプレビュー環境/モバイル実機からも確認可能。
export default defineConfig({
  plugins: [svelte()],
  // 相対パスで出力する。Tauri のカスタムプロトコルでも、
  // GitHub Pages 等のサブディレクトリ配信でも同じビルドをそのまま使える。
  base: "./",
  clearScreen: false,
  server: {
    port: 1420,
    strictPort: true,
    host: host || "0.0.0.0",
    allowedHosts: true,
    hmr: host ? { protocol: "ws", host, port: 1421 } : undefined,
    watch: { ignored: ["**/src-tauri/**", "**/crates/**", "**/target/**"] },
  },
  build: {
    target: "safari15",
    outDir: "build",
    emptyOutDir: true,
    minify: "esbuild",
    sourcemap: false,
    chunkSizeWarningLimit: 900,
  },
});
