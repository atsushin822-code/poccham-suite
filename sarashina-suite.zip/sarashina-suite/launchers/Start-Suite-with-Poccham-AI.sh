#!/usr/bin/env bash
# ============================================================
#  Suite with Poccham AI ランチャー (Linux)
#  この .sh を AppImage と同じフォルダに置いて実行してください。
#     ./Start-Suite-with-Poccham-AI.sh
#  実行権限が無い場合は次のように起動できます:
#     bash Start-Suite-with-Poccham-AI.sh
# ============================================================
set -uo pipefail

cd "$(dirname "$(readlink -f "$0" 2>/dev/null || echo "$0")")" || exit 1
note() { printf '[Suite with Poccham AI] %s\n' "$*"; }

# 1) AppImage を優先（アーティファクト経由だと実行権限が落ちるため毎回付与する）
appimg=$(find . -maxdepth 2 -type f -name '*.AppImage' 2>/dev/null | head -n1)
if [ -n "${appimg:-}" ]; then
  chmod +x "$appimg" 2>/dev/null || true
  note "起動: $appimg"
  exec "./${appimg#./}" "$@"
fi

# 2) 生バイナリ（deb / rpm を展開した場合など）
for cand in "./suite-with-poccham-ai" "./Suite with Poccham AI" "./usr/bin/suite-with-poccham-ai" "./opt/Suite with Poccham AI/suite-with-poccham-ai"
do
  if [ -f "$cand" ]; then
    chmod +x "$cand" 2>/dev/null || true
    note "起動: $cand"
    exec "$cand" "$@"
  fi
done

# 3) PATH 上のインストール済みバイナリ
if command -v suite-with-poccham-ai >/dev/null 2>&1; then
  note "起動: $(command -v suite-with-poccham-ai)"
  exec suite-with-poccham-ai "$@"
fi

cat <<'EOS'
[Suite with Poccham AI] 実行ファイルが見つかりません。

  * AppImage を使う場合 : この .sh を SuiteWithPocchamAI_*_amd64.AppImage と同じフォルダに置く
  * deb / rpm を使う場合: sudo apt install ./suite-with-poccham-ai_*.deb  などで導入後、再実行
  * 依存が足りない場合 : sudo apt install libwebkit2gtk-4.1-0 libgtk-3-0
EOS
exit 1
