@echo off
rem ============================================================
rem  Suite with Poccham AI ランチャー (Windows)
rem  この .bat をアプリの .exe と同じフォルダに置いて
rem  ダブルクリックしてください。インストールは不要です。
rem ============================================================
setlocal EnableDelayedExpansion
chcp 65001 >nul 2>&1
cd /d "%~dp0"

set "APP="

rem 1) 同じフォルダの実行ファイル（ポータブル版 / インストーラ版の両方に対応）
for %%F in ("SuiteWithPocchamAI.exe" "Suite with Poccham AI.exe" "suite-with-poccham-ai.exe") do (
  if not defined APP if exist "%%~fF" set "APP=%%~fF"
)

rem 2) サブフォルダも探す
if not defined APP (
  for /r "%~dp0" %%F in (SuiteWithPocchamAI.exe "Suite with Poccham AI.exe") do (
    if not defined APP if exist "%%~fF" set "APP=%%~fF"
  )
)

if not defined APP (
  echo [Suite with Poccham AI] 実行ファイルが見つかりません。
  echo.
  echo この .bat をアプリの .exe（SuiteWithPocchamAI.exe）と同じフォルダに置いてから実行してください。
  echo.
  pause
  exit /b 1
)

echo [Suite with Poccham AI] 起動: "!APP!"
start "" "!APP!"

if errorlevel 1 (
  echo.
  echo 起動できませんでした。WebView2 ランタイムが必要です:
  echo   https://developer.microsoft.com/microsoft-edge/webview2/
  echo.
  pause
  exit /b 1
)

exit /b 0
