#!/bin/bash
# ============================================================
#  Suite with Poccham AI ランチャー (macOS)
#  この .command を "Suite with Poccham AI.app" または .dmg と
#  同じフォルダに置いてダブルクリックしてください。
#  実行権限が無い場合は次のように起動できます:
#     bash "Start-Suite-with-Poccham-AI.command"
# ============================================================
set -uo pipefail

cd "$(dirname "$0")" || exit 1
note() { printf '[Suite with Poccham AI] %s\n' "$*"; }

APPDIR="Suite with Poccham AI.app"
APP=""
for c in "$APPDIR" *.app; do
  if [ -d "$c" ]; then APP="$c"; break; fi
done

# .app が無く .dmg がある場合はマウントして /Applications へコピーする
if [ -z "$APP" ]; then
  dmg=$(ls -1 ./*.dmg 2>/dev/null | head -n1 || true)
  if [ -n "${dmg:-}" ]; then
    note "dmg をマウントします: $dmg"
    mnt=$(hdiutil attach -nobrowse -readonly "$dmg" 2>/dev/null | awk -F'\t' 'END{print $NF}')
    if [ -n "${mnt:-}" ] && [ -d "$mnt/$APPDIR" ]; then
      note "アプリを Applications へコピーします"
      cp -R "$mnt/$APPDIR" /Applications/ 2>/dev/null \
        || { mkdir -p "$HOME/Applications" && cp -R "$mnt/$APPDIR" "$HOME/Applications/" 2>/dev/null; } \
        || true
      hdiutil detach "$mnt" >/dev/null 2>&1 || true
      for c in "/Applications/$APPDIR" "$HOME/Applications/$APPDIR"; do
        if [ -d "$c" ]; then APP="$c"; break; fi
      done
    fi
  fi
fi

if [ -z "$APP" ]; then
  note ".app が見つかりません。"
  cat <<'EOS'
  * "Suite with Poccham AI.app" と同じフォルダにこの .command を置いて実行
  * または .dmg と同じフォルダに置いて実行（自動でマウント→コピーします）
  * 実行権限が無い場合:  bash "Start-Suite-with-Poccham-AI.command"
EOS
  read -r -p "Enter で終了します..." _ || true
  exit 1
fi

# 未署名ビルドの隔離属性を解除（「開発元を確認できません」対策）
note "隔離属性を解除: $APP"
xattr -dr com.apple.quarantine "$APP" 2>/dev/null || true

note "起動: $APP"
open "$APP" || exit 1
exit 0
