-- =============================================================================
-- Sarashina Suite: 初期スキーマ (user_version = 1)
-- 方針: すべてローカル。ネットワーク同期なし。削除は基本ソフトデリート。
-- =============================================================================

-- ドキュメント（doc=文書 / sheet=表計算 / slide=プレゼン）
CREATE TABLE IF NOT EXISTS documents (
    id          TEXT PRIMARY KEY,
    title       TEXT NOT NULL DEFAULT '無題のドキュメント',
    kind        TEXT NOT NULL DEFAULT 'doc' CHECK (kind IN ('doc', 'sheet', 'slide')),
    content     TEXT NOT NULL DEFAULT '',   -- リッチテキスト HTML（サニタイズ済み）
    plain_text  TEXT NOT NULL DEFAULT '',   -- 検索用のプレーンテキスト
    pinned      INTEGER NOT NULL DEFAULT 0,
    created_at  INTEGER NOT NULL,           -- Unix epoch (ms)
    updated_at  INTEGER NOT NULL,
    deleted_at  INTEGER                     -- ゴミ箱（NULL = 有効）
);
CREATE INDEX IF NOT EXISTS idx_documents_updated ON documents (updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_documents_live    ON documents (deleted_at, updated_at DESC);

-- 版管理（自動スナップショット / 手動スナップショット）
CREATE TABLE IF NOT EXISTS document_versions (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    document_id TEXT NOT NULL REFERENCES documents (id) ON DELETE CASCADE,
    content     TEXT NOT NULL,
    bytes       INTEGER NOT NULL,
    created_at  INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_versions_doc ON document_versions (document_id, created_at DESC);

-- 全文検索 (FTS5)。日本語は単語分割が不要な trigram トークナイザで部分一致検索。
CREATE VIRTUAL TABLE IF NOT EXISTS documents_fts USING fts5(
    title,
    plain_text,
    content = 'documents',
    content_rowid = 'rowid',
    tokenize = 'trigram'
);

CREATE TRIGGER IF NOT EXISTS documents_ai AFTER INSERT ON documents BEGIN
    INSERT INTO documents_fts (rowid, title, plain_text)
    VALUES (new.rowid, new.title, new.plain_text);
END;

CREATE TRIGGER IF NOT EXISTS documents_ad AFTER DELETE ON documents BEGIN
    INSERT INTO documents_fts (documents_fts, rowid, title, plain_text)
    VALUES ('delete', old.rowid, old.title, old.plain_text);
END;

CREATE TRIGGER IF NOT EXISTS documents_au AFTER UPDATE ON documents BEGIN
    INSERT INTO documents_fts (documents_fts, rowid, title, plain_text)
    VALUES ('delete', old.rowid, old.title, old.plain_text);
    INSERT INTO documents_fts (rowid, title, plain_text)
    VALUES (new.rowid, new.title, new.plain_text);
END;

-- AI チャット（ドキュメントに紐づくアシスタント会話）
CREATE TABLE IF NOT EXISTS chat_sessions (
    id          TEXT PRIMARY KEY,
    document_id TEXT REFERENCES documents (id) ON DELETE SET NULL,
    title       TEXT NOT NULL DEFAULT '新しい会話',
    created_at  INTEGER NOT NULL,
    updated_at  INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS chat_messages (
    id          TEXT PRIMARY KEY,
    session_id  TEXT NOT NULL REFERENCES chat_sessions (id) ON DELETE CASCADE,
    role        TEXT NOT NULL CHECK (role IN ('system', 'user', 'assistant')),
    content     TEXT NOT NULL,
    tokens      INTEGER,
    created_at  INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_messages_session ON chat_messages (session_id, created_at);

-- インストール済み GGUF モデル台帳
CREATE TABLE IF NOT EXISTS models (
    id          TEXT PRIMARY KEY,           -- カタログ ID (例: sarashina2.2-1b-instruct-q4_k_m)
    display_name TEXT NOT NULL,
    file_name   TEXT NOT NULL,
    path        TEXT NOT NULL,              -- 解決済み絶対パス
    size_bytes  INTEGER NOT NULL DEFAULT 0,
    sha256      TEXT,
    status      TEXT NOT NULL DEFAULT 'installed' CHECK (status IN ('installed', 'broken')),
    installed_at INTEGER NOT NULL,
    last_used_at INTEGER
);

-- ダウンロード中断復帰用の状態（Range リクエストの再開に使う）
CREATE TABLE IF NOT EXISTS downloads (
    model_id    TEXT PRIMARY KEY,
    url         TEXT NOT NULL,
    downloaded  INTEGER NOT NULL DEFAULT 0,
    total       INTEGER NOT NULL DEFAULT 0,
    etag        TEXT,
    updated_at  INTEGER NOT NULL
);

-- 生成ログ（性能計測のみ。外部送信は一切しない）
CREATE TABLE IF NOT EXISTS generation_logs (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    model_id     TEXT,
    prompt_tokens INTEGER NOT NULL DEFAULT 0,
    completion_tokens INTEGER NOT NULL DEFAULT 0,
    elapsed_ms   INTEGER NOT NULL DEFAULT 0,
    tokens_per_sec REAL NOT NULL DEFAULT 0,
    created_at   INTEGER NOT NULL
);

-- 設定（KVS）
CREATE TABLE IF NOT EXISTS settings (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);
