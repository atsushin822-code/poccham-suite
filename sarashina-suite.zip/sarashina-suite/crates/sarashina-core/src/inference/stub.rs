//! スタブ推論バックエンド。
//!
//! `--no-default-features`（llama feature 無効）でビルドした場合に使われる。
//! C++ ツールチェーン不要で UI/UX とパイプライン全体を開発・E2E できるようにするのが目的。
//! 実モデルではなく固定のダミー応答をトークン風にストリーミングする。

use std::path::Path;
use std::sync::atomic::{AtomicBool, Ordering};
use std::time::{Duration, Instant};

use super::engine::{make_stats, Backend, ChatTurn, EngineConfig, GenOptions, GenStats, TokenSink};
use crate::error::Result;

pub struct StubBackend {
    loaded: Option<String>,
}

impl StubBackend {
    pub fn new() -> Self {
        Self { loaded: None }
    }
}

const SAMPLE: &str = "（スタブ応答）llama feature が無効のビルドです。\
このメッセージはローカルモデルを読み込まずに生成されています。\
リリースビルドでは Poccham AI がローカル推論エンジンで応答します。";

impl Backend for StubBackend {
    fn name(&self) -> &'static str {
        "stub"
    }

    fn is_loaded(&self) -> bool {
        self.loaded.is_some()
    }

    fn load(&mut self, path: &Path, _config: &EngineConfig) -> Result<()> {
        self.loaded = Some(path.display().to_string());
        Ok(())
    }

    fn generate(
        &mut self,
        messages: &[ChatTurn],
        options: &GenOptions,
        _config: &EngineConfig,
        cancel: &AtomicBool,
        sink: &mut dyn TokenSink,
    ) -> Result<GenStats> {
        let started = Instant::now();
        let prompt_tokens = messages.iter().map(|m| m.content.chars().count() / 2).sum();
        let mut n = 0usize;
        let mut cancelled = false;
        let mut buffer = String::new();

        for ch in SAMPLE.chars() {
            if cancel.load(Ordering::SeqCst) {
                cancelled = true;
                break;
            }
            if n >= options.max_tokens {
                break;
            }
            buffer.push(ch);
            // 数文字ずつまとめて送出（実トークンに近いストリーミング感）
            if buffer.chars().count() >= 3 {
                sink.on_token(&buffer);
                buffer.clear();
                n += 1;
                std::thread::sleep(Duration::from_millis(30));
            }
        }
        if !buffer.is_empty() {
            sink.on_token(&buffer);
            n += 1;
        }

        Ok(make_stats(
            prompt_tokens,
            n,
            started,
            cancelled,
            if cancelled { "cancelled" } else { "stop" },
        ))
    }
}
