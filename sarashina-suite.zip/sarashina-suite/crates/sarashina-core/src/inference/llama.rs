//! llama.cpp バックエンド（`llama-cpp-2` クレート経由）。
//!
//! * モデルは mmap で読み込むため、数 GB の GGUF でも起動は高速・メモリ効率良好
//! * リクエストごとに `LlamaContext` を生成（会話を跨いだ KV キャッシュの汚染を防ぐ）
//! * サンプリングは temperature → top_k → top_p → penalties → dist のチェーン
//!
//! 依存クレートのバージョンは `Cargo.toml` で `0.1.161` に固定している。
//! llama.cpp 側の API 変更が激しいため、更新時はこのファイルのコンパイル確認を必須とすること。

use std::num::NonZeroU32;
use std::path::Path;
use std::sync::atomic::{AtomicBool, Ordering};
use std::time::Instant;

use llama_cpp_2::context::params::LlamaContextParams;
use llama_cpp_2::llama_backend::LlamaBackend;
use llama_cpp_2::llama_batch::LlamaBatch;
use llama_cpp_2::model::params::LlamaModelParams;
use llama_cpp_2::model::{LlamaChatMessage, LlamaChatTemplate, LlamaModel};
use llama_cpp_2::sampling::LlamaSampler;

use super::engine::{
    flush_utf8, make_stats, Backend, ChatTurn, EngineConfig, GenOptions, GenStats, TokenSink,
};
use super::prompt;
use crate::error::{CoreError, Result};

pub struct LlamaBackendImpl {
    backend: Option<LlamaBackend>,
    model: Option<LlamaModel>,
    template: Option<LlamaChatTemplate>,
    n_ctx_loaded: u32,
}

impl LlamaBackendImpl {
    pub fn new() -> Self {
        Self { backend: None, model: None, template: None, n_ctx_loaded: 0 }
    }

    /// GGUF 埋め込みのチャットテンプレートを優先し、無ければフォールバック
    fn build_prompt(&self, model: &LlamaModel, messages: &[ChatTurn]) -> Result<String> {
        if let Some(tmpl) = &self.template {
            let chat: Vec<LlamaChatMessage> = messages
                .iter()
                .filter_map(|m| {
                    let role = match m.role.as_str() {
                        "assistant" => "assistant",
                        "system" => "system",
                        _ => "user",
                    };
                    LlamaChatMessage::new(role.to_string(), m.content.clone()).ok()
                })
                .collect();
            if !chat.is_empty() {
                // add_ass = true: 生成側の発話開始タグを付与
                match model.apply_chat_template(tmpl, &chat, true) {
                    Ok(p) => return Ok(p),
                    Err(e) => tracing::warn!("apply_chat_template 失敗、フォールバック使用: {e}"),
                }
            }
        }
        Ok(prompt::fallback_prompt(messages))
    }
}

impl Backend for LlamaBackendImpl {
    fn name(&self) -> &'static str {
        "llama.cpp"
    }

    fn is_loaded(&self) -> bool {
        self.model.is_some()
    }

    fn load(&mut self, path: &Path, config: &EngineConfig) -> Result<()> {
        // バックエンド初期化はプロセス内で 1 回だけ（2 回目は BackendAlreadyInitialized）
        if self.backend.is_none() {
            let backend = LlamaBackend::init()
                .map_err(|e| CoreError::inference(format!("llama backend 初期化失敗: {e}")))?;
            self.backend = Some(backend);
        }
        let backend = self
            .backend
            .as_ref()
            .ok_or_else(|| CoreError::inference("llama backend がありません"))?;

        if !path.exists() {
            return Err(CoreError::NotFound(format!("モデルファイル {}", path.display())));
        }

        let params = LlamaModelParams::default()
            .with_n_gpu_layers(config.n_gpu_layers)
            .with_use_mmap(true);

        let started = Instant::now();
        let model = LlamaModel::load_from_file(backend, path, &params)
            .map_err(|e| CoreError::inference(format!("GGUF の読み込みに失敗: {e}")))?;

        tracing::info!(
            "model loaded in {:?}: {:?} ({} params)",
            started.elapsed(),
            path.file_name(),
            model.n_params()
        );

        // モデルに埋め込まれたテンプレート（<|system|>…<|user|>…<|assistant|> 形式）
        self.template = model.chat_template(None).ok();
        if self.template.is_none() {
            tracing::warn!("GGUF にチャットテンプレートがありません。フォールバックを使用します");
        }

        self.n_ctx_loaded = config.n_ctx;
        self.model = Some(model);
        Ok(())
    }

    fn generate(
        &mut self,
        messages: &[ChatTurn],
        options: &GenOptions,
        config: &EngineConfig,
        cancel: &AtomicBool,
        sink: &mut dyn TokenSink,
    ) -> Result<GenStats> {
        let backend = self
            .backend
            .as_ref()
            .ok_or_else(|| CoreError::inference("llama backend が未初期化です"))?;
        let model = self
            .model
            .as_ref()
            .ok_or_else(|| CoreError::Model("モデルがロードされていません".into()))?;

        let n_ctx = if options.n_ctx > 0 { options.n_ctx } else { config.n_ctx.max(self.n_ctx_loaded) };
        let n_ctx = n_ctx.max(512);
        let n_batch = 512.min(n_ctx) as usize;

        let ctx_params = LlamaContextParams::default()
            .with_n_ctx(NonZeroU32::new(n_ctx))
            .with_n_batch(n_batch as u32)
            .with_n_threads(config.n_threads)
            .with_n_threads_batch(config.n_threads);

        // コンテキストはリクエスト毎に生成（前の会話の KV を持ち越さない）
        let mut ctx = model
            .new_context(backend, ctx_params)
            .map_err(|e| CoreError::inference(format!("コンテキスト生成に失敗: {e}")))?;

        let started = Instant::now();

        // --- プロンプトのトークン化とコンテキスト予算の調整 -----------------
        let max_tokens = options
            .max_tokens
            .clamp(16, (n_ctx as usize).saturating_sub(64))
            .min(n_ctx as usize / 2);

        let mut prompt_text = self.build_prompt(model, messages)?;
        let mut tokens = model.vocab().tokenize(prompt_text.as_bytes(), true, true);

        let mut budget_chars = (n_ctx as usize).saturating_sub(max_tokens) * 2;
        let mut attempt = 0;
        while tokens.len() + max_tokens > n_ctx as usize && budget_chars > 128 && attempt < 8 {
            budget_chars = budget_chars * 2 / 3;
            let trimmed = prompt::trim_to_budget(messages, budget_chars);
            prompt_text = self.build_prompt(model, &trimmed)?;
            tokens = model.vocab().tokenize(prompt_text.as_bytes(), true, true);
            attempt += 1;
        }
        if tokens.len() + 16 >= n_ctx as usize {
            return Err(CoreError::Invalid(format!(
                "プロンプトが長すぎます ({} トークン / 上限 {n_ctx})。新しい会話を開始してください",
                tokens.len()
            )));
        }
        let prompt_tokens = tokens.len();

        // --- プロンプトを n_batch ずつデコード -----------------------------
        let mut batch = LlamaBatch::new(n_batch, 1);
        let mut pos: i32 = 0;
        for (idx, chunk) in tokens.chunks(n_batch).enumerate() {
            let _ = idx;
            batch.clear();
            let last = chunk.len() - 1;
            for (i, token) in chunk.iter().enumerate() {
                batch
                    .add(*token, pos, &[0], i == last)
                    .map_err(|e| CoreError::inference(format!("batch 追加に失敗: {e}")))?;
                pos += 1;
            }
            ctx.decode(&mut batch)
                .map_err(|e| CoreError::inference(format!("プロンプトのデコードに失敗: {e}")))?;
            if cancel.load(Ordering::SeqCst) {
                return Ok(make_stats(prompt_tokens, 0, started, true, "cancelled"));
            }
        }

        // --- サンプラチェーン -----------------------------------------------
        let seed = if options.seed == 0 {
            (crate::now_ms() as u32) ^ 0x9E37_79B9
        } else {
            options.seed
        };
        let mut samplers = Vec::with_capacity(5);
        if options.repeat_penalty > 1.0 {
            samplers.push(LlamaSampler::penalties(
                model.n_vocab(),
                128,
                options.repeat_penalty,
                0.0,
                0.0,
            ));
        }
        if options.temperature > 0.01 {
            samplers.push(LlamaSampler::temp(options.temperature));
            samplers.push(LlamaSampler::top_k(options.top_k.max(1)));
            samplers.push(LlamaSampler::top_p(options.top_p.clamp(0.01, 1.0), 1));
            samplers.push(LlamaSampler::dist(seed));
        } else {
            // temperature 0 = 貪欲法（決定的な出力が欲しい校正・整形向け）
            samplers.push(LlamaSampler::greedy());
        }
        let mut sampler = LlamaSampler::chain_simple(samplers);

        // --- 生成ループ ------------------------------------------------------
        let mut n_generated = 0usize;
        let mut carry: Vec<u8> = Vec::new();
        let mut cancelled = false;
        let mut finish_reason = "length";

        loop {
            if cancel.load(Ordering::SeqCst) {
                cancelled = true;
                finish_reason = "cancelled";
                break;
            }
            if n_generated >= max_tokens {
                break;
            }
            if pos as usize + 1 >= n_ctx as usize {
                finish_reason = "context_full";
                break;
            }

            let token = sampler.sample(&ctx, -1);
            if model.vocab().is_eog(token) {
                finish_reason = "stop";
                break;
            }

            let mut piece: Vec<u8> = Vec::new();
            model.vocab().token_to_piece_into(token, &mut piece, false, None);
            carry.extend_from_slice(&piece);
            // 文字境界を跨いだバイト列は次トークンへ持ち越す
            if flush_utf8(&mut carry, sink) {
                // 完全な文字列を送出済み
            }

            n_generated += 1;

            batch.clear();
            batch
                .add(token, pos, &[0], true)
                .map_err(|e| CoreError::inference(format!("batch 追加に失敗: {e}")))?;
            pos += 1;
            ctx.decode(&mut batch)
                .map_err(|e| CoreError::inference(format!("デコードに失敗: {e}")))?;
        }

        // ループ終了時に残った完全なバイト列を流す
        flush_utf8(&mut carry, sink);

        Ok(make_stats(prompt_tokens, n_generated, started, cancelled, finish_reason))
    }
}
